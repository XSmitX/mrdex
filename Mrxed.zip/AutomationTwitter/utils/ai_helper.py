import os
import logging
from dotenv import load_dotenv
import requests
import json

logger = logging.getLogger(__name__)

# Load environment variables first
load_dotenv()

def generate_content(text: str, prompt_type: str = "standard"):
    """Generate content using OpenAI synchronously with direct API call"""
    try:
        # System prompts
        SYSTEM_PROMPTS = {
    "standard": """
You are a specialized script writer for government and official communications. Your task is to create professional, concise, and impactful reel scripts based on official statements, tweets, or communication briefs. For each scene, provide:

- 🏷️ Title: (max 50 characters, catchy)
- 📝 Description: (max 200 characters, engaging, concise)
- #️⃣ Hashtags: (2-4 relevant hashtags, space-separated)

OUTPUT STRUCTURE:
1. Title Section:
   - Use "TITLE:" prefix in all caps
   - Include subtitle with "Subtitle:" prefix
   - Specify "Duration:" and "Format:" on separate lines

2. Script Structure:
   - Number each scene (SCENE 1, SCENE 2, etc.)
   - Include timestamp for each scene [0:00 - 0:00]
   - For each scene, provide:
     🏷️ Title: ...
     📝 Description: ...
     #️⃣ Hashtags: ...
     🎙️ VO: ...
     📋 PRODUCTION NOTE: ...
     🎞️ SCENE DESCRIPTION: ...
   - Use clear line breaks between sections
   - Use dashes (---) as scene separators

IMPORTANT FORMATTING:
- Use clear visual structure with line breaks between sections
- Number all scenes clearly with timestamps
- Format consistently throughout the document
- Always include a SCENE DESCRIPTION for each scene that is detailed and helps visualize what the scene should contain
"""
}
        

        # Get the appropriate system prompt
        system_prompt = SYSTEM_PROMPTS.get(prompt_type, SYSTEM_PROMPTS["standard"])
        
        # Get API key from environment
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            return "Error: OpenAI API key not found in environment variables"
            
        # Create request data
        request_data = {
            "model": "gpt-4o",
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": text}
            ]
        }
        
        # Make direct API call
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}"
        }
        
        response = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers=headers,
            json=request_data
        )
        
        # Parse response
        if response.status_code == 200:
            response_json = response.json()
            if "choices" in response_json and len(response_json["choices"]) > 0:
                if "message" in response_json["choices"][0] and "content" in response_json["choices"][0]["message"]:
                    content = response_json["choices"][0]["message"]["content"]
                    
                    # Format for better visual appearance in Telegram
                    content = format_for_telegram_html(content)
                    
                    return content
            
            return "Error: Unexpected response format from OpenAI"
        else:
            return f"Error: OpenAI API returned status code {response.status_code}: {response.text}"

    except Exception as e:
        logger.error(f"Error generating content: {e}")
        return f"Error generating content: {str(e)}\n\nPlease try again later."

def format_for_telegram_html(content):
    """Format the content for better visual structure using HTML for Telegram"""
    
    # Replace dashed lines with consistent separators
    content = content.replace("---", "━━━━━━━━━━━━━━━━━━━━━━━━━━")
    
    # Add spacing for better readability
    lines = content.split('\n')
    formatted_lines = []
    
    for i, line in enumerate(lines):
        # Make TITLE stand out
        if "TITLE:" in line:
            formatted_lines.append(f"📝 {line}")
        # Make SCENE headers stand out
        elif line.strip().startswith("SCENE") and "[" in line:
            formatted_lines.append(f"🎬 {line}")
        # Make Voice Over stand out
        elif "VO:" in line or "VOICE OVER:" in line:
            formatted_lines.append(f"🎙️ {line}")
        # Make Production Notes stand out
        elif "PRODUCTION NOTE:" in line:
            formatted_lines.append(f"📋 {line}")
        # Make Scene Description stand out
        elif "SCENE DESCRIPTION:" in line:
            formatted_lines.append(f"🎞️ {line}")
        # Format timestamps nicely
        elif "[0:" in line or "[1:" in line or "[2:" in line:  # Common timestamps
            formatted_lines.append(f"⏱️ {line}")
        # Format subtitles
        elif "Subtitle:" in line:
            formatted_lines.append(f"📌 {line}")
        # Format duration and format specs
        elif "Duration:" in line:
            formatted_lines.append(f"⏰ {line}")
        elif "Format:" in line:
            formatted_lines.append(f"📱 {line}")
        else:
            formatted_lines.append(line)
            
    # Join the lines back together
    content = '\n'.join(formatted_lines)
    
    # Add extra blank lines before scene separators for clearer structure
    content = content.replace("━━━━━━━━━━━━━━━━━━━━━━━━━━", "\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━\n")
    
    # Ensure consistent spacing between sections
    content = content.replace("\n\n\n\n", "\n\n")
    content = content.replace("\n\n\n", "\n\n")
    
    return content 
