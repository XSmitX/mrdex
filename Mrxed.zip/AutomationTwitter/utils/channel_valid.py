"""
Channel Validation Helpers
Contains async helpers for validating and fixing Telegram channel IDs.
"""

import asyncio
import logging
from utils.config import Config

# Simple in-memory cache for chat info
_chat_cache = {}

# If you have other places where you call get_chat with different IDs, you can use the same cache:
async def get_chat_with_cache(client, chat_id):
    if chat_id in _chat_cache:
        return _chat_cache[chat_id]
    chat = await client.get_chat(chat_id)
    _chat_cache[chat_id] = chat
    return chat
