from playwright.async_api import Page, Browser, BrowserContext
import json
import logging
from typing import Dict, List, Optional, Tuple
import aiofiles
import os
from datetime import datetime
import asyncio
import csv

logger = logging.getLogger(__name__)

async def login_with_credentials(page: Page, username: str, password: str) -> bool:
    """Login to Twitter using username and password - optimized for speed"""
    try:
        logger.info("Attempting to login with credentials...")
        
        # Navigate to login page with shorter timeout
        logger.info("Navigating to login page...")
        await page.goto("https://x.com/i/flow/login", timeout=30000, wait_until="domcontentloaded")
        await page.wait_for_timeout(1000)  # Brief wait for essential elements
        
        # Fill username with updated selectors - no need for long waits
        logger.info(f"Entering username: {username}")
        username_input = await page.wait_for_selector("input[autocomplete='username']", timeout=5000)
        if not username_input:
            logger.error("Could not find username input field")
            return False
        await username_input.fill(username)
        
        # Click the Next button - try multiple possible selectors with shorter timeouts
        logger.info("Clicking Next button...")
        next_button_selectors = [
            "div[data-testid='auth-next-button']",
            "div[data-testid='auth-login-button']",
            "div[data-testid='LoginForm_Login_Button']", 
            "div[role='button'][tabindex='0']:has-text('Next')",
            "[data-testid='nextButton']"
        ]
        
        clicked = False
        for selector in next_button_selectors:
            try:
                if await page.locator(selector).count() > 0:
                    await page.locator(selector).click(timeout=2000)
                    clicked = True
                    logger.info(f"Clicked Next button with selector: {selector}")
                    break
            except:
                continue
        
        if not clicked:
            # Try to find any visible button
            try:
                logger.info("Trying to find any Next-like button...")
                await page.click("text=Next", timeout=2000)
                clicked = True
            except Exception as e:
                logger.error(f"Could not click Next button: {e}")
                return False
        
        await page.wait_for_timeout(1000)
        
        # Wait for password field with shorter timeout
        logger.info("Looking for password field...")
        password_input = await page.wait_for_selector("input[name='password'], input[type='password']", timeout=5000)
        if not password_input:
            logger.error("Could not find password input field")
            return False
            
        # Fill password
        logger.info("Entering password...")
        await password_input.fill(password)
        
        # Click the login button with shorter timeouts
        logger.info("Clicking Login button...")
        login_selectors = [
            "div[data-testid='LoginForm_Login_Button']",
            "div[role='button']:has-text('Log in')",
            "[data-testid='LoginForm_Login_Button']",
            "div[role='button'][tabindex='0']:has-text('Log in')"
        ]
        
        clicked = False
        for selector in login_selectors:
            try:
                if await page.locator(selector).count() > 0:
                    await page.locator(selector).click(timeout=2000)
                    clicked = True
                    logger.info(f"Clicked Login button with selector: {selector}")
                    break
            except:
                continue
        
        if not clicked:
            # Try to find any visible login button
            try:
                logger.info("Trying to find any Login button...")
                await page.click("text=Log in", timeout=2000)
                clicked = True
            except Exception as e:
                logger.error(f"Could not click Login button: {e}")
                return False
        
        # Brief wait for login to complete
        logger.info("Waiting for login process to complete...")
        await page.wait_for_timeout(3000)
        
        # Check login immediately rather than waiting
        return await verify_login(page)
        
    except Exception as e:
        logger.error(f"Login error: {e}")
        return False

async def extract_and_save_cookies(context: BrowserContext, username: str, cookie_dir: str) -> Optional[str]:
    """Extract cookies after successful login and save them"""
    try:
        # Get all cookies
        cookies = await context.cookies()
        
        # Prepare cookie file path
        cookie_file = os.path.join(cookie_dir, f"{username}_cookies.json")
        
        # Save cookies to file
        async with aiofiles.open(cookie_file, 'w') as f:
            await f.write(json.dumps(cookies))
        
        logger.info(f"Saved cookies to {cookie_file}")
        return cookie_file
    
    except Exception as e:
        logger.error(f"Error saving cookies: {e}")
        return None

async def validate_and_load_cookies(context, cookie_file: str) -> bool:
    """Validate and load cookies for browser context"""
    try:
        # Read and parse cookie file
        async with aiofiles.open(cookie_file, 'r', encoding='utf-8') as f:
            content = await f.read()
            cookies = json.loads(content)
        
        if not isinstance(cookies, list):
            logger.error("Invalid cookie format - not a list")
            return False
        
        logger.info(f"Found {len(cookies)} cookies in file")
        
        # Filter and process cookies
        essential_cookies = []
        essential_names = ["auth_token", "ct0", "twid", "kdt"]
        found_essential = set()
        
        for cookie in cookies:
            try:
                # Basic validation
                if not all(field in cookie for field in ["name", "value", "domain", "path"]):
                    continue
                
                # Process essential cookies
                if cookie["name"] in essential_names:
                    # Fix domain
                    if cookie["domain"] in ["x.com"]:
                        cookie["domain"] = "." + cookie["domain"]
                    elif not cookie["domain"].startswith("."):
                        cookie["domain"] = "." + cookie["domain"]
                    
                    # Ensure secure flag
                    cookie["secure"] = True
                    
                    # Add to essential cookies
                    essential_cookies.append(cookie)
                    found_essential.add(cookie["name"])
                    
                    logger.info(f"Processed essential cookie: {cookie['name']}")
            
            except Exception as e:
                logger.error(f"Error processing cookie: {e}")
                continue
        
        # Check if we found all essential cookies
        missing_cookies = set(essential_names) - found_essential
        if missing_cookies:
            logger.error(f"Missing essential cookies: {missing_cookies}")
            return False
        
        # Log cookie details for debugging
        logger.info(f"Found {len(essential_cookies)} essential cookies")
        for cookie in essential_cookies:
            logger.info(f"Cookie: {cookie['name']}, Domain: {cookie['domain']}")
        
        # Add cookies to context
        try:
            await context.add_cookies(essential_cookies)
            logger.info("Successfully added cookies to browser context")
            return True
        except Exception as e:
            logger.error(f"Failed to add cookies to context: {e}")
            return False
    
    except json.JSONDecodeError:
        logger.error(f"Invalid JSON in cookie file: {cookie_file}")
        return False
    except FileNotFoundError:
        logger.error(f"Cookie file not found: {cookie_file}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error loading cookies: {e}")
        return False

async def verify_login(page: Page) -> bool:
    """Verify if login was successful with minimal waiting"""
    try:
        logger.info("Verifying login status...")
        
        # Navigate to home page with shorter timeout and less waiting
        try:
            logger.info("Quick navigation to home page...")
            # Use domcontentloaded instead of networkidle to avoid long waits
            await page.goto("https://x.com/home", timeout=20000, wait_until="domcontentloaded")
            
            # Don't wait for full page load, just check URL immediately
            current_url = page.url
            logger.info(f"Current URL after navigation: {current_url}")
            
            # Quick check - if URL contains home, we're logged in
            login_success_urls = ["x.com/home", "/home"]  # Removed twitter.com
            if any(url in current_url for url in login_success_urls):
                logger.info("✓ Login verified quickly by URL")
                return True
            
        except Exception as e:
            logger.error(f"Navigation error: {e}")
            # Continue with element checks even if navigation had issues
        
        # Quick check for logged-in elements without waiting
        selectors = [
            "[data-testid='SideNav_NewTweet_Button']",
            "[data-testid='AppTabBar_Profile_Link']",
            "[data-testid='primaryColumn']",
            "[data-testid='SideNav']"
        ]
        
        # Try to find any logged-in indicator
        for selector in selectors:
            try:
                if await page.locator(selector).count(timeout=1000) > 0:
                    logger.info(f"✓ Login verified by element: {selector}")
                    return True
            except Exception:
                # Ignore errors and try next selector
                continue
        
        # Final check - if we're not redirected to login page, assume success
        if "login" not in current_url and "x.com" in current_url:  # Only check for x.com
            logger.info("✓ Login verified by not being on login page")
            return True
                
        logger.info("✗ Login verification failed")
        return False
        
    except Exception as e:
        logger.error(f"Error verifying login: {e}")
        return False

async def export_to_csv(accounts, username):
    """Export accounts to CSV file"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"following_{username}_{timestamp}.csv"
    
    try:
        with open(filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=['username', 'name', 'fetched_at'])
            writer.writeheader()
            writer.writerows(accounts)
        logger.info(f"Exported {len(accounts)} accounts to {filename}")
        return filename
    except Exception as e:
        logger.error(f"Error exporting to CSV: {e}")
        return None

async def fetch_following_accounts(page, username, progress_callback=None, max_accounts=100):
    """
    Fetch all accounts that the user follows
    Args:
        page: Playwright page object
        username: Twitter username to fetch following for
        progress_callback: Optional async callback function that receives the current list of accounts
        max_accounts: Maximum number of accounts to fetch (default 100, set to 0 for unlimited)
    Returns:
        List of dicts containing username and display name
    """
    logger.info(f"Starting to fetch following accounts for @{username}")
    following_accounts = []
    seen_usernames = set()
    fetch_completed = False
    max_consecutive_attempts_with_no_new = 2  # Reduced from 3 to terminate faster
    last_total_seen = 0
    
    try:
        # Navigate to following page
        url = f"https://x.com/{username}/following"
        logger.info(f"Navigating to {url}")
        
        try:
            response = await page.goto(url, timeout=30000, wait_until="domcontentloaded")
            if not response or response.status >= 400:
                logger.error(f"Navigation failed with status {response.status if response else 'no response'}")
                return []
        except Exception as e:
            logger.error(f"Navigation error: {e}")
            return []
            
        await page.wait_for_timeout(3000)  # Initial wait
        
        # Check for following count first - this helps terminate earlier
        try:
            count_selectors = [
                'a[href*="/following"] span',
                '[data-testid="followingCount"] span',
                'a[href$="/following"] div span span'
            ]
            
            for selector in count_selectors:
                try:
                    following_stats = await page.query_selector(selector)
                    if following_stats:
                        following_text = await following_stats.inner_text()
                        if following_text:
                            # Convert text like "1,234" to number
                            clean_text = ''.join(c for c in following_text if c.isdigit())
                            if clean_text:
                                expected_following_count = int(clean_text)
                                logger.info(f"Expected following count: {expected_following_count}")
                                
                                # If max_accounts is set, use the smaller of the two values
                                if max_accounts > 0 and (expected_following_count > max_accounts):
                                    logger.info(f"Limiting fetch to {max_accounts} accounts (out of {expected_following_count})")
                                    expected_following_count = max_accounts
                                break
                except Exception:
                    continue
        except Exception as e:
            logger.warning(f"Could not determine expected following count: {e}")
            expected_following_count = None
        
        # Initialize scroll state
        scroll_attempts = 0
        max_scroll_attempts = 20  # Reduced to terminate faster
        last_height = 0
        stall_count = 0
        no_new_accounts_count = 0
        
        while scroll_attempts < max_scroll_attempts and not fetch_completed:
            # Add a failsafe - stop after reaching reasonable account count
            if max_accounts > 0 and len(following_accounts) >= max_accounts:
                logger.info(f"Reached maximum account limit: {max_accounts}")
                fetch_completed = True
                break
                
            try:
                # Find user cells
                cells = await page.query_selector_all('[data-testid="UserCell"]')
                if not cells:
                    cells = await page.query_selector_all('[data-testid="cellInnerDiv"]')
                
                if cells:
                    logger.info(f"Found {len(cells)} cells with selector: [data-testid=\"UserCell\"]")
                    initial_count = len(following_accounts)
                    
                    # Process cells
                    for cell in cells:
                        try:
                            # Get username
                            username_element = await cell.query_selector('div[dir="ltr"] span')
                            if not username_element:
                                continue
                                
                            username_text = (await username_element.inner_text()).strip('@')
                            if not username_text or username_text in seen_usernames:
                                continue
                            
                            # Get display name
                            name_element = await cell.query_selector('div[data-testid="User-Name"] span')
                            display_name = await name_element.inner_text() if name_element else username_text
                            
                            # IMPORTANT: Verify this is a following entry, not a suggestion
                            # Check for follow button or following text
                            follow_button = await cell.query_selector('[data-testid="followButton"], [role="button"]:has-text("Follow"), span:has-text("Follow")')
                            following_text = await cell.query_selector('[data-testid="following"], [role="button"]:has-text("Following"), span:has-text("Following")')
                            
                            # If we find a follow button but no following text, it's a suggestion
                            if follow_button and not following_text:
                                button_text = await follow_button.inner_text()
                                if button_text and 'follow' in button_text.lower() and 'following' not in button_text.lower():
                                    logger.debug(f"Skipping suggested account: @{username_text}")
                                    continue
                            
                            # If we can't find either, check for any text containing "Follow"
                            if not follow_button and not following_text:
                                cell_text = await cell.inner_text()
                                if 'follow' in cell_text.lower() and 'following' not in cell_text.lower():
                                    logger.debug(f"Skipping potential suggestion: @{username_text}")
                                    continue
                            
                            # Add account
                            account_info = {
                                "username": username_text,
                                "name": display_name.strip(),
                                "fetched_at": datetime.now().isoformat()
                            }
                            following_accounts.append(account_info)
                            seen_usernames.add(username_text)
                            logger.info(f"Found following: @{username_text}")
                            
                            # Call progress callback if provided
                            if progress_callback and len(following_accounts) % 10 == 0:
                                await progress_callback(following_accounts)
                            
                            # Check if we have found all expected accounts
                            if expected_following_count and len(following_accounts) >= expected_following_count:
                                logger.info(f"Found all {expected_following_count} expected accounts")
                                fetch_completed = True
                                break
                            
                            # Check max accounts again after each account is added
                            if max_accounts > 0 and len(following_accounts) >= max_accounts:
                                logger.info(f"Reached maximum account limit: {max_accounts}")
                                fetch_completed = True
                                break
                                
                        except Exception as e:
                            logger.debug(f"Error processing user cell: {e}")
                            continue
                    
                    # Skip if we've reached completion
                    if fetch_completed:
                        break
                        
                    # Check if we found any new accounts
                    if len(following_accounts) == initial_count:
                        no_new_accounts_count += 1
                        if no_new_accounts_count >= max_consecutive_attempts_with_no_new:
                            if following_accounts:
                                logger.info(f"No new accounts found in last {max_consecutive_attempts_with_no_new} attempts after finding {len(following_accounts)} accounts")
                                fetch_completed = True
                                break
                    else:
                        no_new_accounts_count = 0
                
                # Skip scrolling if we've completed the fetch
                if fetch_completed:
                    break
                
                # Check if the total count has remained the same for multiple attempts
                if last_total_seen == len(following_accounts) and len(following_accounts) > 0:
                    stall_count += 1
                    # If stalled for multiple attempts, we're likely done
                    if stall_count >= max_consecutive_attempts_with_no_new:
                        logger.info(f"Following count stayed at {len(following_accounts)} for {stall_count} attempts - considering completed")
                        fetch_completed = True
                        break
                else:
                    stall_count = 0
                    last_total_seen = len(following_accounts)
                
                # Scroll with dynamic jumps
                current_height = await page.evaluate('document.documentElement.scrollHeight')
                if current_height == last_height:
                    no_new_accounts_count += 1
                    if no_new_accounts_count >= max_consecutive_attempts_with_no_new:
                        if following_accounts:
                            logger.info("Reached end of scrolling")
                            fetch_completed = True
                            break
                else:
                    last_height = current_height
                
                # Scroll with dynamic jumps
                scroll_amount = min(800, current_height // 4)
                await page.evaluate(f'window.scrollBy(0, {scroll_amount})')
                await page.wait_for_timeout(1000)
                
                scroll_attempts += 1
                logger.info(f"Scroll attempt {scroll_attempts}: Found {len(following_accounts)} accounts so far")
                
            except Exception as e:
                logger.error(f"Error during scroll iteration: {e}")
                if following_accounts:
                    # If we have accounts and encounter an error, just stop
                    logger.info(f"Stopping after error with {len(following_accounts)} accounts found")
                    break
                continue
        
        # If we get here with accounts, consider the operation successful
        if following_accounts:
            logger.info(f"Successfully fetched {len(following_accounts)} following accounts")
            return following_accounts
        else:
            logger.error("No following accounts found")
            return []
            
    except Exception as e:
        logger.error(f"Error in fetch_following_accounts: {e}")
        return following_accounts if following_accounts else []

async def fetch_recent_posts(page: Page, count: int = 10) -> List[Dict]:
    """Fetch recent posts from timeline"""
    try:
        logger.info(f"Fetching recent posts (limit: {count})")
        
        # Navigate to home page
        try:
            await page.goto("https://x.com/home", timeout=60000, wait_until="domcontentloaded")
            await page.wait_for_timeout(5000)  # Wait for content to load
            logger.info("Navigated to home page")
        except Exception as e:
            logger.error(f"Navigation error: {e}")
            # Try to continue anyway
        
        # Take a screenshot for debugging
        await page.screenshot(path="timeline.png")
        logger.info("Saved timeline screenshot")
        
        posts = []
        scroll_attempts = 0
        max_scroll_attempts = 5
        
        logger.info("Looking for tweets...")
        
        # Find all tweet articles
        while len(posts) < count and scroll_attempts < max_scroll_attempts:
            # Wait for tweet articles to appear
            tweet_articles = await page.query_selector_all("article[data-testid='tweet']")
            logger.info(f"Found {len(tweet_articles)} tweets on screen")
            
            if not tweet_articles and scroll_attempts == 0:
                logger.warning("No tweets found on first attempt")
                
                # Try alternative selectors if Twitter's structure changed
                alt_articles = await page.query_selector_all("[data-testid='cellInnerDiv']")
                if alt_articles:
                    logger.info(f"Found {len(alt_articles)} alternative tweet containers")
                    tweet_articles = alt_articles
            
            # Process visible tweets
            for article in tweet_articles:
                if len(posts) >= count:
                    break
                    
                try:
                    # Skip if we've already processed this article
                    article_id = await article.evaluate("(el) => el.getAttribute('data-testid-tweet-id') || el.getAttribute('data-tweet-id') || ''")
                    
                    # Look for tweet ID in the article URL
                    if not article_id:
                        links = await article.query_selector_all("a")
                        for link in links:
                            href = await link.get_attribute("href")
                            if href and "/status/" in href:
                                article_id = href.split("/status/")[1].split("?")[0].split("/")[0]
                                break
                    
                    # Skip if we already have this tweet
                    if article_id and any(p.get("id") == article_id for p in posts):
                        continue
                    
                    # Get author
                    author_element = await article.query_selector("[data-testid='User-Name'] a:last-child")
                    author = ""
                    if author_element:
                        author_href = await author_element.get_attribute("href")
                        if author_href:
                            author = author_href.split("/")[-1]
                    
                    # Get tweet text
                    text_element = await article.query_selector("[data-testid='tweetText']")
                    text = await text_element.inner_text() if text_element else ""
                    
                    # Get timestamp
                    time_element = await article.query_selector("time")
                    timestamp = await time_element.get_attribute("datetime") if time_element else ""
                    
                    # Get metrics
                    metrics = {}
                    metric_elements = await article.query_selector_all("[data-testid$='-count']")
                    for metric in metric_elements:
                        metric_type = await metric.get_attribute("data-testid")
                        metric_value = await metric.inner_text()
                        if metric_type and metric_value:
                            metric_key = metric_type.replace("-count", "")
                            metrics[metric_key] = metric_value
                    
                    # Add to posts list only if we have essential data
                    if author and (text or timestamp):
                        post_data = {
                            "author": author,
                            "text": text,
                            "date": timestamp,
                            "metrics": metrics,
                            "id": article_id
                        }
                        posts.append(post_data)
                        logger.info(f"Found tweet by @{author}: {text[:30]}...")
                
                except Exception as e:
                    logger.error(f"Error processing tweet article: {e}")
                    continue
            
            # Break if we have enough posts
            if len(posts) >= count:
                break
                
            # Scroll to load more tweets
            logger.info(f"Scrolling to load more tweets ({len(posts)}/{count})")
            await page.evaluate("window.scrollBy(0, 800)")
            await page.wait_for_timeout(2000)
            scroll_attempts += 1
        
        logger.info(f"Successfully fetched {len(posts)} recent posts")
        return posts
    
    except Exception as e:
        logger.error(f"Error fetching posts: {e}")
        return []

async def fetch_account_posts(page: Page, username: str, max_posts: int = 5) -> List[Dict]:
    """
    Fetch recent posts from a specific Twitter account
    
    Args:
        page: Playwright page object
        username: Twitter username to fetch posts from
        max_posts: Maximum number of posts to fetch (default 5)
    
    Returns:
        List of post dictionaries containing post information
    """
    posts = []
    timeout = 30000  # 30 seconds timeout
    
    try:
        logger.info(f"Fetching up to {max_posts} posts from @{username}")
        
        # Navigate to the user's profile
        try:
            await page.goto(f"https://x.com/{username}", timeout=timeout)
            await page.wait_for_timeout(3000)  # Wait for content to load
        except Exception as e:
            logger.error(f"Failed to navigate to {username}'s profile: {e}")
            return []
        
        # Wait for tweets to load with multiple selectors
        tweet_found = False
        for selector in [
            "article[data-testid='tweet']",
            "[data-testid='cellInnerDiv']",
            "div[data-testid='primaryColumn'] div[data-testid='tweet']",
            "div[data-testid='primaryColumn'] article"
        ]:
            try:
                await page.wait_for_selector(selector, timeout=10000)
                tweet_found = True
                logger.info(f"Found tweets using selector: {selector}")
                break
            except Exception:
                continue
        
        if not tweet_found:
            logger.warning(f"No tweets found for {username}")
            return []
        
        # Get tweets
        tweet_elements = await page.query_selector_all("article[data-testid='tweet']")
        if not tweet_elements:
            tweet_elements = await page.query_selector_all("[data-testid='cellInnerDiv']")
        
        logger.info(f"Found {len(tweet_elements)} tweets for {username}")
        
        # Process up to max_posts tweets
        for i, tweet in enumerate(tweet_elements[:max_posts]):
            try:
                # Extract post information using existing function
                post_data = await extract_post_info(tweet)
                
                # Add author info if not present
                if not post_data.get("author"):
                    post_data["author"] = username
                
                # Skip if this is a retweet or reply (optional)
                if "RT @" in post_data.get("text", ""):
                    continue
                
                posts.append(post_data)
                logger.info(f"Added post {i+1} from {username}")
                
            except Exception as e:
                logger.error(f"Error processing tweet {i+1} from {username}: {e}")
        
        logger.info(f"Successfully fetched {len(posts)} posts from @{username}")
        return posts
        
    except Exception as e:
        logger.error(f"Error in fetch_account_posts: {e}")
        return posts

async def fetch_following_recent_posts(page, username, max_following=10, max_posts=3, min_posts=1):
    """
    Fetches recent posts from accounts that user follows
    :param page: Playwright page object
    :param username: Twitter username whose following list to use
    :param max_following: Maximum number of following accounts to process
    :param max_posts: Maximum posts per account (default 3)
    :param min_posts: Minimum posts required per account
    :return: List of posts with author and content
    """
    posts = []
    following_processed = 0
    timeout = 30000  # 30 seconds timeout
    
    try:
        logger.info(f"Fetching posts from accounts {username} follows")
        
        # Get list of accounts the user follows
        following_accounts = await fetch_following_accounts(page, username=username)
        if not following_accounts:
            logger.warning(f"No following accounts found for {username}")
            return []
            
        logger.info(f"Found {len(following_accounts)} following accounts, processing up to {max_following}")
        
        # Process each following account
        for account in following_accounts[:max_following]:
            following_processed += 1
            account_posts = []
            
            try:
                username = account.get('username')
                display_name = account.get('name', 'Unknown')
                logger.info(f"Fetching posts from {username}")
                
                # Navigate to the user's profile
                try:
                    await page.goto(f"https://x.com/{username}", timeout=timeout)
                    await page.wait_for_timeout(3000)  # Wait for content to load
                except Exception as e:
                    logger.error(f"Failed to navigate to {username}'s profile: {e}")
                    continue
                
                # Wait for tweets to load with multiple selectors
                tweet_found = False
                for selector in [
                    "article[data-testid='tweet']",
                    "[data-testid='cellInnerDiv']",
                    "div[data-testid='primaryColumn'] div[data-testid='tweet']",
                    "div[data-testid='primaryColumn'] article"
                ]:
                    try:
                        await page.wait_for_selector(selector, timeout=10000)
                        tweet_found = True
                        logger.info(f"Found tweets using selector: {selector}")
                        break
                    except Exception:
                        continue
                
                if not tweet_found:
                    logger.warning(f"No tweets found for {username} after trying all selectors")
                    continue
                
                # Get tweets
                tweet_elements = await page.query_selector_all("article[data-testid='tweet']")
                if not tweet_elements:
                    tweet_elements = await page.query_selector_all("[data-testid='cellInnerDiv']")
                
                logger.info(f"Found {len(tweet_elements)} tweets for {username}")
                
                # Process up to max_posts tweets
                for i, tweet in enumerate(tweet_elements[:max_posts]):
                    try:
                        post_data = {
                            "author": username,
                            "display_name": display_name
                        }
                        
                        # Get tweet text with multiple selectors
                        text_found = False
                        for text_selector in [
                            "div[data-testid='tweetText']",
                            "div[lang] span",
                            "div[dir='auto']"
                        ]:
                            try:
                                text_element = await tweet.query_selector(text_selector)
                                if text_element:
                                    post_data["text"] = await text_element.inner_text()
                                    text_found = True
                                    break
                            except Exception:
                                continue
                        
                        if not text_found:
                            post_data["text"] = "No text content"
                        
                        # Get timestamp
                        time_element = await tweet.query_selector("time")
                        if time_element:
                            datetime_attr = await time_element.get_attribute("datetime")
                            post_data["date"] = datetime_attr
                            # Convert to readable format
                            try:
                                dt = datetime.fromisoformat(datetime_attr.replace('Z', '+00:00'))
                                post_data["readable_time"] = dt.strftime('%Y-%m-%d %H:%M:%S')
                            except Exception as e:
                                logger.warning(f"Could not parse datetime: {e}")
                        
                        # Extract image URLs
                        image_urls = []
                        try:
                            # Look for images in the tweet
                            images = await tweet.query_selector_all("img[alt='Image']")
                            for img in images:
                                src = await img.get_attribute("src")
                                if src:
                                    # Convert thumbnail URL to full-size image URL
                                    if "?format=" in src:
                                        src = src.split("?format=")[0] + "?format=jpg&name=large"
                                    image_urls.append(src)
                            
                            if image_urls:
                                post_data["image_urls"] = image_urls
                                post_data["has_media"] = True
                        except Exception as e:
                            logger.error(f"Error extracting images: {e}")
                        
                        # Get tweet ID and URL
                        status_link = await tweet.query_selector("a[href*='/status/']")
                        if status_link:
                            href = await status_link.get_attribute("href")
                            if href and '/status/' in href:
                                post_id = href.split('/status/')[1].split('/')[0]
                                post_data["id"] = post_id
                                post_data["url"] = f"https://x.com/{username}/status/{post_id}"
                        
                        # Get metrics with multiple selectors
                        metrics = {}
                        for metric_type in ['reply', 'retweet', 'like']:
                            try:
                                metric_element = await tweet.query_selector(f"[data-testid='{metric_type}']")
                                if metric_element:
                                    metric_text = await metric_element.inner_text()
                                    try:
                                        # Convert metric text to number
                                        if metric_text:
                                            if 'K' in metric_text:
                                                metrics[metric_type] = int(float(metric_text.replace('K', '')) * 1000)
                                            elif 'M' in metric_text:
                                                metrics[metric_type] = int(float(metric_text.replace('M', '')) * 1000000)
                                            else:
                                                metrics[metric_type] = int(metric_text)
                                    except ValueError:
                                        logger.debug(f"Could not parse metric value: {metric_text}")
                            except Exception as e:
                                logger.debug(f"Error getting {metric_type} metric: {e}")
                        
                        if metrics:
                            post_data["metrics"] = metrics
                        
                        account_posts.append(post_data)
                        logger.info(f"Added post {i+1} from {username}")
                        
                    except Exception as e:
                        logger.error(f"Error processing tweet {i+1} from {username}: {e}")
                
                # Add posts if we have enough
                if len(account_posts) >= min_posts:
                    posts.extend(account_posts)
                    logger.info(f"Added {len(account_posts)} posts from {username}")
                
            except Exception as e:
                logger.error(f"Error processing account {username}: {e}")
            
            # Small delay between accounts
            await page.wait_for_timeout(2000)
        
        logger.info(f"Completed fetch from following accounts. Processed {following_processed} accounts, collected {len(posts)} posts")
        return posts
        
    except Exception as e:
        logger.error(f"Error in fetch_following_recent_posts: {e}")
        return posts

async def extract_logged_in_username(page: Page) -> Optional[str]:
    """Extract username of logged in account"""
    try:
        # Try different methods to get username
        selectors = [
            "a[data-testid='AppTabBar_Profile_Link']",
            "a[data-testid='SideNav_NewTweet_Button']",
            "[data-testid='UserCell']"
        ]
        
        for selector in selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=5000)
                if element:
                    if selector == "a[data-testid='AppTabBar_Profile_Link']":
                        href = await element.get_attribute("href")
                        if href:
                            return href.split("/")[-1]
                    else:
                        text = await element.inner_text()
                        if "@" in text:
                            return text.split("@")[1].split()[0]
            except:
                continue
        
        return None
    
    except Exception as e:
        logger.error(f"Error extracting username: {e}")
        return None

async def extract_post_time(post_element) -> Tuple[str, str]:
    """
    Extract and format post timestamp
    Returns tuple of (readable_time, raw_time)
    """
    try:
        # Try multiple selectors for time element
        time_selectors = [
            'time[datetime]',
            'a[href*="/status/"] time',
            'span[data-testid="post-time"]'
        ]
        
        for selector in time_selectors:
            time_element = await post_element.query_selector(selector)
            if time_element:
                # Get datetime attribute and text content
                datetime_attr = await time_element.get_attribute('datetime')
                time_text = await time_element.inner_text()
                
                if datetime_attr:
                    try:
                        # Parse the ISO timestamp
                        dt = datetime.fromisoformat(datetime_attr.replace('Z', '+00:00'))
                        # Convert to local time
                        local_dt = dt.astimezone()
                        
                        # Format readable time
                        readable_time = local_dt.strftime("%Y-%m-%d %H:%M:%S")
                        raw_time = datetime_attr
                        
                        return readable_time, raw_time
                    except Exception as e:
                        logger.error(f"Error parsing datetime: {e}")
                
                # Fallback to displayed time text
                if time_text:
                    return time_text, time_text
        
        return "Unknown time", ""
    except Exception as e:
        logger.error(f"Error extracting post time: {e}")
        return "Unknown time", ""

async def extract_post_info(post_element) -> Dict:
    """Extract all information from a post element"""
    try:
        # Get post text
        text_element = await post_element.query_selector('div[data-testid="tweetText"]')
        text = await text_element.inner_text() if text_element else "No content"
        
        # Get post ID from the link
        post_id = ""
        link_element = await post_element.query_selector('a[href*="/status/"]')
        if link_element:
            href = await link_element.get_attribute('href')
            if href:
                post_id = href.split('/status/')[-1].split('?')[0]
        
        # Get author info
        author = "Unknown"
        display_name = "Unknown"
        author_element = await post_element.query_selector('div[data-testid="User-Name"]')
        if author_element:
            # Get display name
            name_element = await author_element.query_selector('span')
            if name_element:
                display_name = await name_element.inner_text()
            
            # Get username
            username_element = await author_element.query_selector('div[dir="ltr"]')
            if username_element:
                author = (await username_element.inner_text()).strip('@')
        
        # Get post time
        readable_time, raw_time = await extract_post_time(post_element)
        
        # Get metrics
        metrics = {}
        metric_selectors = {
            'reply': 'div[data-testid="reply"]',
            'retweet': 'div[data-testid="retweet"]',
            'like': 'div[data-testid="like"]'
        }
        
        for metric_type, selector in metric_selectors.items():
            try:
                metric_element = await post_element.query_selector(selector)
                if metric_element:
                    metric_text = await metric_element.inner_text()
                    if metric_text:
                        metrics[metric_type] = metric_text
            except Exception as e:
                logger.debug(f"Error getting {metric_type} metric: {e}")
        
        # Get image URLs
        image_urls = []
        try:
            image_elements = await post_element.query_selector_all('img[alt="Image"]')
            for img in image_elements:
                src = await img.get_attribute('src')
                if src and 'profile' not in src.lower():  # Skip profile pictures
                    image_urls.append(src)
        except Exception as e:
            logger.debug(f"Error getting images: {e}")
        
        return {
            "id": post_id,
            "text": text,
            "author": author,
            "display_name": display_name,
            "date": raw_time,
            "readable_time": readable_time,
            "metrics": metrics,
            "image_urls": image_urls,
            "has_media": len(image_urls) > 0
        }
    except Exception as e:
        logger.error(f"Error extracting post info: {e}")
        return {}

async def get_following_count(page, username):
    """
    Get the number of accounts a user follows
    Args:
        page: Playwright page object
        username: Twitter username to get following count for
    Returns:
        int: Number of accounts followed, or None if count cannot be determined
    """
    logger.info(f"Getting following count for @{username}")
    
    try:
        # Navigate to following page with x.com URL
        url = f"https://x.com/{username}/following"
        logger.info(f"Navigating to {url}")
        
        # Navigate with error handling
        try:
            response = await page.goto(url, timeout=30000, wait_until="domcontentloaded")
            if not response:
                logger.error("Navigation failed - no response")
                return None
            if response.status >= 400:
                logger.error(f"Navigation failed with status {response.status}")
                return None
        except Exception as e:
            logger.error(f"Navigation error: {e}")
            return None
            
        # Wait for page to stabilize
        try:
            await page.wait_for_load_state("networkidle", timeout=10000)
        except Exception as e:
            logger.warning(f"Network idle wait failed: {e}")
            
        await page.wait_for_timeout(5000)  # Initial wait
        
        # Try multiple selectors for following count
        count_selectors = [
            'a[href*="/following"] span',
            '[data-testid="followingCount"] span',
            'a[href$="/following"] div span span',
            'div[role="button"] span span',
            'div[role="tablist"] div span span',
            'div[role="tab"]:has-text("Following") span span',
            'div[role="tab"] span span'
        ]
        
        for selector in count_selectors:
            try:
                following_stats = await page.query_selector(selector)
                if following_stats:
                    following_text = await following_stats.inner_text()
                    if following_text:
                        # Convert text like "1,234" to number
                        clean_text = ''.join(c for c in following_text if c.isdigit())
                        if clean_text:
                            following_count = int(clean_text)
                            logger.info(f"Found following count: {following_count}")
                            return following_count
            except Exception:
                continue
                
        logger.warning("Could not determine following count")
        return None
                
    except Exception as e:
        logger.error(f"Error getting following count: {e}")
        return None
