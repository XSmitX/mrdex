"""
CronJob Action Handlers
Contains async helpers for handling cron-related callback queries.
"""

from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from pymongo.errors import PyMongoError
import asyncio
from datetime import datetime




# Import or expect these to be injected or imported as needed
# from bot import db, Config, logger, get_cronjob_accounts, fetch_cronjob_posts, format_post_for_channel, remove_cronjob_account
# TODO: Pass in db, Config, logger, and helper functions from bot.py when registering the handler

async def handle_cron_actions(client, callback_query, *, db, Config, logger, user_sessions, user_states, get_cronjob_accounts, fetch_cronjob_posts, format_post_for_channel, remove_cronjob_account):
    """Handler for all cron-related callback queries (to be registered in bot.py)"""
    user_id = callback_query.from_user.id
    action = callback_query.data
    
    # Check if user has an active session
    if user_id not in user_sessions:
        await callback_query.message.edit_text(
            "⚠️ Your session has expired. Please start again with /start"
        )
        return
    
    session = user_sessions[user_id]
    
    # Add account
    if action == "cron_add":
        await callback_query.answer()
        await client.send_message(
            user_id, 
            "Please send the Twitter username or profile URL of the account you want to track.\n\n"
            "Examples:\n"
            "- username\n"
            "- @username\n"
            "- https://twitter.com/username\n"
            "- https://x.com/username"
        )
        
        # Set the user state to wait for the username
        user_states[user_id] = "waiting_for_cron_username"
    
    # List accounts
    elif action == "cron_list":
        await callback_query.answer()
        
        # Get all tracked accounts for this user only
        accounts = await get_cronjob_accounts(db, Config, logger, user_id=user_id)
        
        if not accounts:
            await callback_query.message.edit_text(
                "You don't have any Twitter accounts being tracked.\nUse 'Add Twitter Account' to start tracking accounts.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Cron Menu", callback_data="cron_menu")]])
            )
            return
        
        # Create a message with all accounts
        message = "📋 Your Tracked Twitter Accounts:\n\n"
        
        # Try to fetch account details from the database
        try:
            for idx, account_item in enumerate(accounts, 1):
                # Extract username from the account item
                if isinstance(account_item, str):
                    username = account_item
                elif isinstance(account_item, dict) and "twitter_username" in account_item:
                    username = account_item["twitter_username"]
                    if not isinstance(username, str):
                        logger.warning(f"Invalid username type in document: {type(username)}")
                        continue
                else:
                    logger.warning(f"Invalid account format: {account_item}")
                    continue
                
                # Get account details
                last_fetch = "Never"
                fetch_count = 0
                if isinstance(account_item, dict):
                    if "last_fetch" in account_item and account_item["last_fetch"]:
                        last_fetch = account_item["last_fetch"].strftime("%Y-%m-%d %H:%M:%S")
                    if "fetch_count" in account_item:
                        fetch_count = account_item["fetch_count"]
                
                message += f"{idx}. @{username}\n   Last fetch: {last_fetch}\n   Fetch count: {fetch_count}\n\n"
        except Exception as e:
            logger.error(f"Error fetching account details: {e}")
            message += "Error fetching detailed account information."
        
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("Remove Account", callback_data="cron_remove")],
            [InlineKeyboardButton("Back to Cron Menu", callback_data="cron_menu")]
        ])
        await callback_query.message.edit_text(message, reply_markup=keyboard)
    
    # Fetch posts
    elif action == "cron_fetch":
        await callback_query.answer("Starting fetch process...")
        
        # Get active session
        active_account = None
        if "active" in user_sessions[user_id]:
            active_account = user_sessions[user_id]["active"]
            
        if not session or not active_account:
            await callback_query.message.edit_text(
                "⚠️ No active Twitter account. Please add or select an account first.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Cron Menu", callback_data="cron_menu")]])
            )
            return
            
        # Get the active session object
        active_session = None
        if "accounts" in user_sessions[user_id] and active_account in user_sessions[user_id]["accounts"]:
            active_session = user_sessions[user_id]["accounts"][active_account]
        
        if not active_session or not hasattr(active_session, 'page') or not active_session.page:
            await callback_query.message.edit_text(
                "⚠️ Browser session not initialized. Please start again with /start",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Cron Menu", callback_data="cron_menu")]])
            )
            return
        
        # Get user's tracked accounts
        accounts = await get_cronjob_accounts(db, Config, logger, user_id=user_id)
        if not accounts:
            await callback_query.message.edit_text(
                "You don't have any Twitter accounts being tracked.\nUse 'Add Twitter Account' to start tracking accounts.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Cron Menu", callback_data="cron_menu")]])
            )
            return
        
        status_message = await callback_query.message.edit_text(
            f"⏳ Fetching {Config.CRON_MAX_POSTS_PER_ACCOUNT} recent non-pinned posts from {len(accounts)} Twitter accounts...\nThis may take a while."
        )
        
        # Extract usernames from account objects
        usernames = []
        for account_item in accounts:
            if isinstance(account_item, str):
                usernames.append(account_item)
            elif isinstance(account_item, dict) and "twitter_username" in account_item:
                username = account_item["twitter_username"]
                if isinstance(username, str):
                    usernames.append(username)
        
        account_posts = await fetch_cronjob_posts(active_session, usernames, db, Config, logger)
        if not account_posts:
            await status_message.edit_text(
                "No posts were found from your tracked accounts.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Cron Menu", callback_data="cron_menu")]])
            )
            return
        
        total_posts = sum(len(acc["posts"]) for acc in account_posts)
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("View Posts", callback_data="cron_view_posts")],
            [InlineKeyboardButton("Back to Cron Menu", callback_data="cron_menu")]
        ])
        
        await status_message.edit_text(
            f"✅ Successfully fetched {total_posts} recent non-pinned posts from {len(account_posts)} accounts.",
            reply_markup=keyboard
        )
    
    # View posts
    elif action == "cron_view_posts":
        await callback_query.answer()
        try:
            recent_posts = list(db[Config.POSTS_COLLECTION].find({}, sort=[("stored_at", -1)], limit=20))
            logger.info(f"Found {len(recent_posts)} recent posts in database")
        except PyMongoError as e:
            logger.error(f"MongoDB error when fetching recent posts: {e}")
            await callback_query.message.edit_text(
                "Error fetching posts from database.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Cron Menu", callback_data="cron_menu")]])
            )
            return
        if not recent_posts:
            await callback_query.message.edit_text(
                "No recent posts found in the database.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Cron Menu", callback_data="cron_menu")]])
            )
            return
        posts_by_author = {}
        for post in recent_posts:
            author = post.get("author", "Unknown")
            if author not in posts_by_author:
                posts_by_author[author] = []
            posts_by_author[author].append(post)
        message = "📊 Recent posts by author:\n\n"
        for author, posts in posts_by_author.items():
            message += f"@{author}: {len(posts)} posts\n"
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("Send to Channel", callback_data="cron_send_to_channel")],
            [InlineKeyboardButton("Back to Cron Menu", callback_data="cron_menu")]
        ])
        await callback_query.message.edit_text(message, reply_markup=keyboard)
    
    # Remove account
    elif action == "cron_remove":
        await callback_query.answer()
        accounts = await get_cronjob_accounts(db, Config, logger, user_id=user_id)
        if not accounts:
            await callback_query.message.edit_text(
                "You don't have any Twitter accounts being tracked.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Cron Menu", callback_data="cron_menu")]])
            )
            return
        buttons = []
        for account_item in accounts:
            # Extract username from the account item
            if isinstance(account_item, str):
                username = account_item
            elif isinstance(account_item, dict) and "twitter_username" in account_item:
                username = account_item["twitter_username"]
                if not isinstance(username, str):
                    logger.warning(f"Invalid username type in document: {type(username)}")
                    continue
            else:
                logger.warning(f"Invalid account format: {account_item}")
                continue
                
            buttons.append([
                InlineKeyboardButton(f"@{username}", callback_data=f"cron_remove_{username}")
            ])
        buttons.append([InlineKeyboardButton("Cancel", callback_data="cron_menu")])
        keyboard = InlineKeyboardMarkup(buttons)
        await callback_query.message.edit_text(
            "Select a Twitter account to remove from tracking:",
            reply_markup=keyboard
        )
    
    # Send to channel
    elif action == "cron_send_to_channel":
        await callback_query.answer("Starting to send posts to channel...")
        try:
            # Get appropriate collection based on user_id
            collection_name = Config.POSTS_COLLECTION
            if user_id is not None:
                try:
                    from bot import get_user_db_collections
                    collections = get_user_db_collections(user_id)
                    collection_name = collections["posts"]
                    logger.info(f"Using user-specific posts collection: {collection_name}")
                except ImportError:
                    logger.warning("Could not import get_user_db_collections, using default collection")
            
            if db is None:
                await callback_query.message.edit_text(
                    "Database connection is not available.",
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Cron Menu", callback_data="cron_menu")]])
                )
                return
                
            posts_collection = db[collection_name]
            total_posts = posts_collection.count_documents({})
            status_message = await callback_query.message.edit_text(
                f"Found {total_posts} total posts in database"
            )
            recent_posts = list(posts_collection.find({"sent_to_channel": False}, sort=[("stored_at", -1)], limit=20))
            already_sent = posts_collection.count_documents({"sent_to_channel": True})
            no_field = posts_collection.count_documents({"sent_to_channel": {"$exists": False}})
            
            await status_message.edit_text(
                f"Found {len(recent_posts)} posts to send\n"
                f"Already sent: {already_sent}\n"
                f"Missing field: {no_field}\n"
                f"Total posts: {total_posts}"
            )
            
            logger.info(f"Found {len(recent_posts)} unsent posts to send to channel")
        except PyMongoError as e:
            logger.error(f"MongoDB error when fetching recent posts: {e}")
            await callback_query.message.edit_text(
                f"Error fetching posts from database: {str(e)}",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Cron Menu", callback_data="cron_menu")]])
            )
            return
            
        if not recent_posts:
            if no_field > 0:
                try:
                    result = posts_collection.update_many(
                        {"sent_to_channel": {"$exists": False}}, 
                        {"$set": {"sent_to_channel": False}}
                    )
                    await status_message.edit_text(
                        f"Updated {result.modified_count} posts to set sent_to_channel=False\nPlease try sending posts again.",
                        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Cron Menu", callback_data="cron_menu")]])
                    )
                    return
                except PyMongoError as e:
                    logger.error(f"Error updating posts: {e}")
                    
            await status_message.edit_text(
                "No new posts to send to the channel.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Cron Menu", callback_data="cron_menu")]])
            )
            return
            
        await status_message.edit_text(
            f"Sending {len(recent_posts)} posts to channel..."
        )
        
        for i, post in enumerate(recent_posts[:5]):
            try:
                logger.info(f"Post {i+1}: ID={post.get('id')}, Author={post.get('author')}")
            except Exception as e:
                logger.error(f"Error logging post info: {e}")
                
        sent_count = 0
        for post in recent_posts:
            try:
                message = format_post_for_channel(post)
                keyboard = InlineKeyboardMarkup([
                    [InlineKeyboardButton("🤖 Generate Script with AI", callback_data="generate_content")]
                ])
                
                await client.send_message(
                    chat_id=Config.CHANNEL_ID, 
                    text=message, 
                    disable_web_page_preview=False, 
                    reply_markup=keyboard
                )
                
                if "_id" in post:
                    posts_collection.update_one(
                        {"_id": post["_id"]}, 
                        {"$set": {
                            "sent_to_channel": True,
                            "sent_at": datetime.now()
                        }}
                    )
                    
                sent_count += 1
                # Add delay to avoid flooding
                await asyncio.sleep(1)
                
            except Exception as e:
                logger.error(f"Error sending post to channel: {e}")
                
        keyboard = InlineKeyboardMarkup([[InlineKeyboardButton("Back to Cron Menu", callback_data="cron_menu")]])
        await status_message.edit_text(
            f"✅ Successfully sent {sent_count} posts to channel.",
            reply_markup=keyboard
        )
    
    # Menu
    elif action == "cron_menu":
        await callback_query.answer()
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("Add Twitter Account", callback_data="cron_add")],
            [InlineKeyboardButton("List Tracked Accounts", callback_data="cron_list")],
            [InlineKeyboardButton("Back to Main Menu", callback_data="back_to_menu")]
        ])
        await callback_query.message.edit_text(
            "Twitter Account Tracking Management:",
            reply_markup=keyboard
        )
    
    # Handle account removal
    elif action.startswith("cron_remove_"):
        await callback_query.answer()
        username = action.replace("cron_remove_", "")
        success = await remove_cronjob_account(username, db, Config, logger, user_id=user_id)
        message = f"✅ Removed @{username} from tracking." if success else f"❌ Failed to remove @{username} from tracking."
        keyboard = InlineKeyboardMarkup([[InlineKeyboardButton("Back to Cron Menu", callback_data="cron_menu")]])
        await callback_query.message.edit_text(message, reply_markup=keyboard)

async def remove_cronjob_account(username, db, Config, logger, user_id=None):
    """Remove a Twitter account from the CronJob collection"""
    try:
        if db is None:
            logger.error("MongoDB connection not initialized")
            return False
        # Clean username (remove @ if present)
        if username.startswith('@'):
            username = username[1:]
        result = db[Config.CRONJOB_COLLECTION].delete_one({"username": username})
        if result.deleted_count > 0:
            logger.info(f"Removed CronJob account: {username}")
            return True
        else:
            logger.warning(f"CronJob account not found: {username}")
            return False
    except PyMongoError as e:
        logger.error(f"MongoDB error when removing CronJob account: {e}")
        return False

async def add_cronjob_account(username, db, Config, logger):
    """Add a Twitter account to the CronJob collection"""
    try:
        if db is None:
            logger.error("MongoDB connection not initialized")
            return False
        # Clean username (remove @ if present)
        if username.startswith('@'):
            username = username[1:]
        account_data = {
            "username": username,
            "active": True,
            "added_at": datetime.now(),
            "last_fetch": None,
            "fetch_count": 0
        }
        result = db[Config.CRONJOB_COLLECTION].update_one(
            {"username": username},
            {"$set": account_data},
            upsert=True
        )
        if result.upserted_id:
            logger.info(f"Added new CronJob account: {username}")
        else:
            logger.info(f"Updated existing CronJob account: {username}")
        return True
    except PyMongoError as e:
        logger.error(f"MongoDB error when adding CronJob account: {e}")
        return False

async def get_cronjob_accounts(db, Config, logger, user_id=None, account_username=None):
    """Get all cronjob accounts, optionally filtered by user_id and account_username"""
    try:
        if db is None:
            logger.error("Database connection not available")
            return []
            
        # Build query
        query = {"active": True}
        if user_id is not None:
            query["user_id"] = user_id
        if account_username is not None:
            query["account_username"] = account_username
            
        # Get appropriate collection based on user_id
        collection_name = Config.CRONJOB_COLLECTION
        if user_id is not None:
            # Import the function to get user-specific collections
            # Note: This is to avoid circular imports
            try:
                # Use relative import with proper path setup
                import sys
                import os
                # Get the absolute path of the current file's directory
                current_dir = os.path.dirname(os.path.abspath(__file__))
                # Get the parent directory
                parent_dir = os.path.dirname(current_dir)
                # Add parent directory to path if not already there
                if parent_dir not in sys.path:
                    sys.path.insert(0, parent_dir)
                
                # Now import from bot
                from bot import get_user_db_collections
                collections = get_user_db_collections(user_id)
                collection_name = collections["cronjob"]
                logger.info(f"Using user-specific cronjob collection: {collection_name}")
            except ImportError as e:
                logger.warning(f"Could not import get_user_db_collections: {e}, using default collection")
        
        # Get all active cronjob accounts from the appropriate collection
        accounts = list(db[collection_name].find(query))
        
        if accounts:
            logger.info(f"Found {len(accounts)} active cronjob accounts for user {user_id if user_id else 'global'}")
        else:
            logger.info(f"No cronjob accounts configured for user {user_id if user_id else 'global'}")
            
        return accounts
        
    except Exception as e:
        logger.error(f"Error in get_cronjob_accounts: {e}")
        return []

async def fetch_cronjob_posts(session, cron_accounts, db, Config, logger, max_posts_per_account=5):
    """Fetch posts from all CronJob accounts"""
    all_posts = []
    account_posts = []
    from datetime import datetime
    for username in cron_accounts:
        try:
            # Ensure username is a string
            if not isinstance(username, str):
                logger.warning(f"Invalid username format: {username}")
                continue
            logger.info(f"Fetching {Config.CRON_MAX_POSTS_PER_ACCOUNT} recent non-pinned posts for CronJob account: @{username}")
            # Use the default CRON_MAX_POSTS_PER_ACCOUNT setting or the provided parameter
            posts_to_fetch = Config.CRON_MAX_POSTS_PER_ACCOUNT if max_posts_per_account is None else max_posts_per_account
            # fetch_account_posts must be imported or injected from bot.py
            posts = await session.fetch_account_posts(session.page, username, max_posts=posts_to_fetch) if hasattr(session, 'fetch_account_posts') else []
            if posts:
                # Update last fetch time in the database
                try:
                    if db is not None:
                        db[Config.CRONJOB_COLLECTION].update_one(
                            {"username": username},
                            {
                                "$set": {"last_fetch": datetime.now()},
                                "$inc": {"fetch_count": 1}
                            }
                        )
                except Exception as e:
                    logger.error(f"Error updating CronJob account stats: {e}")
                # Add to the results
                all_posts.extend(posts)
                account_posts.append({
                    "username": username,
                    "name": username,  # We don't have the display name here
                    "posts": posts
                })
        except Exception as e:
            logger.error(f"Error fetching posts for @{username}: {e}")
    # Store all posts in the database
    if all_posts:
        if hasattr(session, 'store_posts_in_db'):
            await session.store_posts_in_db(all_posts, "cronjob")
    return account_posts

async def scheduled_cronjob_task(db, Config, logger, user_sessions, get_cronjob_accounts, fetch_account_posts, store_posts_in_db, send_posts_to_channel, format_post_for_channel, cleanup_global_browser, initialize_global_browser, bot):
    """Run the scheduled cronjob task to fetch posts from accounts (refactored for utils/cronjob.py)"""
    # These should be managed at a higher level or passed in
    global _CRON_RUNNING, _LAST_CRON_START
    import time
    import asyncio
    _CRON_RUNNING = getattr(scheduled_cronjob_task, '_CRON_RUNNING', False)
    _LAST_CRON_START = getattr(scheduled_cronjob_task, '_LAST_CRON_START', 0)
    try:
        if _CRON_RUNNING:
            logger.info("Cron task already running, skipping this run")
            return
        current_time = int(time.time())
        if current_time - _LAST_CRON_START < 60:
            logger.info("Cron task ran too recently, throttling")
            return
        _CRON_RUNNING = True
        _LAST_CRON_START = current_time
        logger.info("Starting scheduled CronJob task")
        if not Config.CRON_ENABLED:
            logger.info("CronJob is disabled in config")
            _CRON_RUNNING = False
            return
        # Get shared browser instance
        if hasattr(Config, 'SHARED_SESSION_ID') and Config.SHARED_SESSION_ID:
            logger.info(f"Using shared browser session from user {Config.SHARED_SESSION_ID}")
            # Handle both multi-account and single-account structures
            if Config.SHARED_SESSION_ID in user_sessions:
                user_data = user_sessions[Config.SHARED_SESSION_ID]
                
                # Check if this is the new multi-account structure
                if isinstance(user_data, dict) and "active" in user_data and "accounts" in user_data:
                    active_account = user_data["active"]
                    if active_account and active_account in user_data["accounts"]:
                        session = user_data["accounts"][active_account]
                        if hasattr(session, 'page') and session.page:
                            Config.GLOBAL_PAGE = session.page
                            logger.info(f"Successfully retrieved page from shared user session (account: @{active_account})")
                        else:
                            logger.warning(f"Active account @{active_account} has no valid page")
                    else:
                        logger.warning(f"No active account found for user {Config.SHARED_SESSION_ID}")
                
                # Check if this is the old single-account structure
                elif hasattr(user_data, 'page') and user_data.page:
                    # This is a UserSession object directly
                    Config.GLOBAL_PAGE = user_data.page
                    logger.info(f"Successfully retrieved page from shared user session (single account)")
                else:
                    logger.warning(f"Unsupported session structure for user {Config.SHARED_SESSION_ID}")
            
            page = getattr(Config, 'GLOBAL_PAGE', None)
            if not page:
                logger.error("No shared browser page available, initializing a new one")
                await initialize_global_browser()
                page = getattr(Config, 'GLOBAL_PAGE', None)
                if not page:
                    logger.error("Failed to initialize fallback browser, aborting cron task")
                    _CRON_RUNNING = False
                    return
        else:
            if not getattr(Config, 'GLOBAL_BROWSER', None):
                logger.info("Initializing global browser for CronJob")
                await initialize_global_browser()
            if not getattr(Config, 'GLOBAL_PAGE', None):
                logger.error("Failed to initialize global browser")
                _CRON_RUNNING = False
                return
            page = Config.GLOBAL_PAGE
        
        client = bot
        if not client:
            logger.error("Could not get bot client")
            _CRON_RUNNING = False
            return
        
        else:
            logger.warning("No channel ID configured, posts will not be sent to any channel")
        cron_accounts = await get_cronjob_accounts(db, Config, logger)
        if not cron_accounts:
            logger.info("No cronjob accounts configured")
            _CRON_RUNNING = False
            return
        logger.info(f"Scheduled task found {len(cron_accounts)} active CronJob accounts")
        all_posts = []
        for account_item in cron_accounts:
            try:
                # Extract username from the account item (could be a string or a document)
                if isinstance(account_item, str):
                    username = account_item
                elif isinstance(account_item, dict) and "twitter_username" in account_item:
                    username = account_item["twitter_username"]
                    if not isinstance(username, str):
                        logger.warning(f"Invalid username type in document: {type(username)}")
                        continue
                else:
                    logger.warning(f"Invalid account format: {account_item}")
                    continue
                
                logger.info(f"Fetching posts for @{username}")
                account_posts = await fetch_account_posts(page, username, max_posts=Config.CRON_MAX_POSTS_PER_ACCOUNT)
                if account_posts:
                    logger.info(f"Fetched {len(account_posts)} posts from @{username}")
                    new_posts = await store_posts_in_db(account_posts, username)
                    if new_posts:
                        logger.info(f"Stored {len(new_posts)} new posts from @{username}")
                        all_posts.extend(new_posts)
                    else:
                        logger.info(f"All posts were duplicates, nothing new to store")
                else:
                    logger.info(f"No posts found for @{username}")
            except Exception as e:
                logger.error(f"Error fetching posts from account: {e}")
            await asyncio.sleep(5)
        logger.info(f"Found total of {len(all_posts)} new posts across all accounts")
        if all_posts and Config.CHANNEL_ID:
            try:
                test_result = False
                try:
                    await client.send_message(Config.CHANNEL_ID, "⚙️ Test message - please ignore", disable_notification=True)
                    test_result = True
                except Exception as test_e:
                    logger.error(f"Test message to channel failed: {test_e}")
                if test_result:
                    logger.info(f"Sending {len(all_posts)} posts to channel {Config.CHANNEL_ID}")
                    await send_posts_to_channel(client, all_posts, db, Config, logger, format_post_for_channel)
                    logger.info(f"Successfully sent posts to channel")
                else:
                    logger.error(f"Cannot send posts to channel due to failed test message")
            except Exception as e:
                logger.error(f"Error sending posts to channel: {e}")
        elif Config.CHANNEL_ID:
            logger.info(f"No new posts to send to channel")
        else:
            logger.warning(f"Channel ID not configured, skipping post sending")
        try:
            if Config.CHANNEL_ID:
                logger.info("Fetching following counts")
            else:
                logger.warning("Channel ID not configured, skipping following count updates")
        except Exception as e:
            logger.error(f"Error fetching following counts: {e}")
        logger.info(f"Scheduled task completed. Waiting {Config.CRON_FETCH_INTERVAL} minutes for next run.")
    except Exception as e:
        logger.error(f"Error in scheduled task: {e}")
    finally:
        _CRON_RUNNING = False
        try:
            wait_time = Config.CRON_FETCH_INTERVAL * 60
            logger.info(f"Scheduling next cron run in {wait_time} seconds")
            asyncio.create_task(_schedule_next_cron_run(wait_time, db, Config, logger, user_sessions, get_cronjob_accounts, fetch_account_posts, store_posts_in_db, send_posts_to_channel, format_post_for_channel, cleanup_global_browser, initialize_global_browser, bot))
        except Exception as e:
            logger.error(f"Error scheduling next cron run: {e}")

async def _schedule_next_cron_run(wait_time, db, Config, logger, user_sessions, get_cronjob_accounts, fetch_account_posts, store_posts_in_db, send_posts_to_channel, format_post_for_channel, cleanup_global_browser, initialize_global_browser, bot):
    """Helper function to schedule the next cron run after waiting (refactored for utils/cronjob.py)"""
    import asyncio
    try:
        await asyncio.sleep(wait_time)
        asyncio.create_task(scheduled_cronjob_task(db, Config, logger, user_sessions, get_cronjob_accounts, fetch_account_posts, store_posts_in_db, send_posts_to_channel, format_post_for_channel, cleanup_global_browser, initialize_global_browser, bot))
    except Exception as e:
        logger.error(f"Error in _schedule_next_cron_run: {e}")
        await asyncio.sleep(60)
        asyncio.create_task(scheduled_cronjob_task(db, Config, logger, user_sessions, get_cronjob_accounts, fetch_account_posts, store_posts_in_db, send_posts_to_channel, format_post_for_channel, cleanup_global_browser, initialize_global_browser, bot))

async def scheduled_user_cronjob_task(user_id, db, Config, logger, user_sessions, get_cronjob_accounts, fetch_account_posts, store_posts_in_db, send_posts_to_channel, format_post_for_channel, bot):
    """Run a dedicated cronjob task for a specific user with their own browser session"""
    # Track running state per user
    if not hasattr(scheduled_user_cronjob_task, '_USER_CRON_RUNNING'):
        scheduled_user_cronjob_task._USER_CRON_RUNNING = {}
    if not hasattr(scheduled_user_cronjob_task, '_USER_LAST_CRON_START'):
        scheduled_user_cronjob_task._USER_LAST_CRON_START = {}
    
    import time
    import asyncio
    
    # Get user-specific running state
    is_running = scheduled_user_cronjob_task._USER_CRON_RUNNING.get(user_id, False)
    last_start = scheduled_user_cronjob_task._USER_LAST_CRON_START.get(user_id, 0)
    
    try:
        if is_running:
            logger.info(f"User {user_id} cron task already running, skipping this run")
            return
            
        current_time = int(time.time())
        if current_time - last_start < 60:
            logger.info(f"User {user_id} cron task ran too recently, throttling")
            return
            
        # Mark as running
        scheduled_user_cronjob_task._USER_CRON_RUNNING[user_id] = True
        scheduled_user_cronjob_task._USER_LAST_CRON_START[user_id] = current_time
        
        logger.info(f"Starting user-specific CronJob task for user {user_id}")
        
        if not Config.CRON_ENABLED:
            logger.info("CronJob is disabled in config")
            scheduled_user_cronjob_task._USER_CRON_RUNNING[user_id] = False
            return
        
        # Try to import user collection helper
        user_collections = None
        try:
            from bot import get_user_db_collections
            user_collections = get_user_db_collections(user_id)
            logger.info(f"Using user-specific collections for user {user_id}")
        except ImportError:
            logger.warning("Could not import get_user_db_collections, using default collections")
        
        # Get user's browser session
        if user_id not in user_sessions:
            logger.error(f"No session found for user {user_id}")
            scheduled_user_cronjob_task._USER_CRON_RUNNING[user_id] = False
            return
            
        user_data = user_sessions[user_id]
        page = None
        
        # Handle both multi-account and single-account structures
        if isinstance(user_data, dict) and "active" in user_data and "accounts" in user_data:
            active_account = user_data["active"]
            if active_account and active_account in user_data["accounts"]:
                session = user_data["accounts"][active_account]
                if hasattr(session, 'page') and session.page:
                    page = session.page
                    logger.info(f"Using browser session for user {user_id} (account: @{active_account})")
                else:
                    logger.warning(f"Active account @{active_account} for user {user_id} has no valid page")
            else:
                logger.warning(f"No active account found for user {user_id}")
        elif hasattr(user_data, 'page') and user_data.page:
            # Single account structure
            page = user_data.page
            logger.info(f"Using browser session for user {user_id} (single account)")
        
        if not page:
            logger.error(f"No valid browser page found for user {user_id}")
            scheduled_user_cronjob_task._USER_CRON_RUNNING[user_id] = False
            return
            
        client = bot
        if not client:
            logger.error("Could not get bot client")
            scheduled_user_cronjob_task._USER_CRON_RUNNING[user_id] = False
            return
            
        # Get only this user's tracked accounts
        cron_accounts = await get_cronjob_accounts(db, Config, logger, user_id=user_id)
        
        if not cron_accounts:
            logger.info(f"No cronjob accounts configured for user {user_id}")
            scheduled_user_cronjob_task._USER_CRON_RUNNING[user_id] = False
            return
            
        logger.info(f"Found {len(cron_accounts)} active CronJob accounts for user {user_id}")
        
        all_posts = []
        for account_item in cron_accounts:
            try:
                # Extract username from the account item
                if isinstance(account_item, str):
                    username = account_item
                elif isinstance(account_item, dict) and "twitter_username" in account_item:
                    username = account_item["twitter_username"]
                    if not isinstance(username, str):
                        logger.warning(f"Invalid username type in document: {type(username)}")
                        continue
                else:
                    logger.warning(f"Invalid account format: {account_item}")
                    continue
                    
                logger.info(f"User {user_id}: Fetching posts for @{username}")
                account_posts = await fetch_account_posts(page, username, max_posts=Config.CRON_MAX_POSTS_PER_ACCOUNT)
                
                if account_posts:
                    logger.info(f"User {user_id}: Fetched {len(account_posts)} posts from @{username}")
                    # Pass user_id to store_posts_in_db to use user-specific collection
                    new_posts = await store_posts_in_db(account_posts, username, user_id)
                    
                    if new_posts:
                        logger.info(f"User {user_id}: Stored {len(new_posts)} new posts from @{username}")
                        all_posts.extend(new_posts)
                    else:
                        logger.info(f"User {user_id}: All posts were duplicates, nothing new to store")
                else:
                    logger.info(f"User {user_id}: No posts found for @{username}")
            except Exception as e:
                logger.error(f"User {user_id}: Error fetching posts from account @{username}: {e}")
                
            # Add a small delay between accounts
            await asyncio.sleep(2)
            
        logger.info(f"User {user_id}: Found total of {len(all_posts)} new posts across all accounts")
        
        # Send notification to user about new posts
        if all_posts:
            try:
                await client.send_message(
                    chat_id=user_id,
                    text=f"✅ Your cron job has fetched {len(all_posts)} new posts from your tracked accounts."
                )
            except Exception as e:
                logger.error(f"Error sending notification to user {user_id}: {e}")
                
        # Send posts to channel if configured
        user_channel_id = None  # You could add per-user channel configuration
        
        if all_posts and (Config.CHANNEL_ID or user_channel_id):
            channel_id = user_channel_id or Config.CHANNEL_ID
            try:
                logger.info(f"User {user_id}: Sending {len(all_posts)} posts to channel {channel_id}")
                await send_posts_to_channel(client, all_posts, db, Config, logger, format_post_for_channel, user_id=user_id)
                logger.info(f"User {user_id}: Successfully sent posts to channel")
            except Exception as e:
                logger.error(f"User {user_id}: Error sending posts to channel: {e}")
                
        logger.info(f"User {user_id}: Scheduled task completed. Waiting {Config.CRON_FETCH_INTERVAL} minutes for next run.")
        
    except Exception as e:
        logger.error(f"Error in user {user_id} scheduled task: {e}")
    finally:
        scheduled_user_cronjob_task._USER_CRON_RUNNING[user_id] = False
        try:
            wait_time = Config.CRON_FETCH_INTERVAL * 60
            logger.info(f"Scheduling next cron run for user {user_id} in {wait_time} seconds")
            asyncio.create_task(_schedule_next_user_cron_run(wait_time, user_id, db, Config, logger, user_sessions, get_cronjob_accounts, fetch_account_posts, store_posts_in_db, send_posts_to_channel, format_post_for_channel, bot))
        except Exception as e:
            logger.error(f"Error scheduling next cron run for user {user_id}: {e}")

async def _schedule_next_user_cron_run(wait_time, user_id, db, Config, logger, user_sessions, get_cronjob_accounts, fetch_account_posts, store_posts_in_db, send_posts_to_channel, format_post_for_channel, bot):
    """Helper function to schedule the next cron run for a specific user"""
    import asyncio
    try:
        await asyncio.sleep(wait_time)
        # Check if user still exists in user_sessions before scheduling next run
        if user_id in user_sessions:
            asyncio.create_task(scheduled_user_cronjob_task(
                user_id, db, Config, logger, user_sessions, get_cronjob_accounts, 
                fetch_account_posts, store_posts_in_db, send_posts_to_channel, 
                format_post_for_channel, bot
            ))
        else:
            logger.info(f"User {user_id} no longer has an active session, stopping their cron task")
    except Exception as e:
        logger.error(f"Error in _schedule_next_user_cron_run for user {user_id}: {e}")
        await asyncio.sleep(60)
        if user_id in user_sessions:
            asyncio.create_task(scheduled_user_cronjob_task(
                user_id, db, Config, logger, user_sessions, get_cronjob_accounts, 
                fetch_account_posts, store_posts_in_db, send_posts_to_channel, 
                format_post_for_channel, bot
            )) 