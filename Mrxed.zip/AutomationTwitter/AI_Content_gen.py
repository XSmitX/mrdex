"""
AI Content Generation Helpers
Contains async wrappers and helpers for AI-based content generation.
"""

import asyncio
import threading
import queue
import logging
from utils.ai_helper import generate_content

async def generate_ai_content(text: str, prompt_type: str = "standard"):
    """Generate content using OpenAI via the helper module"""
    try:
        # Create a queue to get the result
        result_queue = queue.Queue()

        # Function to run in thread
        def thread_task():
            try:
                # Call the synchronous function
                result = generate_content(text, prompt_type)
                # Put the result in the queue
                result_queue.put(result)
            except Exception as e:
                # Put the exception in the queue
                result_queue.put(f"Error: {str(e)}")

        # Create and start the thread
        thread = threading.Thread(target=thread_task)
        thread.start()

        # Wait for the thread to complete (blocking, but in a way that doesn't affect asyncio)
        while thread.is_alive():
            await asyncio.sleep(0.1)

        # Get the result from the queue
        return result_queue.get()

    except Exception as e:
        logging.error(f"Error in generate_ai_content: {e}")
        return f"Error generating content: {str(e)}\n\nPlease try again later."
