"""
Browser Initialization Helpers
Contains async helpers for cleaning up and initializing Playwright browser sessions for users.
"""

from playwright.async_api import async_playwright
import asyncio
import os
import logging
import sys
from pathlib import Path

# Add the parent directory to sys.path to allow importing from bot.py
parent_dir = str(Path(__file__).parent)
if parent_dir not in sys.path:
    sys.path.append(parent_dir)

# Import UserSession class
try:
    # Try importing directly first
    from bot import UserSession
except ImportError:
    # Define a stub class as fallback if importBrowser initialized for user fails
    class UserSession:
        def __init__(self):
            self.state = "initial"
            self.username = None
            self.password = None
            self.cookie_file = None
            self.browser = None
            self.context = None
            self.page = None
            self.playwright = None
            self.last_activity = None

logger = logging.getLogger(__name__)

# TODO: Pass in user_sessions, Config, and logger from bot.py when calling these functions

async def cleanup_session(user_id: int, user_sessions, Config, logger):
    """Clean up browser resources for a user session"""
    try:
        # Cancel user's cron task if it exists
        if hasattr(Config, 'USER_CRON_TASKS') and user_id in Config.USER_CRON_TASKS:
            try:
                Config.USER_CRON_TASKS[user_id].cancel()
                Config.USER_CRON_TASKS.pop(user_id, None)
                logger.info(f"Cancelled cron task for user {user_id}")
            except Exception as e:
                logger.error(f"Error cancelling cron task for user {user_id}: {e}")
        
        # Check if user has a session
        if user_id in user_sessions:
            # Check if it's a pending session
            if isinstance(user_sessions[user_id], dict) and "_pending" in user_sessions[user_id]:
                session = user_sessions[user_id]["_pending"]
                
                try:
                    if hasattr(session, 'page') and session.page:
                        await session.page.close()
                    if hasattr(session, 'context') and session.context:
                        await session.context.close()
                    if hasattr(session, 'browser') and session.browser:
                        await session.browser.close()
                    if hasattr(session, 'playwright') and session.playwright:
                        await session.playwright.stop()
                except Exception as e:
                    logger.error(f"Error closing browser resources for pending session: {e}")
                
                # Remove the pending session
                user_sessions[user_id] = {}
                
            # Check if it's a regular session
            elif isinstance(user_sessions[user_id], UserSession):
                session = user_sessions[user_id]
                
                try:
                    if hasattr(session, 'page') and session.page:
                        await session.page.close()
                    if hasattr(session, 'context') and session.context:
                        await session.context.close()
                    if hasattr(session, 'browser') and session.browser:
                        await session.browser.close()
                    if hasattr(session, 'playwright') and session.playwright:
                        await session.playwright.stop()
                except Exception as e:
                    logger.error(f"Error closing browser resources for user session: {e}")
                
                # Remove the user session
                user_sessions.pop(user_id, None)
        
        # If this user's session is shared with cron job, stop sharing
        if hasattr(Config, 'SHARED_SESSION_ID') and Config.SHARED_SESSION_ID == user_id:
            Config.SHARED_SESSION_ID = None
            if hasattr(Config, 'GLOBAL_PAGE'):
                Config.GLOBAL_PAGE = None
            if hasattr(Config, 'GLOBAL_CONTEXT'):
                Config.GLOBAL_CONTEXT = None
            
        logger.info(f"Cleaned up session for user {user_id}")
        return True
        
    except Exception as e:
        logger.error(f"Error in cleanup_session: {e}")
        return False

async def initialize_browser(user_id: int, user_sessions, Config, logger) -> bool:
    """Initialize browser for a user session"""
    try:
        # Check if we're initializing a pending session or an active session
        if "_pending" in user_sessions[user_id]:
            # We're initializing a pending session for a new account
            session = user_sessions[user_id]["_pending"]
        else:
            # This shouldn't happen - we should always have a _pending session
            logger.error(f"No pending session found for user {user_id}")
            return False
        
        # Create Playwright instance
        session.playwright = await asyncio.wait_for(
            async_playwright().start(),
            timeout=30.0
        )
        
        # Launch browser
        session.browser = await asyncio.wait_for(
            session.playwright.chromium.launch(
                headless=True,
                args=[
                    "--disable-extensions",
                    "--disable-gpu",
                    "--no-sandbox",
                    "--disable-setuid-sandbox",
                    "--disable-dev-shm-usage",
                    "--disable-accelerated-2d-canvas",
                    "--no-first-run",
                    "--no-zygote",
                    "--disable-notifications"
                ]
            ),
            timeout=30.0
        )
        
        # Create context
        session.context = await asyncio.wait_for(
            session.browser.new_context(
                viewport={"width": 1280, "height": 800},
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36"
            ),
            timeout=15.0
        )
        
        # Create page
        session.page = await asyncio.wait_for(
            session.context.new_page(),
            timeout=15.0
        )
        
        # Set longer timeouts
        session.page.set_default_timeout(30000)  # 30 seconds
        session.page.set_default_navigation_timeout(60000)  # 60 seconds
        
        logger.info(f"Browser initialized for user {user_id}")
        return True
        
    except Exception as e:
        logger.error(f"Error starting playwright for user {user_id}: {e}")
        await cleanup_session(user_id, user_sessions, Config, logger)
        return False

async def cleanup_specific_account(user_id, twitter_username, user_sessions, Config, logger):
    """Clean up browser resources for a specific Twitter account"""
    try:
        if (user_id in user_sessions and 
            "accounts" in user_sessions[user_id] and 
            twitter_username in user_sessions[user_id]["accounts"]):
            
            session = user_sessions[user_id]["accounts"][twitter_username]
            
            try:
                if hasattr(session, 'page') and session.page:
                    await session.page.close()
                if hasattr(session, 'context') and session.context:
                    await session.context.close()
                if hasattr(session, 'browser') and session.browser:
                    await session.browser.close()
                if hasattr(session, 'playwright') and session.playwright:
                    await session.playwright.stop()
            except Exception as e:
                logger.error(f"Error closing browser resources for account @{twitter_username}: {e}")
            
            # Remove the account from the user's accounts
            user_sessions[user_id]["accounts"].pop(twitter_username, None)
            
            # If this was the active account, set another one as active
            if user_sessions[user_id]["active"] == twitter_username:
                user_sessions[user_id]["active"] = next(iter(user_sessions[user_id]["accounts"]), None)
            
            logger.info(f"Cleaned up session for account @{twitter_username} (User: {user_id})")
            return True
        
        return False
        
    except Exception as e:
        logger.error(f"Error in cleanup_specific_account: {e}")
        return False
