"""
ImageGen.py
Contains both consolidated and scene-by-scene image generation logic.
Extracted and merged from bot.py and SceneBySceneGen.py.
"""
import os
import logging
import asyncio
from openai import OpenAI
import re
from pyrogram.types import CallbackQuery
from pyrogram import Client


# The handle_scene_by_scene_generation function has been removed to fix syntax warnings

async def generate_consolidated_image(script_text, chat_id, client, message, prompt_prefix="", quiet=False):
    """Generate a single detailed image from the entire script using enhanced GPT-4 prompting
    
    Args:
        script_text (str): The script text to generate an image from
        chat_id (int): The chat ID to send the image to
        client (Client): The Pyrogram client
        message: The message object to reply to with status updates
        prompt_prefix (str, optional): Optional prefix to add to the prompt
        quiet (bool, optional): If True, will not send status messages
        
    Returns:
        str: The URL of the generated image, or False if generation failed
    """
    try:
        if not script_text:
            raise ValueError("No script text provided")

        # Create user directory if it doesn't exist
        user_dir = f"user_images/{str(client.me.id)}"
        os.makedirs(user_dir, exist_ok=True)

        status_message = None
        if not quiet:
            # Create a status message
            status_message = await message.reply("🎨 Creating your consolidated image...")

        try:
            from openai import OpenAI
            import re
            client_ai = OpenAI()

            if status_message and not quiet:
                await status_message.edit_text("🎨 Analyzing your script and creating a visual prompt...")

            system_prompt = """You are a visual script analyzer. Extract key visual elements and context from the script scene.\nFocus on:\n1. Setting/Location\n2. Main subjects/characters\n3. Actions/movements\n4. Visual atmosphere/mood\n5. Important visual details\n6. Camera angles/shots (if specified)\n\nProvide a structured analysis that can be used to generate an accurate image."""
            def get_prompt():
                try:
                    response = client_ai.chat.completions.create(
                        model="gpt-4",
                        messages=[
                            {"role": "system", "content": system_prompt},
                            {"role": "user", "content": f"{script_text[:800]}"}
                        ],
                        max_tokens=150,
                        temperature=1
                    )
                    return response
                except Exception as e:
                    logging.error(f"Error in prompt generation: {e}")
                    raise

            loop = asyncio.get_event_loop()
            
            if status_message and not quiet:
                await status_message.edit_text("🎨 Creating detailed visual concept from your script...")
                
            summary_response = await loop.run_in_executor(None, get_prompt)
            detailed_prompt = summary_response.choices[0].message.content.strip()
            detailed_prompt = detailed_prompt.replace("\n", " ").replace("  ", " ")
            detailed_prompt = re.sub(r'[^\w\s,.!?-]', '', detailed_prompt)
            detailed_prompt = detailed_prompt[:950]
            enhanced_prompt = f"Create an Social Media ready image for this prompt '{detailed_prompt}' Style: Contextual, High quality,Highly Detailed, professional ,4K."

            if status_message and not quiet:
                await status_message.edit_text("🎨 Visual concept ready. Generating your image with DALL-E...")

            def generate_image():
                try:
                    return client_ai.images.generate(
                        model="dall-e-3",
                        prompt=enhanced_prompt,
                        size="1792x1024",
                        quality="hd",
                        style="vivid",
                        n=1
                    )
                except Exception as e:
                    logging.error(f"DALL-E API Error: {str(e)}")
                    raise

            try:
                if status_message and not quiet:
                    await status_message.edit_text("🎨 Creating your image with DALL-E 3...\n⏳ This may take a minute...")
                    
                image_response = await loop.run_in_executor(None, generate_image)
                image_url = image_response.data[0].url
                
                if status_message and not quiet:
                    await status_message.edit_text("✅ Image created! Sending it to you now...")
                    
                # Only send the image automatically if not in quiet mode
                if not quiet:
                    send_success = await send_image_with_retry(
                        client=client,
                        chat_id=chat_id,
                        image_url=image_url
                    )
                    if not send_success:
                        if status_message:
                            await status_message.edit_text("❌ Error sending image. Please try again.")
                        return False
                    
                    if status_message:
                        await status_message.delete()
                
                return image_url
            except Exception as e:
                logging.error(f"Error in image generation: {e}")
                if status_message and not quiet:
                    await status_message.edit_text(f"❌ Error generating image: {str(e)[:100]}... Please try again.")
                return False
        except Exception as e:
            logging.error(f"Error: {e}")
            if status_message and not quiet:
                await status_message.edit_text(f"❌ Error during generation: {str(e)[:100]}... Please try again.")
            return False
    except Exception as e:
        logging.error(f"Error: {e}")
        if 'status_message' in locals() and status_message and not quiet:
            await status_message.edit_text(f"❌ Error: {str(e)[:100]}... Please try again.")
        return False

async def send_image_with_retry(client, chat_id, image_path=None, image_url=None, caption=None, reply_to_message_id=None, reply_markup=None):
    """
    Send an image with retry logic, supporting both local files and URLs.
    Now part of ImageGen.py.
    Args:
        client (Client): The Pyrogram client
        chat_id (int): The chat ID to send the image to
        image_path (str, optional): Local path to the image file
        image_url (str, optional): URL of the image to send
        caption (str, optional): Caption to include with the image
        reply_to_message_id (int, optional): Message ID to reply to
        reply_markup (InlineKeyboardMarkup, optional): Reply markup for inline keyboard
    Returns:
        bool: True if the image was sent successfully, False otherwise
    """
    import os
    from urllib.parse import urlparse
    import logging
    if not image_path and not image_url:
        logging.error("No image path or URL provided")
        return False
    def is_valid_url(url):
        if not url or not isinstance(url, str):
            return False
        try:
            result = urlparse(url)
            return all([result.scheme, result.netloc])
        except:
            return False
    if image_url and not is_valid_url(image_url):
        logging.error(f"Invalid image URL: {image_url}")
        return False
    using_url = image_url is not None and is_valid_url(image_url)
    source = image_url if using_url else image_path
    source_type = "URL" if using_url else "local file"
    logging.info(f"Sending image from {source_type} to chat {chat_id}")
    if caption and len(caption) > 1024:
        image_caption = caption[:1000] + "... (continued in next message)"
        remaining_caption = caption[1000:]
    else:
        image_caption = caption
        remaining_caption = None
    max_retries = 3
    base_delay = 2
    for attempt in range(1, max_retries + 1):
        try:
            if using_url:
                sent_message = await client.send_photo(
                    chat_id=chat_id,
                    photo=source,
                    caption=image_caption,
                    reply_to_message_id=reply_to_message_id,
                    reply_markup=reply_markup
                )
            else:
                if not os.path.exists(source):
                    logging.error(f"Image file not found: {source}")
                    return False
                sent_message = await client.send_photo(
                    chat_id=chat_id,
                    photo=source,
                    caption=image_caption,
                    reply_to_message_id=reply_to_message_id,
                    reply_markup=reply_markup
                )
            if remaining_caption:
                try:
                    await client.send_message(
                        chat_id=chat_id,
                        text=remaining_caption,
                        reply_to_message_id=sent_message.id
                    )
                except Exception as e:
                    logging.error(f"Error sending caption continuation: {str(e)}")
            logging.info(f"Successfully sent image to chat {chat_id}")
            return True
        except Exception as e:
            logging.error(f"Error sending image (attempt {attempt}/{max_retries}): {str(e)}")
            if attempt < max_retries:
                delay = base_delay * (2 ** (attempt - 1))
                logging.info(f"Retrying in {delay} seconds...")
                import asyncio
                await asyncio.sleep(delay)
            else:
                logging.error("Max retries reached. Failed to send image.")
                return False
    return False

def extract_scenes_from_script(script_text):
    """
    Extract scene numbers, title, description, hashtags, and text from a script.
    Returns:
        list: List of dicts with keys: scene_num, title, description, hashtags, scene_text
    """
    scenes = []
    scene_separator = "━━━━━━━━━━━━━━━━━━━━━━━━━━"
    scene_blocks = script_text.split(scene_separator)
    
    # Patterns for extracting fields
    scene_pattern = r'(?:🎬\s*)?SCENE\s*(\d+)'
    title_pattern = r'🏷️\s*Title:\s*(.*)'
    description_pattern = r'📝\s*Description:\s*(.*)'
    hashtags_pattern = r'#️⃣\s*Hashtags:\s*(.*)'
    
    for block in scene_blocks:
        block = block.strip()
        if not block:
            continue
        # Extract scene number
        scene_num_match = re.search(scene_pattern, block, re.IGNORECASE)
        scene_num = scene_num_match.group(1) if scene_num_match else None
        # Extract title
        title_match = re.search(title_pattern, block)
        title = title_match.group(1).strip() if title_match else ""
        # Extract description
        description_match = re.search(description_pattern, block)
        description = description_match.group(1).strip() if description_match else ""
        # Extract hashtags
        hashtags_match = re.search(hashtags_pattern, block)
        hashtags = hashtags_match.group(1).strip() if hashtags_match else ""
        # Add to scenes list
        if scene_num:
            scenes.append({
                "scene_num": scene_num,
                "title": title,
                "description": description,
                "hashtags": hashtags,
                "scene_text": block
            })
    # Fallback: if no scenes found, treat whole script as one scene
    if not scenes and script_text.strip():
        scenes = [{
            "scene_num": "1",
            "title": "",
            "description": "",
            "hashtags": "",
            "scene_text": script_text.strip()
        }]
    return scenes 