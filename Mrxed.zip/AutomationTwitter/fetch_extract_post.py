import asyncio
import logging
from datetime import datetime
from utils.scraper import extract_post_info

async def fetch_account_posts(page, username, max_posts=3):
    """
    Fetch recent posts from a Twitter account, skipping pinned posts
    Args:
        page: Playwright page object
        username: Twitter username to fetch posts from
        max_posts: Maximum number of posts to fetch
    Returns:
        List of post dictionaries or empty list on error
    """
    posts = []
    try:
        logger = logging.getLogger(__name__)
        logger.info(f"Fetching up to {max_posts} posts from @{username}")
        url = f"https://x.com/{username}"
        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(3)
            logger.info(f"Successfully navigated to {username}'s profile")
        except Exception as e:
            logger.error(f"Error navigating to {username}'s profile: {e}")
            return []
        tweet_selector = "article[data-testid='tweet']"
        try:
            await page.wait_for_selector(tweet_selector, timeout=10000)
            tweets = await page.query_selector_all(tweet_selector)
            logger.info(f"Found tweets using selector: {tweet_selector}")
        except Exception as e:
            logger.error(f"Error finding tweets: {e}")
            try:
                alternative_selector = "div[data-testid='cellInnerDiv']"
                await page.wait_for_selector(alternative_selector, timeout=5000)
                tweets = await page.query_selector_all(alternative_selector)
                logger.info(f"Found tweets using alternative selector: {alternative_selector}")
            except Exception as alt_e:
                logger.error(f"Error finding tweets with alternative selector: {alt_e}")
                return []
        if not tweets:
            logger.info(f"No tweets found for {username}")
            return []
        logger.info(f"Found {len(tweets)} tweets for {username}")
        post_count = 0
        for i, tweet in enumerate(tweets):
            if post_count >= max_posts:
                break
            try:
                pinned_indicator = await tweet.query_selector("div[data-testid='socialContext']")
                if pinned_indicator:
                    pinned_text = await pinned_indicator.inner_text()
                    if "pinned" in pinned_text.lower():
                        logger.info(f"Skipping pinned tweet {i+1}")
                        continue
                post_info = await extract_and_enhance_post_info(tweet)
                if post_info:
                    post_count += 1
                    logger.info(f"Added post {post_count} from {username}")
                    post_info["author"] = username
                    post_info["fetched_at"] = datetime.now().isoformat()
                    posts.append(post_info)
            except Exception as e:
                logger.error(f"Error processing tweet {i+1}: {e}")
                continue
        logger.info(f"Successfully fetched {len(posts)} posts from @{username}")
    except Exception as e:
        logger.error(f"Error fetching posts from {username}: {e}")
    return posts

async def extract_and_enhance_post_info(post_element):
    """
    Extract complete post information including full text and all media
    This function enhances the basic post extraction with more comprehensive data capture
    """
    try:
        from utils.scraper import extract_post_info
        post_info = await extract_post_info(post_element)
        try:
            show_more = await post_element.query_selector('div[role="button"][data-testid="tweet-text-show-more-link"]')
            if show_more:
                try:
                    await show_more.click()
                    await asyncio.sleep(0.5)
                except Exception as click_err:
                    logging.warning(f"Failed to click 'show more': {click_err}")
            text_element = await post_element.query_selector('div[data-testid="tweetText"]')
            if text_element:
                full_text = await text_element.inner_text()
                if full_text:
                    post_info["text"] = full_text
        except Exception as text_err:
            logging.warning(f"Error extracting full text: {text_err}")
        try:
            img_elements = await post_element.query_selector_all('img[src*="https://pbs.twimg.com/media/"]')
            image_urls = []
            for img in img_elements:
                src = await img.get_attribute("src")
                if src and "pbs.twimg.com/media" in src:
                    if "?" in src:
                        base_url = src.split("?")[0]
                        clean_url = f"{base_url}?format=jpg&name=orig"
                    else:
                        clean_url = src
                    if clean_url not in image_urls:
                        image_urls.append(clean_url)
            if image_urls:
                post_info["image_urls"] = image_urls
        except Exception as img_err:
            logging.warning(f"Error extracting images: {img_err}")
        try:
            video_element = await post_element.query_selector('video')
            if video_element:
                poster = await video_element.get_attribute("poster")
                if poster:
                    post_info["video_thumbnail"] = poster
                    post_info["has_video"] = True
            video_container = await post_element.query_selector('div[data-testid="videoPlayer"]')
            if video_container:
                post_info["has_video"] = True
                playback_button = await video_container.query_selector('div[role="button"][data-testid="play"]')
                if playback_button:
                    post_info["has_playable_video"] = True
                video_preview = await video_container.query_selector('img[draggable="true"]')
                if video_preview:
                    thumb_src = await video_preview.get_attribute("src")
                    if thumb_src:
                        post_info["video_thumbnail"] = thumb_src
        except Exception as video_err:
            logging.warning(f"Error extracting video: {video_err}")
        try:
            quoted_tweet = await post_element.query_selector('div[data-testid="tweet-quoted"]')
            if quoted_tweet:
                quote_text_el = await quoted_tweet.query_selector('div[data-testid="tweetText"]')
                quote_info = {"has_quote": True}
                if quote_text_el:
                    quote_text = await quote_text_el.inner_text()
                    quote_info["quote_text"] = quote_text
                quote_author_el = await quoted_tweet.query_selector('div[data-testid="User-Name"]')
                if quote_author_el:
                    author_name_el = await quote_author_el.query_selector('span')
                    if author_name_el:
                        author_name = await author_name_el.inner_text()
                        quote_info["quote_author"] = author_name
                post_info["quote_info"] = quote_info
        except Exception as quote_err:
            logging.warning(f"Error extracting quote tweet: {quote_err}")
        try:
            metrics_items = await post_element.query_selector_all('div[role="group"] div[role="button"]')
            for metric_item in metrics_items:
                try:
                    label = await metric_item.get_attribute("aria-label")
                    if label:
                        if "repl" in label.lower() and "replies" not in post_info.get("metrics", {}):
                            count = "".join([c for c in label if c.isdigit()])
                            if count:
                                if "metrics" not in post_info:
                                    post_info["metrics"] = {}
                                post_info["metrics"]["replies"] = count
                        elif "retweet" in label.lower() and "retweet" not in post_info.get("metrics", {}):
                            count = "".join([c for c in label if c.isdigit()])
                            if count:
                                if "metrics" not in post_info:
                                    post_info["metrics"] = {}
                                post_info["metrics"]["retweet"] = count
                        elif "like" in label.lower() and "like" not in post_info.get("metrics", {}):
                            count = "".join([c for c in label if c.isdigit()])
                            if count:
                                if "metrics" not in post_info:
                                    post_info["metrics"] = {}
                                post_info["metrics"]["like"] = count
                except Exception:
                    pass
        except Exception as metrics_err:
            logging.warning(f"Error extracting detailed metrics: {metrics_err}")
        try:
            time_element = await post_element.query_selector('time')
            if time_element:
                datetime_str = await time_element.get_attribute("datetime")
                if datetime_str:
                    post_info["datetime"] = datetime_str
                link_element = await post_element.query_selector('a[href*="/status/"]')
                if link_element:
                    href = await link_element.get_attribute("href")
                    if href and "/status/" in href:
                        post_info["post_url"] = f"https://x.com{href}"
        except Exception as time_err:
            logging.warning(f"Error extracting timestamp: {time_err}")
        try:
            name_element = await post_element.query_selector('div[data-testid="User-Name"] > div:nth-child(1) > div:nth-child(1) > span')
            if name_element:
                display_name = await name_element.inner_text()
                if display_name:
                    post_info["display_name"] = display_name.strip()
        except Exception as name_err:
            logging.warning(f"Error extracting display name: {name_err}")
        return post_info
    except Exception as e:
        logging.error(f"Error in extract_and_enhance_post_info: {e}")
        from utils.scraper import extract_post_info
        return await extract_post_info(post_element)
