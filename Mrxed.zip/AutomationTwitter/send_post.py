"""
Send Post Helpers
Contains async helpers for sending posts to a Telegram channel and marking them as sent.
"""

import asyncio
import logging
from datetime import datetime
from pyrogram import Client
from pyrogram.errors import FloodWait
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

# TODO: Pass in db, Config, logger, and format_post_for_channel from bot.py when calling these functions

async def send_posts_to_channel(client, posts, db, Config, logger, format_post_for_channel, user_id=None):
    """
    Send posts to a channel with rate limiting
    
    Args:
        client: Pyrogram client
        posts: List of posts to send
        db: MongoDB database
        Config: Configuration object
        logger: Logger instance
        format_post_for_channel: Function to format posts for channel
        user_id: Optional user ID for user-specific collections
    """
    if not posts:
        logger.info("No posts to send to channel")
        return
    
    # Get the appropriate collection
    posts_collection = None
    if user_id:
        try:
            # Try to import user collection helper
            from bot import get_user_db_collections
            collections = get_user_db_collections(user_id)
            posts_collection = db[collections["posts"]]
            logger.info(f"Using user-specific posts collection for user {user_id}")
        except ImportError:
            logger.warning("Could not import get_user_db_collections, using default collection")
            posts_collection = db[Config.POSTS_COLLECTION]
    else:
        posts_collection = db[Config.POSTS_COLLECTION]
    
    channel_id = Config.CHANNEL_ID
    if not channel_id:
        logger.error("No channel ID configured")
        return
    
    sent_count = 0
    for post in posts:
        try:
            # Format the post for the channel
            message = format_post_for_channel(post)
            
            # Add the "Generate Script with AI" button
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("🤖 Generate Script with AI", callback_data="generate_content")]
            ])
            
            # Send the message to the channel
            await client.send_message(
                chat_id=channel_id,
                text=message,
                disable_web_page_preview=True,
                reply_markup=keyboard
            )
            
            # Update post status in database
            if posts_collection is not None and post.get("_id"):
                posts_collection.update_one(
                    {"_id": post["_id"]},
                    {"$set": {
                        "sent_to_channel": True,
                        "sent_at": datetime.now()
                    }}
                )
            
            sent_count += 1
            logger.info(f"Sent post {sent_count}/{len(posts)} to channel")
            
            # Rate limiting to avoid flood wait
            await asyncio.sleep(2)
        
        except FloodWait as e:
            logger.warning(f"FloodWait: Waiting for {e.x} seconds")
            await asyncio.sleep(e.x)
            
            # Try again with this post
            try:
                message = format_post_for_channel(post)
                # Add the keyboard for the retry as well
                keyboard = InlineKeyboardMarkup([
                    [InlineKeyboardButton("🤖 Generate Script with AI", callback_data="generate_content")]
                ])
                await client.send_message(
                    chat_id=channel_id,
                    text=message,
                    disable_web_page_preview=True,
                    reply_markup=keyboard
                )
                sent_count += 1
            except Exception as retry_error:
                logger.error(f"Error sending post after FloodWait: {retry_error}")
                
        except Exception as e:
            logger.error(f"Error sending post to channel: {e}")
    
    logger.info(f"Sent {sent_count}/{len(posts)} posts to channel")
    return sent_count
