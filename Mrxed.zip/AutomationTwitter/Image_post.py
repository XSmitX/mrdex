import asyncio
import logging
import os

async def post_image_to_twitter(context, image_path, description, logger=None):
    logger = logger or logging.getLogger(__name__)
    if context is None:
        logger.error("Browser context is None. Cannot post to Twitter.")
        return None
    if not os.path.exists(image_path):
        logger.error(f"Image file not found: {image_path}")
        return None
    logger.info(f"Posting image to Twitter: {image_path}")
    
    # Create a new page for this specific post to avoid blocking other operations
    page = await context.new_page()
    if not page:
        logger.error("Failed to create new page!")
        return None
    
    try:
        page.set_default_timeout(15000)
        page.set_default_navigation_timeout(30000)
        # Go to Twitter home page
        for attempt in range(3):
            try:
                await page.goto("https://x.com/home", timeout=40000)
                break
            except Exception as nav_error:
                if attempt == 2:
                    logger.error("Could not load Twitter homepage after 3 attempts")
                    await page.close()
                    return None
                await asyncio.sleep(2)
        try:
            await page.wait_for_load_state("networkidle", timeout=5000)
        except Exception:
            pass
        await asyncio.sleep(3)
        # Compose button
        tweet_composer_selectors = [
            'a[data-testid="SideNav_NewTweet_Button"]',
            'a[href="/compose/tweet"]',
            'a:has-text("Tweet")'
        ]
        compose_clicked = False
        for selector in tweet_composer_selectors:
            try:
                compose_button = await page.wait_for_selector(selector, timeout=10000)
                if compose_button:
                    await asyncio.sleep(1)
                    await compose_button.click()
                    compose_clicked = True
                    await asyncio.sleep(2)
                    logger.info(f"Clicked compose button: {selector}")
                    break
            except Exception:
                continue
        if not compose_clicked:
            try:
                await page.keyboard.press('n')
                await asyncio.sleep(2)
                compose_clicked = True
                logger.info("Opened compose with keyboard shortcut")
            except Exception:
                pass
            if not compose_clicked:
                try:
                    compose_result = await page.evaluate('''
                        () => {
                            let composeButton = Array.from(document.querySelectorAll('a')).find(
                                el => el.getAttribute('aria-label') === 'Tweet' || 
                                      el.getAttribute('aria-label') === 'Post' ||
                                      el.textContent.includes('Tweet')
                            );
                            if (composeButton) {
                                composeButton.click();
                                return true;
                            }
                            return false;
                        }
                    ''')
                    if compose_result:
                        compose_clicked = True
                        await asyncio.sleep(2)
                        logger.info("Clicked compose button using JS fallback")
                except Exception:
                    pass
        if not compose_clicked:
            logger.error("Could not find or click compose button. Aborting.")
            try:
                await page.screenshot(path=f"error_compose_{os.path.basename(image_path)}.png")
            except Exception:
                pass
            await page.close()
            return None
        await asyncio.sleep(3)
        # Fill tweet text
        selectors = [
            'div[data-testid="tweetTextarea_0"]', 
            'div[role="textbox"]', 
            'div[aria-label="Tweet text"]',
            'div[aria-label="What\'s happening?"]', 
            "div[aria-label=\"What's happening?\"]"
        ]
        text_filled = False
        for selector in selectors:
            try:
                text_box = await page.wait_for_selector(selector, timeout=10000)
                if text_box:
                    await asyncio.sleep(1)
                    await text_box.fill(description)
                    text_filled = True
                    logger.info(f"Filled tweet text: {selector}")
                    await asyncio.sleep(1)
                    break
            except Exception:
                continue
        if not text_filled:
            try:
                js_result = await page.evaluate(f'''
                    () => {{
                        const textboxes = document.querySelectorAll('div[role="textbox"]');
                        for (const box of textboxes) {{
                            if (box.isConnected && box.offsetParent !== null) {{
                                box.textContent = "{description}";
                                box.dispatchEvent(new Event('input', {{ bubbles: true }}));
                                return true;
                            }}
                        }}
                        return false;
                    }}
                ''')
                if js_result:
                    text_filled = True
                    await asyncio.sleep(1)
                    logger.info("Filled tweet text using JS fallback")
            except Exception:
                pass
        if not text_filled:
            logger.warning("Could not find or fill tweet text box. Continuing anyway.")
        # Upload the image
        input_selector = 'input[type="file"][accept^="image"]'
        try:
            file_input = await page.wait_for_selector(input_selector, timeout=15000)
            if file_input:
                await page.set_input_files(input_selector, image_path)
                try:
                    await page.wait_for_selector('div[aria-label="Image"] img, div[data-testid="attachments"] img, [data-testid="tweetPhoto"]', timeout=20000)
                except Exception:
                    pass
                await asyncio.sleep(3)
                logger.info("Image uploaded")
            else:
                logger.error("File input not found")
                try:
                    await page.screenshot(path=f"error_file_input_{os.path.basename(image_path)}.png")
                except Exception:
                    pass
                await page.close()
                return None
        except Exception:
            logger.error("Failed to upload image")
            try:
                await page.screenshot(path=f"error_upload_{os.path.basename(image_path)}.png")
            except Exception:
                pass
            await page.close()
            return None
        # Click tweet button
        tweet_posted = False
        try:
            result = await page.evaluate("""
                () => {
                    const buttonAttributes = [
                        '[data-testid="tweetButton"]',
                        '[data-testid="tweetButtonInline"]',
                        '[data-testid="postButton"]'
                    ];
                    for (const attr of buttonAttributes) {
                        const buttons = document.querySelectorAll(attr);
                        for (const button of buttons) {
                            if (button && button.offsetWidth > 0 && button.offsetHeight > 0) {
                                button.click();
                                return { clicked: true, method: 'attribute', selector: attr };
                            }
                        }
                    }
                    const texts = ['Tweet', 'Post'];
                    for (const text of texts) {
                        const buttons = document.querySelectorAll('div[role="button"]');
                        for (const button of buttons) {
                            if (button.textContent.includes(text) && 
                                button.offsetWidth > 0 && 
                                button.offsetHeight > 0) {
                                button.click();
                                return { clicked: true, method: 'text', text: text };
                            }
                        }
                    }
                    const dialogButtons = document.querySelectorAll('.css-18t94o4[role="button"]:not([aria-disabled="true"])');
                    for (const button of dialogButtons) {
                        if (button && button.offsetWidth > 0 && button.offsetHeight > 0) {
                            button.click();
                            return { clicked: true, method: 'dialog', element: button.textContent };
                        }
                    }
                    return { clicked: false };
                }
            """)
            if result and result.get('clicked'):
                tweet_posted = True
                logger.info("Clicked tweet button")
            else:
                tweet_posted = False
        except Exception:
            tweet_posted = False
        if not tweet_posted:
            try:
                button_selectors = [
                    '[data-testid="tweetButton"]',
                    '[data-testid="primaryColumn"] div[role="button"]',
                    'div[role="button"]:has-text("Tweet")',
                    'div[role="button"]:has-text("Post")'
                ]
                for selector in button_selectors:
                    try:
                        button = await page.wait_for_selector(selector, timeout=10000)
                        if button:
                            await asyncio.sleep(1)
                            await button.click()
                            tweet_posted = True
                            logger.info(f"Clicked tweet button: {selector}")
                            break
                    except Exception:
                        continue
            except Exception:
                pass
        if not tweet_posted:
            logger.error("Could not click post button.")
            try:
                await page.screenshot(path=f"error_post_{os.path.basename(image_path)}.png")
            except Exception:
                pass
            await page.close()
            return None
        await asyncio.sleep(5)
        # Get tweet URL from profile
        try:
            await page.goto("https://x.com/home", timeout=30000)
            await asyncio.sleep(2)
            profile_link = await page.query_selector('a[data-testid="AppTabBar_Profile_Link"]')
            if profile_link:
                profile_url = await profile_link.get_attribute("href")
                if profile_url:
                    await page.goto(f"https://x.com{profile_url}", timeout=30000)
                    await asyncio.sleep(2)
                    tweets = await page.query_selector_all('article[data-testid="tweet"] a[href*="/status/"]')
                    if tweets and len(tweets) > 0:
                        tweet_url = await tweets[0].get_attribute("href")
                        if tweet_url:
                            tweet_url = f"https://x.com{tweet_url}" if tweet_url.startswith('/') else tweet_url
                            logger.info(f"Tweet posted: {tweet_url}")
                            await page.close()
                            return tweet_url
        except Exception:
            pass
        if tweet_posted:
            logger.info("Tweet appears to have been posted, but couldn't retrieve the URL")
            await page.close()
            return "Tweet was posted, but couldn't retrieve the URL"
        else:
            logger.error("Tweet may not have been posted and URL not found")
            await page.close()
            return None
    except Exception as e:
        logger.error(f"Error posting image to Twitter: {e}")
        try:
            await page.screenshot(path=f"error_general_{os.path.basename(image_path)}.png")
        except Exception:
            pass
        await page.close()
        return None
    finally:
        try:
            await page.close()
        except Exception as e:
            logger.warning(f"Error closing page: {e}")
        
        return tweet_url 