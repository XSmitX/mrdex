"""
ImageGen.py
Contains both consolidated and scene-by-scene image generation logic.
Extracted and merged from bot.py and SceneBySceneGen.py.
"""
import os
import logging
import asyncio
import re

from utils.config import Config

# The handle_scene_by_scene_generation function has been removed to fix syntax warnings

async def generate_consolidated_image(script_text, chat_id, client, message, prompt_prefix="", quiet=False):
    """Generate a single detailed image from the entire script using enhanced GPT-4 prompting
    
    Args:
        script_text (str): The script text to generate an image from
        chat_id (int): The chat ID to send the image to
        client (Client): The Pyrogram client
        message: The message object to reply to with status updates
        prompt_prefix (str, optional): Optional prefix to add to the prompt
        quiet (bool, optional): If True, will not send status messages
        
    Returns:
        str: The URL of the generated image, or False if generation failed
    """
    try:
        if not script_text:
            raise ValueError("No script text provided")

        # Create user directory if it doesn't exist
        user_dir = f"user_images/{str(client.me.id)}"
        os.makedirs(user_dir, exist_ok=True)

        status_message = None
        if not quiet:
            # Create a status message
            status_message = await message.reply("🎨 Creating your consolidated image...")

        try:
            from openai import OpenAI
            import re
            client_ai = OpenAI()

            if status_message and not quiet:
                await status_message.edit_text("🎨 Analyzing your script and creating a visual prompt...")

            system_prompt = """You are a visual script analyzer. Extract key visual elements and context from the script scene.\nFocus on:\n1. Setting/Location\n2. Main subjects/characters\n3. Actions/movements\n4. Visual atmosphere/mood\n5. Important visual details\n6. Camera angles/shots (if specified)\n\nProvide a structured analysis that can be used to generate an accurate image."""
            def get_prompt():
                try:
                    response = client_ai.chat.completions.create(
                        model="gpt-4",
                        messages=[
                            {"role": "system", "content": system_prompt},
                            {"role": "user", "content": f"{script_text[:800]}"}
                        ],
                        max_tokens=150,
                        temperature=1
                    )
                    return response
                except Exception as e:
                    logging.error(f"Error in prompt generation: {e}")
                    raise

            loop = asyncio.get_event_loop()
            
            if status_message and not quiet:
                await status_message.edit_text("🎨 Creating detailed visual concept from your script...")
                
            summary_response = await loop.run_in_executor(None, get_prompt)
            detailed_prompt = summary_response.choices[0].message.content.strip()
            detailed_prompt = detailed_prompt.replace("\n", " ").replace("  ", " ")
            detailed_prompt = re.sub(r'[^\w\s,.!?-]', '', detailed_prompt)
            detailed_prompt = detailed_prompt[:950]

            # New: Clean and improve the prompt for DALL-E
            if not detailed_prompt or len(detailed_prompt) < 10:
                detailed_prompt = "A visually engaging, high-quality, professional social media image with rich detail and vibrant colors."

            # Remove meta-instruction, just use the description
            enhanced_prompt = (
                f"{prompt_prefix} {detailed_prompt}. "
                "Style: Contextual, high quality, highly detailed, professional, 4K, vivid colors."
            ).strip()

            # Optionally, log the prompt for debugging
            logging.info(f"Prompt sent to DALL-E: {enhanced_prompt}")

            if status_message and not quiet:
                await status_message.edit_text("🎨 Visual concept ready. Generating your image with DALL-E...")

            def generate_image():
                try:
                    return client_ai.images.generate(
                        model="dall-e-3",
                        prompt=enhanced_prompt,
                        size="1024x1024",
                        quality="hd",
                        style="natural",
                        n=1
                    )
                except Exception as e:
                    logging.error(f"DALL-E API Error: {str(e)}")
                    raise

            try:
                if status_message and not quiet:
                    await status_message.edit_text("🎨 Creating your image with DALL-E 3...\n⏳ This may take a minute...")
                    
                image_response = await loop.run_in_executor(None, generate_image)
                image_url = image_response.data[0].url
                
                # Send the image to the storage channel and get file_id/message_id
                storage_channel_id = Config.STORAGE_CHANNEL_ID  # Add this to your config
                sent_message = await client.send_photo(
                    chat_id=storage_channel_id,
                    photo=image_url,
                    caption= f"<code> Generated by : {chat_id}</code>"
                )
                file_id = sent_message.photo.file_id
                message_id = sent_message.id
                
                if status_message and not quiet:
                    await status_message.edit_text("✅ Image created! Sending it to you now...")
                
                # Only send the image automatically if not in quiet mode
                if not quiet:
                    send_success = await send_image_with_retry(
                        client=client,
                        chat_id=chat_id,
                        image_url=image_url
                    )
                    if not send_success:
                        if status_message:
                            await status_message.edit_text("❌ Error sending image. Please try again.")
                        return False
                    if status_message:
                        await status_message.delete()
                
                # Return all necessary info for batch storage
                return {
                    'image_url': image_url,
                    'file_id': file_id,
                    'message_id': message_id
                }
            except Exception as e:
                logging.error(f"Error in image generation: {e}")
                if status_message and not quiet:
                    await status_message.edit_text(f"❌ Error generating image: {str(e)[:100]}... Please try again.")
                return False
        except Exception as e:
            logging.error(f"Error: {e}")
            if status_message and not quiet:
                await status_message.edit_text(f"❌ Error during generation: {str(e)[:100]}... Please try again.")
            return False
    except Exception as e:
        logging.error(f"Error: {e}")
        if 'status_message' in locals() and status_message and not quiet:
            await status_message.edit_text(f"❌ Error: {str(e)[:100]}... Please try again.")
        return False

async def send_image_with_retry(client, chat_id, image_path=None, image_url=None, caption=None, reply_to_message_id=None, reply_markup=None):
    """
    Send an image with retry logic, supporting both local files and URLs.
    Now part of ImageGen.py.
    Args:
        client (Client): The Pyrogram client
        chat_id (int): The chat ID to send the image to
        image_path (str, optional): Local path to the image file
        image_url (str, optional): URL of the image to send
        caption (str, optional): Caption to include with the image
        reply_to_message_id (int, optional): Message ID to reply to
        reply_markup (InlineKeyboardMarkup, optional): Reply markup for inline keyboard
    Returns:
        bool: True if the image was sent successfully, False otherwise
    """
    import os
    from urllib.parse import urlparse
    import logging
    if not image_path and not image_url:
        logging.error("No image path or URL provided")
        return False
    def is_valid_url(url):
        if not url or not isinstance(url, str):
            return False
        try:
            result = urlparse(url)
            return all([result.scheme, result.netloc])
        except:
            return False
    if image_url and not is_valid_url(image_url):
        logging.error(f"Invalid image URL: {image_url}")
        return False
    using_url = image_url is not None and is_valid_url(image_url)
    source = image_url if using_url else image_path
    source_type = "URL" if using_url else "local file"
    logging.info(f"Sending image from {source_type} to chat {chat_id}")
    if caption and len(caption) > 1024:
        image_caption = caption[:1000] + "... (continued in next message)"
        remaining_caption = caption[1000:]
    else:
        image_caption = caption
        remaining_caption = None
    max_retries = 3
    base_delay = 2
    for attempt in range(1, max_retries + 1):
        try:
            if using_url:
                sent_message = await client.send_photo(
                    chat_id=chat_id,
                    photo=source,
                    caption=image_caption,
                    reply_to_message_id=reply_to_message_id,
                    reply_markup=reply_markup
                )

            else:
                if not os.path.exists(source):
                    logging.error(f"Image file not found: {source}")
                    return False
                sent_message = await client.send_photo(
                    chat_id=chat_id,
                    photo=source,
                    caption=image_caption,
                    reply_to_message_id=reply_to_message_id,
                    reply_markup=reply_markup
                )
            if remaining_caption:
                try:
                    await client.send_message(
                        chat_id=chat_id,
                        text=remaining_caption,
                        reply_to_message_id=sent_message.id
                    )
                except Exception as e:
                    logging.error(f"Error sending caption continuation: {str(e)}")
            logging.info(f"Successfully sent image to chat {chat_id}")
            return True
        except Exception as e:
            logging.error(f"Error sending image (attempt {attempt}/{max_retries}): {str(e)}")
            if attempt < max_retries:
                delay = base_delay * (2 ** (attempt - 1))
                logging.info(f"Retrying in {delay} seconds...")
                import asyncio
                await asyncio.sleep(delay)
            else:
                logging.error("Max retries reached. Failed to send image.")
                return False
    return False

def extract_scenes_from_script(script_text):
    """
    Extract scene numbers and text from a script, including VO, PRODUCTION NOTE, and SCENE DESCRIPTION
    Returns:
        list: List of tuples (scene_number, scene_text)
    """
    scenes = []
    
    # Split the script by scene separators
    scene_separator = "━━━━━━━━━━━━━━━━━━━━━━━━━━"
    scene_blocks = script_text.split(scene_separator)
    
    # Process each scene block
    scene_pattern = r'(?:🎬\s*)?SCENE\s*(\d+)\s*\[(\d+:\d+)\s*-\s*(\d+:\d+)\]'
    
    for block in scene_blocks:
        block = block.strip()
        if not block:
            continue
            
        # Try to extract scene number and timestamps
        scene_match = re.search(scene_pattern, block, re.IGNORECASE)
        if scene_match:
            scene_num = scene_match.group(1)
            # Use the entire block as the scene content
            scenes.append((scene_num, block))
    
    # If no scenes were found using the separator method, fall back to the original method
    if not scenes:
        # Pattern to match scene numbers (variations of "Scene X:", "SCENE X:", "X:", etc.)
        patterns = [
            # Scene with emoji and timestamp format
            r'(?:🎬\s*)?(?:SCENE|Scene|scene)\s*(\d+)\s*\[.*?\].*?(?=(?:(?:🎬\s*)?(?:SCENE|Scene|scene)\s*\d+\s*\[)|$)',
            # Standard scene format variations
            r'(?:SCENE|Scene|scene)\s*(\d+)[\s:]*\n*(.*?)(?=(?:\n\s*(?:SCENE|Scene|scene)\s*\d+[\s:]*)|$)',
            # Scene with emoji variations
            r'(?:🎬|📹|🎥)\s*(?:SCENE|Scene|scene)?\s*(\d+)[\s:]*\n*(.*?)(?=(?:\n\s*(?:🎬|📹|🎥)\s*(?:SCENE|Scene|scene)?\s*\d+[\s:]*)|$)',
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, script_text, re.DOTALL | re.MULTILINE)
            if matches:
                if len(matches[0]) == 2:  # Standard format with scene number and content
                    for scene_num, content in matches:
                        content = content.strip()
                        if content:
                            scenes.append((scene_num, content))
                else:  # Only scene number captured, extract content differently
                    for scene_num in matches:
                        if isinstance(scene_num, tuple):
                            scene_num = scene_num[0]
                        # Find the content after this scene number
                        # Fix invalid escape sequences by using raw strings
                        scene_start = re.search(r'(?:🎬\s*)?(?:SCENE|Scene|scene)\s*' + re.escape(scene_num) + r'\s*\[', script_text)
                        if scene_start:
                            start_pos = scene_start.start()
                            # Find the next scene or end of text
                            next_scene = re.search(r'(?:🎬\s*)?(?:SCENE|Scene|scene)\s*(?!' + re.escape(scene_num) + r'\b)\d+\s*\[', script_text[start_pos+1:])
                            if next_scene:
                                end_pos = start_pos + 1 + next_scene.start()
                                content = script_text[start_pos:end_pos].strip()
                            else:
                                content = script_text[start_pos:].strip()
                            
                            scenes.append((scene_num, content))
                
                if scenes:
                    try:
                        import logging
                        logger = logging.getLogger(__name__)
                        logger.info(f"Found {len(scenes)} scenes using pattern: {pattern}")
                    except Exception:
                        pass
                    break
    
    # If still no scenes found, try paragraph-based separation
    if not scenes:
        try:
            import logging
            logger = logging.getLogger(__name__)
            logger.info("No scenes found with patterns, attempting paragraph-based separation.")
        except Exception:
            pass
        paragraphs = re.split(r'\n\s*\n', script_text)
        significant_paragraphs = []
        for p in paragraphs:
            p = p.strip()
            if len(p) >= 100:
                significant_paragraphs.append(p)
            elif len(p) >= 50 and re.search(r'(?:character|setting|location|scene|action|int\.|ext\.)', p, re.IGNORECASE):
                significant_paragraphs.append(p)
        if len(significant_paragraphs) < 2:
            significant_paragraphs = [p.strip() for p in paragraphs if p.strip() and len(p.strip()) > 30]
        paragraphs_to_use = significant_paragraphs[:8]
        for i, paragraph in enumerate(paragraphs_to_use, 1):
            scenes.append((str(i), paragraph))
        try:
            import logging
            logger = logging.getLogger(__name__)
            logger.info(f"Created {len(scenes)} scenes from paragraphs.")
        except Exception:
            pass
    
    # Sort scenes by number
    if scenes:
        try:
            scenes.sort(key=lambda x: int(x[0]))
        except ValueError:
            pass
    else:
        if script_text.strip():
            scenes = [("1", script_text.strip())]
            try:
                import logging
                logger = logging.getLogger(__name__)
                logger.info("Created single scene from entire script.")
            except Exception:
                pass
    
    try:
        scene_numbers = [num for num, _ in scenes]
        import logging
        logger = logging.getLogger(__name__)
        logger.info(f"Final scene count: {len(scenes)}, Scene numbers: {', '.join(scene_numbers)}")
    except Exception:
        pass
        
    return scenes 

def extract_scene_metadata(scene_text):
    """Extracts title, description, and hashtags from a scene block."""
    title = ""
    description = ""
    hashtags = ""
    
    # Use regex to extract lines with various formats
    # Title patterns
    title_patterns = [
        r"🏷️\s*Title:\s*(.*?)(?:\n|$)",
        r"📝\s*Title:\s*(.*?)(?:\n|$)",
        r"Title:\s*(.*?)(?:\n|$)",
        r"TITLE:\s*(.*?)(?:\n|$)"
    ]
    
    # Description patterns
    desc_patterns = [
        r"📝\s*Description:\s*(.*?)(?:\n|$)",
        r"Description:\s*(.*?)(?:\n|$)",
        r"DESCRIPTION:\s*(.*?)(?:\n|$)",
        r"Scene Description:\s*(.*?)(?:\n|$)",
        r"SCENE DESCRIPTION:\s*(.*?)(?:\n|$)"
    ]
    
    # Hashtag patterns
    hashtag_patterns = [
        r"#️⃣\s*Hashtags:\s*(.*?)(?:\n|$)",
        r"Hashtags:\s*(.*?)(?:\n|$)",
        r"HASHTAGS:\s*(.*?)(?:\n|$)",
        r"Tags:\s*(.*?)(?:\n|$)"
    ]
    
    # Try to extract title
    for pattern in title_patterns:
        match = re.search(pattern, scene_text, re.IGNORECASE)
        if match:
            title = match.group(1).strip()
            break
    
    # If no title found, try to extract from the first line if it looks like a title
    if not title:
        first_line = scene_text.split('\n')[0].strip() if scene_text else ""
        if first_line and len(first_line) < 80 and not first_line.startswith('SCENE') and not first_line.startswith('🎬'):
            title = first_line
    
    # Try to extract description
    for pattern in desc_patterns:
        match = re.search(pattern, scene_text, re.IGNORECASE)
        if match:
            description = match.group(1).strip()
            break
    
    # If no description found, look for a paragraph that might be a description
    if not description:
        # Look for paragraphs after "SCENE DESCRIPTION" or similar
        scene_desc_match = re.search(r"(?:SCENE|Scene)\s*(?:DESCRIPTION|Description).*?\n+(.*?)(?:\n\n|$)", scene_text, re.DOTALL)
        if scene_desc_match:
            description = scene_desc_match.group(1).strip()
        # Or look for paragraphs after "VO:" or "VOICE OVER:"
        elif not description:
            vo_match = re.search(r"(?:VO|VOICE OVER|Voice Over):\s*(.*?)(?:\n\n|$)", scene_text, re.DOTALL)
            if vo_match:
                description = vo_match.group(1).strip()
    
    # Try to extract hashtags
    for pattern in hashtag_patterns:
        match = re.search(pattern, scene_text, re.IGNORECASE)
        if match:
            hashtags = match.group(1).strip()
            break
    
    # If no hashtags found, try to extract hashtags from anywhere in the text
    if not hashtags:
        # Find all hashtags in the text
        all_hashtags = re.findall(r'#\w+', scene_text)
        if all_hashtags:
            hashtags = ' '.join(all_hashtags)
    
    # If still no hashtags, generate some basic ones
    if not hashtags:
        hashtags = "#AIGeneratedContent #DigitalArt"
    
    # Clean up the extracted data
    title = title[:100] if title else ""  # Limit title length
    description = description[:500] if description else ""  # Limit description length
    
    # Make sure hashtags start with #
    if hashtags and not any(hashtags.startswith(prefix) for prefix in ['#', ' #']):
        hashtags = '#' + hashtags.replace(' ', ' #')
    
    return title, description, hashtags

async def download_image_from_telegram(client, file_id, temp_path):
    """
    Download an image from Telegram using file_id
    
    Args:
        client: The Pyrogram client
        file_id: The file_id of the image to download
        temp_path: The local path to save the image to
        
    Returns:
        str: The local path where the image was saved
    """
    try:
        await client.download_media(file_id, file_name=temp_path)
        return temp_path
    except Exception as e:
        logging.error(f"Error downloading image from Telegram: {e}")
        raise Exception(f"Failed to download image from Telegram: {e}") 