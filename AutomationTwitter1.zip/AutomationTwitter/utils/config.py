import os
from dotenv import load_dotenv
from datetime import datetime
from typing import Optional

# Load environment variables
load_dotenv()

class Config:
    API_ID = os.getenv("API_ID", "1712043")
    API_HASH = os.getenv("API_HASH", "965c994b615e2644670ea106fd31daaf")
    BOT_TOKEN = os.getenv("BOT_TOKEN", "8089085349:AAFbt2SKEKhx7Gf1YHZUHL4-y1rIXAClxQw")
    TEMP_DIR = "temp"
    COOKIE_DIR = "cookies"
    
    # MongoDB Configuration
    MONGO_URI = os.getenv("MONGO_URI", "mongodb+srv://yourusername:yourpassword@cluster0.mongodb.net/")
    DB_NAME = "AUTOMATION_BOT"
    ACCOUNTS_COLLECTION = "twitter_accounts"
    POSTS_COLLECTION = "twitter_posts"
    CRONJOB_COLLECTION = "cronjob_accounts"
    
    # Test accounts
    TEST_ACCOUNTS = {
        "mrxed0158": "mrxed0158_cookies.json"
    }
    
    # Cron job settings
    CRON_FETCH_INTERVAL = int(os.getenv("CRON_FETCH_INTERVAL" )) # Minutes between fetches (set directly in config.py)
    CRON_MAX_POSTS_PER_ACCOUNT = int(os.getenv("CRON_MAX_POSTS"))  # Maximum posts to fetch per account (changed to 3)
    CRON_ENABLED = os.getenv("CRON_ENABLED", "true").lower() == "true"  # Whether CronJob is enabled

    CHANNEL_ID = os.getenv("CHANNEL_ID", "-1002699356033")
    CHANNEL_ID_FOR_FORWARDING = os.getenv("CHANNEL_ID_FOR_FORWARDING", "-1002699356033")
    STORAGE_CHANNEL_ID = os.getenv("STORAGE_CHANNEL_ID", "")  # Private channel for image storage
    
    # Default login credentials for cronjob browser
    DEFAULT_TWITTER_USERNAME = os.getenv("DEFAULT_TWITTER_USERNAME", "")
    DEFAULT_TWITTER_PASSWORD = os.getenv("DEFAULT_TWITTER_PASSWORD", "")
    DEFAULT_TWITTER_COOKIE_FILE = os.getenv("DEFAULT_TWITTER_COOKIE_FILE", "")  # Optional cookie file
    
    # Global shared browser instance for cron jobs
    GLOBAL_BROWSER = None
    GLOBAL_CONTEXT = None
    GLOBAL_PAGE = None
    
    # Shared browser from user sessions
    SHARED_SESSION_ID = None  # User ID whose session is shared
    CRON_TASK = None  # Store the cron task reference
    GLOBAL_PLAYWRIGHT = None  # Store the playwright instance 


class UserSession:
    def __init__(self):
        self.state: str = "initial"
        self.username: Optional[str] = None
        self.password: Optional[str] = None
        self.cookie_file: Optional[str] = None
        self.browser = None
        self.context = None
        self.page = None
        self.playwright = None
        self.last_activity = datetime.now()