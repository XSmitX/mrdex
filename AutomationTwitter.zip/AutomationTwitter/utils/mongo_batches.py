import uuid
from datetime import datetime
from pymongo.collection import Collection
from typing import List, Dict, Optional

def get_user_batch_collection(db, user_id):
    """Get the appropriate batch collection for a user"""
    try:
        # Try to import user collection helper
        from bot import get_user_db_collections
        collections = get_user_db_collections(user_id)
        return db[collections["images"]]
    except ImportError:
        # Fallback to default collection
        return db.twitter_image_batches

def create_image_batch(db, telegram_user_id: int, twitter_username: str, images: list, scenes: list = None, script_text: str = None, metadata: list = None) -> str:
    """Create a new image batch in MongoDB and return the batch_id.
    'images' is now a list of dicts: {'image_url': ..., 'file_id': ..., 'message_id': ...}
    'metadata' is an optional list of dicts: {'title': ..., 'description': ..., 'hashtags': ...}
    """
    if db is None:
        raise ValueError("Database connection is not available")
    batch_id = str(uuid.uuid4())
    
    # Ensure each image has a status field set to "pending"
    for i, image in enumerate(images):
        if "status" not in image:
            image["status"] = "pending"
        
        # Add metadata to each image if available
        if metadata and i < len(metadata):
            image["title"] = metadata[i].get("title", "")
            image["description"] = metadata[i].get("description", "")
            image["hashtags"] = metadata[i].get("hashtags", "")
    
    batch_doc = {
        "batch_id": batch_id,
        "telegram_user_id": telegram_user_id,
        "twitter_username": twitter_username,
        "created_at": datetime.utcnow(),
        "images": images,  # Now a list of dicts with status and metadata
        "status": "pending"
    }
    if scenes is not None:
        batch_doc["scenes"] = scenes
    if script_text is not None:
        batch_doc["script_text"] = script_text
    collection = get_user_batch_collection(db, telegram_user_id)
    collection.insert_one(batch_doc)
    return batch_id

def get_image_batch(db, telegram_user_id: int, twitter_username: str, batch_id: str) -> Optional[Dict]:
    """Retrieve an image batch from MongoDB by batch_id."""
    if db is None:
        return None
        
    # Get user-specific collection
    collection = get_user_batch_collection(db, telegram_user_id)
    return collection.find_one({"batch_id": batch_id, "telegram_user_id": telegram_user_id})

def update_image_status(db, telegram_user_id: int, twitter_username: str, batch_id: str, image_index: int, status: str) -> bool:
    """Update the status of a specific image in a batch."""
    if db is None:
        return False
        
    # Get user-specific collection
    collection = get_user_batch_collection(db, telegram_user_id)
    
    # Update the specific image in the batch
    result = collection.update_one(
        {"batch_id": batch_id, "telegram_user_id": telegram_user_id},
        {"$set": {f"images.{image_index}.status": status}}
    )
    return result.modified_count > 0

def delete_image_batch(db, telegram_user_id: int, twitter_username: str, batch_id: str) -> bool:
    """Delete an image batch from MongoDB."""
    if db is None:
        return False
        
    # Get user-specific collection
    collection = get_user_batch_collection(db, telegram_user_id)
    
    result = collection.delete_one({"batch_id": batch_id, "telegram_user_id": telegram_user_id})
    return result.deleted_count > 0 