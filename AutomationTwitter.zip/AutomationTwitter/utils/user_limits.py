from datetime import datetime

default_limits = {"max_accounts": 5, "max_cron_jobs": 10}  # Default limits

async def get_user_limits(user_id, db, logger):
    """Get user's account limits based on their tier"""
    try:
        if db is None:
            return default_limits
        user = db.users.find_one({"user_id": user_id})
        if user:
            return {
                "max_accounts": user.get("max_accounts", 5),
                "max_cron_jobs": user.get("max_cron_jobs", 10),
                "account_tier": user.get("account_tier", "free")
            }
        else:
            return default_limits
    except Exception as e:
        if logger:
            logger.error(f"Error getting user limits: {e}")
        return default_limits 