# Twitter Automation Bot Deployment Guide

This guide provides step-by-step instructions for deploying the Twitter Automation Bot on CentOS 9 Stream using Docker and docker-compose.

## Prerequisites

- CentOS 9 Stream server
- Root or sudo access
- Basic knowledge of Linux commands
- Domain name (optional, for SSL)

## 1. Server Setup

### Update System

```bash
sudo dnf update -y
sudo dnf upgrade -y
```

### Install Required Packages

```bash
# Install required packages
sudo dnf install -y dnf-plugins-core
sudo dnf install -y git curl wget
```

## 2. Install Docker and Docker Compose

### Install Docker

```bash
# Add Docker repository
sudo dnf config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo

# Install Docker
sudo dnf install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# Start and enable Docker
sudo systemctl start docker
sudo systemctl enable docker

# Add your user to the docker group (optional)
sudo usermod -aG docker $USER
```

You may need to log out and log back in for group changes to take effect.

### Install Docker Compose

```bash
# Install Docker Compose plugin
sudo dnf install -y docker-compose-plugin

# Verify installation
docker compose version
```

## 3. Clone the Repository

```bash
# Create a directory for the project
mkdir -p /opt/twitter-bot
cd /opt/twitter-bot

# Clone the repository
git clone https://github.com/yourusername/twitter-automation-bot.git .
```

## 4. Configuration

### Create Environment File

Create a `.env` file in the project directory with your configuration:

```bash
cd /opt/twitter-bot
cp .env.example .env
nano .env
```

Add the following content, replacing the placeholder values with your actual credentials:

```
BOT_TOKEN=your_telegram_bot_token
API_ID=your_telegram_api_id
API_HASH=your_telegram_api_hash
CHANNEL_ID=your_telegram_channel_id
ADMIN_USER_IDS=comma,separated,user,ids
OPENAI_API_KEY=your_openai_api_key
```

### Create Data Directories

```bash
mkdir -p data/cookies data/temp data/user_images data/logs data/mongodb
chmod -R 777 data
```

## 5. Deployment

### Build and Start the Containers

```bash
cd /opt/twitter-bot
docker compose up -d --build
```

This will build the Docker image and start the containers in detached mode.

### Check Container Status

```bash
docker compose ps
```

### View Logs

```bash
# View logs for all services
docker compose logs

# View logs for just the bot
docker compose logs twitter-bot

# Follow logs in real-time
docker compose logs -f twitter-bot
```

## 6. Maintenance

### Updating the Bot

To update the bot to the latest version:

```bash
cd /opt/twitter-bot
git pull
docker compose down
docker compose up -d --build
```

### Backup MongoDB Data

```bash
# Create a backup directory
mkdir -p /opt/backups

# Backup MongoDB data
docker exec twitter-bot-mongodb sh -c 'mongodump --archive' > /opt/backups/mongodb-$(date +%Y%m%d).archive
```

### Restore MongoDB Data

```bash
# Restore from backup
docker exec -i twitter-bot-mongodb sh -c 'mongorestore --archive' < /opt/backups/mongodb-YYYYMMDD.archive
```

## 7. Troubleshooting

### Container Not Starting

Check the logs for errors:

```bash
docker compose logs twitter-bot
```

### MongoDB Connection Issues

Verify MongoDB is running:

```bash
docker compose ps mongodb
```

Check MongoDB logs:

```bash
docker compose logs mongodb
```

### Browser Automation Issues

If you encounter issues with Playwright:

```bash
# Access the container shell
docker exec -it twitter-automation-bot bash

# Manually install browsers
playwright install chromium --with-deps
```

### Permission Issues

If you encounter permission issues with the data directories:

```bash
sudo chmod -R 777 /opt/twitter-bot/data
```

## 8. Security Considerations

- The MongoDB instance is not exposed outside the Docker network by default
- Consider adding authentication to MongoDB for production use
- Store sensitive environment variables securely
- Regularly update your Docker images and host system

## 9. Additional Configuration

### Setting Up as a System Service

Create a systemd service file:

```bash
sudo nano /etc/systemd/system/twitter-bot.service
```

Add the following content:

```
[Unit]
Description=Twitter Automation Bot
After=docker.service
Requires=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/opt/twitter-bot
ExecStart=/usr/bin/docker compose up -d
ExecStop=/usr/bin/docker compose down
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target
```

Enable and start the service:

```bash
sudo systemctl daemon-reload
sudo systemctl enable twitter-bot
sudo systemctl start twitter-bot
```

## 10. Monitoring

Consider setting up monitoring using tools like:

- Prometheus and Grafana
- Docker's built-in health checks (already configured in the Dockerfile)
- External monitoring services

For any issues or questions, please refer to the project's GitHub repository or contact the maintainers. 