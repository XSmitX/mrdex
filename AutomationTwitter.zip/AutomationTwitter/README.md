# Twitter Automation Bot - Deployment Guide

This guide explains how to deploy and run the Twitter Automation Bot on a VPS (Virtual Private Server) or RDP (Remote Desktop Protocol) server, ensuring it runs in headless mode with Playwright.

## Project Overview

This is a Twitter/X automation bot built with:
- **Pyrogram**: Telegram bot framework
- **Playwright**: Headless browser automation for Twitter/X scraping
- **MongoDB**: Database for storing accounts and posts
- **OpenAI**: For AI content generation

The bot can:
- Login to Twitter using cookies or credentials
- Scrape following accounts and their posts
- Generate AI content based on posts
- Run scheduled jobs (cronjobs) to fetch posts automatically
- Forward posts to a Telegram channel

## Prerequisites

- Ubuntu 20.04+, Debian-based VPS/RDP, or CentOS 9 Stream
- Python 3.8+ (for direct installation) or Docker
- At least 2GB RAM (4GB recommended)
- MongoDB Atlas account or self-hosted MongoDB

## Installation

### Option A: Direct Installation

1. **Clone the repository and navigate to the project folder**:
```bash
git clone <repository-url> twitter-bot
cd twitter-bot
```

2. **Create and activate a virtual environment**:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. **Install dependencies**:
```bash
pip install pyrogram playwright pymongo python-dotenv openai aiofiles aiohttp
```

4. **Install Playwright browsers**:
```bash
playwright install chromium
```

5. **Install system dependencies for headless browser**:
```bash
# On Ubuntu/Debian
apt-get update
apt-get install -y libatk1.0-0 libatk-bridge2.0-0 libcups2 libdrm2 libxkbcommon0 libxcomposite1 libxdamage1 libxfixes3 libxrandr2 libgbm1 libasound2 libpango-1.0-0 libcairo2 libatspi2.0-0 libnspr4 libnss3

# On CentOS 9 Stream
dnf update -y
dnf install -y alsa-lib atk cups-libs libdrm libXcomposite libXdamage libXrandr mesa-libgbm pango cairo at-spi2-atk nspr nss
```

### Option B: Docker Installation (Recommended for CentOS 9 Stream)

1. **Install Docker on CentOS 9 Stream**:
```bash
# Update system
sudo dnf update -y

# Install required packages
sudo dnf install -y yum-utils device-mapper-persistent-data lvm2

# Add Docker repository
sudo dnf config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo

# Install Docker
sudo dnf install -y docker-ce docker-ce-cli containerd.io

# Start and enable Docker
sudo systemctl start docker
sudo systemctl enable docker

# Verify Docker installation
sudo docker --version

# Add your user to the docker group (optional, to run docker without sudo)
sudo usermod -aG docker $USER
# Log out and log back in for this to take effect
```

2. **Install Docker Compose**:
```bash
sudo curl -L "https://github.com/docker/compose/releases/download/v2.18.1/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
sudo ln -s /usr/local/bin/docker-compose /usr/bin/docker-compose
docker-compose --version
```

3. **Create project directory and necessary files**:
```bash
mkdir -p twitter-bot/{temp,cookies,user_images}
cd twitter-bot
```

4. **Create Dockerfile**:
```bash
cat > Dockerfile << 'EOF'
FROM python:3.10-slim

# Set working directory
WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    libatk1.0-0 \
    libatk-bridge2.0-0 \
    libcups2 \
    libdrm2 \
    libxkbcommon0 \
    libxcomposite1 \
    libxdamage1 \
    libxfixes3 \
    libxrandr2 \
    libgbm1 \
    libasound2 \
    libpango-1.0-0 \
    libcairo2 \
    libatspi2.0-0 \
    libnspr4 \
    libnss3 \
    wget \
    gnupg \
    && rm -rf /var/lib/apt/lists/*

# Install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Install Playwright and browsers
RUN playwright install chromium
RUN playwright install-deps chromium

# Copy the bot code
COPY . .

# Create necessary directories
RUN mkdir -p temp cookies user_images

# Run the bot
CMD ["python", "bot.py"]
EOF
```

5. **Create requirements.txt**:
```bash
cat > requirements.txt << 'EOF'
pyrogram
tgcrypto
playwright
pymongo
python-dotenv
openai
aiofiles
aiohttp
EOF
```

6. **Create docker-compose.yml**:
```bash
cat > docker-compose.yml << 'EOF'
version: '3'

services:
  twitter-bot:
    build: .
    container_name: twitter-bot
    restart: always
    volumes:
      - ./cookies:/app/cookies
      - ./temp:/app/temp
      - ./user_images:/app/user_images
      - ./.env:/app/.env
      - ./twitter_bot.log:/app/twitter_bot.log
    environment:
      - PYTHONUNBUFFERED=1
EOF
```

## Configuration

1. **Create the necessary directories** (if not using Docker):
```bash
mkdir -p temp cookies user_images
```

2. **Set up environment variables**:
Edit the `.env` file with your credentials:

```
# Telegram Bot Values
API_ID=your_api_id
API_HASH=your_api_hash
BOT_TOKEN=your_bot_token

# OpenAI API Key
OPENAI_API_KEY=your_openai_api_key

# Channel for sending posts (private channel)
CHANNEL_ID=your_channel_id

# Admin user IDs (comma-separated if multiple)
ADMIN_USER_IDS=your_telegram_id

# MongoDB connection
MONGO_URI=your_mongodb_uri

# Twitter Credentials (for cronjobs)
DEFAULT_TWITTER_USERNAME="your_twitter_username"
DEFAULT_TWITTER_PASSWORD="your_twitter_password"

# Optional cookie file (if you have one)
DEFAULT_TWITTER_COOKIE_FILE=""

# Cron configurations
CRON_FETCH_INTERVAL="1"  # Minutes between fetches
CRON_MAX_POSTS="3"       # Maximum posts per account
CRON_ENABLED="true"      # Enable/disable cronjob
```

## Running the Bot

### Option 1: Direct Run (for testing)

```bash
python bot.py
```

### Option 2: Run as a Background Service with Systemd

1. **Create a systemd service file**:

```bash
sudo nano /etc/systemd/system/twitter-bot.service
```

2. **Add the following configuration**:

```
[Unit]
Description=Twitter Automation Bot
After=network.target

[Service]
Type=simple
User=<your-username>
WorkingDirectory=/path/to/twitter-bot
ExecStart=/path/to/twitter-bot/venv/bin/python /path/to/twitter-bot/bot.py
Restart=always
RestartSec=10
Environment="PYTHONUNBUFFERED=1"

[Install]
WantedBy=multi-user.target
```

3. **Enable and start the service**:

```bash
sudo systemctl daemon-reload
sudo systemctl enable twitter-bot
sudo systemctl start twitter-bot
```

4. **Check service status**:

```bash
sudo systemctl status twitter-bot
```

5. **View logs**:

```bash
sudo journalctl -u twitter-bot -f
```

### Option 3: Run with Screen

1. **Install screen**:

```bash
# Ubuntu/Debian
sudo apt-get install screen

# CentOS
sudo dnf install screen
```

2. **Create a new screen session**:

```bash
screen -S twitter-bot
```

3. **Activate the virtual environment and start the bot**:

```bash
cd /path/to/twitter-bot
source venv/bin/activate
python bot.py
```

4. **Detach from screen**: Press `Ctrl+A` then `D`

5. **Reattach to screen later**:

```bash
screen -r twitter-bot
```

### Option 4: Run with Docker (Recommended for CentOS)

1. **Build and start the Docker container**:

```bash
# Build the Docker image
docker-compose build

# Start the container
docker-compose up -d
```

2. **Check container logs**:

```bash
docker-compose logs -f
```

3. **Stop the container**:

```bash
docker-compose down
```

## How the Bot Logs into Twitter (Automated Process)

The bot automatically handles Twitter login in headless mode (no GUI required) using Playwright. The process works as follows:

1. **Cookie-based Authentication (Preferred Method)**:
   - If you have previously logged in and saved cookies, the bot will attempt to load them
   - Cookie files are stored in the `cookies/` directory
   - You can upload cookie files through the Telegram bot interface

2. **Credential-based Authentication**:
   - If cookies are unavailable/invalid, the bot uses the username/password from your `.env` file
   - The login process happens automatically in the background
   - After successful login, cookies are saved for future use

3. **For Cronjobs**:
   - The bot uses `DEFAULT_TWITTER_USERNAME` and `DEFAULT_TWITTER_PASSWORD` from your `.env` file
   - You can also specify `DEFAULT_TWITTER_COOKIE_FILE` if you have cookies

No manual intervention is required for the login process, making it ideal for terminal-based VPS environments.

## Headless Mode Configuration

The bot uses Playwright in headless mode by default. This configuration is already set in the `initialize_browser` and `initialize_global_browser` functions in the code:

```python
browser = await playwright.chromium.launch(
    headless=True,  # True for headless mode on VPS
    args=[
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--disable-gpu'
    ]
)
```

## Troubleshooting

### Browser Issues

If you encounter browser-related issues, try:

1. **Check system dependencies**:
```bash
playwright install-deps
```

2. **Update Playwright**:
```bash
pip install playwright --upgrade
playwright install --force
```

3. **Debug browser launch**:
Add these lines to test browser launching:
```bash
python -c "
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()
    print('Browser launched successfully')
    page.goto('https://x.com')
    print('Page loaded successfully')
    browser.close()
"
```

### Docker-specific Issues

1. **Permission problems**:
```bash
# Fix permissions for mounted volumes
sudo chown -R $(id -u):$(id -g) ./cookies ./temp ./user_images
```

2. **Check Docker logs**:
```bash
docker-compose logs -f
```

3. **Rebuild the container after changes**:
```bash
docker-compose down
docker-compose build
docker-compose up -d
```

### MongoDB Connection Issues

1. **Check your MongoDB connection string** in the `.env` file
2. **Verify network access** is allowed from your VPS IP in MongoDB Atlas
3. **Try connecting with MongoDB Compass** to verify connectivity

### Memory Issues

If the bot crashes due to memory limits:

1. **Increase swap space**:
```bash
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

2. **Reduce browser instances** by setting:
```
CRON_ENABLED="false"  # Disable automatic cronjobs
```

3. **Limit Docker container memory** (add to docker-compose.yml):
```yaml
services:
  twitter-bot:
    # ... existing configuration ...
    deploy:
      resources:
        limits:
          memory: 2G
```

## Monitoring and Maintenance

1. **Set up log rotation**:
```bash
sudo nano /etc/logrotate.d/twitter-bot
```

Add:
```
/path/to/twitter-bot/twitter_bot.log {
    daily
    rotate 7
    compress
    delaycompress
    missingok
    notifempty
    create 0640 root root
}
```

2. **Monitor the bot**:
- Check logs: `tail -f twitter_bot.log`
- Check service: `systemctl status twitter-bot`
- Monitor resources: `htop`
- Docker containers: `docker stats`

## Security Considerations

1. **Secure your .env file**:
```bash
chmod 600 .env
```

2. **Use a non-root user** to run the bot

3. **Set up a firewall**:
```bash
# For CentOS
sudo dnf install firewalld
sudo systemctl start firewalld
sudo systemctl enable firewalld
sudo firewall-cmd --permanent --add-service=ssh
sudo firewall-cmd --reload
```

4. **Keep system updated**:
```bash
# Ubuntu/Debian
sudo apt update && sudo apt upgrade -y

# CentOS
sudo dnf update -y
```

## Backup

Regularly backup your data:

1. **Cookie files**:
```bash
tar -czvf cookies_backup.tar.gz cookies/
```

2. **MongoDB data** (if self-hosted):
```bash
mongodump --uri="your_mongo_uri" --out=backup
```

3. **Docker volumes** (if using Docker):
```bash
docker-compose down
tar -czvf twitter-bot-data.tar.gz cookies/ temp/ user_images/ .env
```

## Contact & Support

For issues and support, please contact the administrator or open an issue on the repository. 