from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
import asyncio

import os
import sys
import logging
import json
import uuid
import asyncio
import aiohttp
import tempfile
import pickle
import time
import re
from datetime import datetime, timedelta
from functools import wraps
from typing import Dict, List, Optional, Union, Any, Callable

from pymongo import MongoClient
from pymongo.errors import PyMongoError
from dotenv import load_dotenv
import re

from collections import deque, defaultdict
import csv
import uuid
from ImageGen import  generate_consolidated_image , send_image_with_retry, extract_scenes_from_script, extract_scene_metadata
from AI_Content_gen import generate_ai_content
from utils.scraper import (
    validate_and_load_cookies, verify_login, fetch_following_accounts, extract_logged_in_username, login_with_credentials,
    fetch_following_recent_posts
)

from utils.cronjob import handle_cron_actions, fetch_cronjob_posts, scheduled_user_cronjob_task , add_cronjob_account , remove_cronjob_account , get_cronjob_accounts
from utils.config import Config , UserSession
from browser_initialization import cleanup_session, initialize_browser, cleanup_specific_account
from send_post import send_posts_to_channel
from fetch_extract_post import fetch_account_posts
from Image_post import post_image_to_twitter
import aiohttp
from utils.mongo_batches import create_image_batch, get_image_batch, update_image_status, delete_image_batch
from utils.user_limits import get_user_limits


# Initialize the bot
bot = Client(
    "twitter_bot",
    api_id=Config.API_ID,
    api_hash=Config.API_HASH,
    bot_token=Config.BOT_TOKEN
)
# Dictionaries to store user sessions and states
user_sessions = {}  # {telegram_user_id: {"active": twitter_username, "accounts": {twitter_username: UserSession}}}
user_states = {}    # {telegram_user_id: state}
active_fetch_jobs = {}  # Track active fetch jobs per user

# Temporary store for image URLs to avoid putting long URLs in callback data
post_to_twitter_temp = {}

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('twitter_bot.log'),
        logging.StreamHandler()  # This will print to terminal
    ]
)
logger = logging.getLogger(__name__)

# Add at the top of the file
_get_messages_cache = {}
async def get_message_with_cache(client, chat_id, message_id):
    key = (chat_id, message_id)
    if key in _get_messages_cache:
        return _get_messages_cache[key]
    msg = await client.get_messages(chat_id=chat_id, message_ids=message_id)
    _get_messages_cache[key] = msg
    return msg



# Custom log handler to capture logs for the bot
class BotLogHandler(logging.Handler):
    def __init__(self):
        super().__init__()
        self.log_queue = {}  # Store logs by user_id
        
    def emit(self, record):
        if hasattr(record, 'user_id'):
            user_id = record.user_id
            if user_id not in self.log_queue:
                self.log_queue[user_id] = []
            
            # Format the log message
            log_entry = self.format(record)
            self.log_queue[user_id].append(log_entry)
            
    def get_logs(self, user_id):
        """Get and clear logs for a specific user"""
        if user_id in self.log_queue and self.log_queue[user_id]:
            logs = self.log_queue[user_id].copy()
            self.log_queue[user_id] = []
            return logs
        return []

bot_log_handler = BotLogHandler()
bot_log_handler.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
logger.addHandler(bot_log_handler)


async def send_log_update(client, user_id, message, level="INFO"):
    """Send a log message to the user and also log it to the system log"""
    try:
        # Add user_id to the log record
        logger_adapter = logging.LoggerAdapter(logger, {"user_id": user_id})
        
        # Log the message based on level
        if level.upper() == "ERROR":
            logger_adapter.error(message)
        elif level.upper() == "WARNING":
            logger_adapter.warning(message)
        else:
            logger_adapter.info(message)
        
        # Send a new message
        try:
            sent_message = await client.send_message(
                chat_id=user_id,
                text=f"🔄 {level.upper()}: {message}"
            )
            # Delete after 5 seconds if it's an info message
            if level.upper() == "INFO":
                asyncio.create_task(auto_delete_message(client, user_id, sent_message.id, 5))
        except Exception as e:
            logger.error(f"Failed to send log update to user {user_id}: {e}")
    except Exception as e:
        logger.error(f"Error in send_log_update: {e}")



# Create queues for posts and AI tasks
post_queue = defaultdict(deque)  # Separate queue per user
ai_task_queue = defaultdict(deque)  # Separate queue per user
is_processing = defaultdict(bool)  # Track processing state per user

async def process_queues(user_id):
    """Process post and AI task queues for a specific user"""
    if is_processing[user_id]:
        return
        
    try:
        is_processing[user_id] = True
        while post_queue[user_id] or ai_task_queue[user_id]:
            # Process AI tasks first as they're user-interactive
            while ai_task_queue[user_id]:
                task = ai_task_queue[user_id].popleft()
                await task
                await asyncio.sleep(0.5)  # Small delay between AI tasks
                
            # Then process posts
            while post_queue[user_id]:
                post_task = post_queue[user_id].popleft()
                await post_task
                await asyncio.sleep(1)  # Delay between posts
    finally:
        is_processing[user_id] = False


# MongoDB connection
mongo_client = None
db = None

def init_mongodb():
    """Initialize MongoDB connection"""
    global mongo_client, db
    try:
        mongo_client = MongoClient(Config.MONGO_URI)
        db = mongo_client[Config.DB_NAME]
        # Test the connection
        mongo_client.admin.command('ping')
        logger.info("Successfully connected to MongoDB Atlas")
        return True
    except PyMongoError as e:
        logger.error(f"Failed to connect to MongoDB: {e}")
        return False

def get_user_db_collections(user_id):
    """
    Get user-specific database collections
    
    This function returns a dictionary of collection names specific to a user.
    Each user's data is stored in separate collections with user_id prefix.
    
    Args:
        user_id: The Telegram user ID
        
    Returns:
        dict: Dictionary with collection names for this user
    """
    if not user_id:
        return {
            "accounts": Config.ACCOUNTS_COLLECTION,
            "posts": Config.POSTS_COLLECTION,
            "cronjob": Config.CRONJOB_COLLECTION,
            "images": "twitter_image_batches"
        }
    
    # Create user-specific collection names
    user_prefix = f"user_{user_id}_"
    return {
        "accounts": f"{user_prefix}twitter_accounts",
        "posts": f"{user_prefix}twitter_posts",
        "cronjob": f"{user_prefix}cronjob_accounts",
        "images": f"{user_prefix}twitter_image_batches"
    }

async def ensure_user_collections(user_id):
    """
    Ensure that all required collections exist for a user
    
    Args:
        user_id: The Telegram user ID
        
    Returns:
        bool: True if collections were created/exist, False otherwise
    """
    try:
        if db is None:
            logger.error("Database connection not available")
            return False
            
        collections = get_user_db_collections(user_id)
        
        # Check if collections exist, create if they don't
        for collection_name in collections.values():
            if collection_name not in db.list_collection_names():
                # Create the collection by inserting and removing a dummy document
                db[collection_name].insert_one({"_dummy": True})
                db[collection_name].delete_one({"_dummy": True})
                logger.info(f"Created collection {collection_name} for user {user_id}")
        
        return True
    except Exception as e:
        logger.error(f"Error ensuring user collections: {e}")
        return False

async def store_accounts_batch(accounts_data, user_id=None):
    """Store multiple Twitter accounts in MongoDB"""
    try:
        if db is None or not accounts_data:
            return False
            
        # Get the appropriate collection for this user
        collections = get_user_db_collections(user_id)
        accounts_collection = collections["accounts"]
        
        # Add timestamp to all records
        timestamp = datetime.now()
        
        for account in accounts_data:
            account["updated_at"] = timestamp
            account["user_id"] = user_id  # Associate with the user
            
            try:
                # Update or insert each document individually
                db[accounts_collection].update_one(
                    {"username": account["username"], "user_id": user_id},
                    {"$set": account},
                    upsert=True
                )
            except PyMongoError as e:
                logger.error(f"Error storing account {account.get('username')} for user {user_id}: {e}")
        
        logger.info(f"Stored {len(accounts_data)} accounts in database for user {user_id}")
        return True
    except PyMongoError as e:
        logger.error(f"MongoDB error during batch store: {e}")
        return False


# Store user sessions
user_sessions: Dict[int, UserSession] = {}
user_states: Dict[int, str] = {}
global START_KEYBOARD
# Keyboard markups
START_KEYBOARD = InlineKeyboardMarkup([
    [
        InlineKeyboardButton("🍪 Login with Your Cookies", callback_data="login_cookies"),
        InlineKeyboardButton("🔑 Login with Password", callback_data="login_credentials"),
    ],
    [InlineKeyboardButton("ℹ️ Help", callback_data="help")]])
LOGGED_IN_KEYBOARD = InlineKeyboardMarkup([
    [
        InlineKeyboardButton("👥 Following List", callback_data="get_following"),
        InlineKeyboardButton("📊 CronJob Accounts", callback_data="cron_menu")
    ],
    [
        InlineKeyboardButton("❌ Logout", callback_data="logout")
    ]
])

# Add a helper function to validate channel ID

# Helper functions

# Function to auto-delete messages after a timeout
async def auto_delete_message(client, chat_id, message_id, delay=5):
    """Delete a message after specified delay in seconds"""
    await asyncio.sleep(delay)
    try:
        await client.delete_messages(chat_id, message_id)
    except Exception as e:
        logger.error(f"Failed to auto-delete message: {e}")

# Database functions
async def store_posts_in_db(posts_data, source_username, user_id=None):
    """Store Twitter posts in MongoDB with improved duplicate checking and return stored posts"""
    try:
        if db is None or not posts_data:
            return []
            
        # Get the appropriate collection for this user
        collections = get_user_db_collections(user_id)
        posts_collection = collections["posts"]
        
        timestamp = datetime.now()
        stored_posts = []
        duplicate_count = 0
        
        for post in posts_data:
            if "id" not in post:
                logger.warning(f"Post missing ID field, skipping")
                continue
                
            # Add user_id to the post data
            post["user_id"] = user_id
                
            # More comprehensive duplicate checking - include multiple fields
            duplicate_query = {
                "$and": [
                    {"user_id": user_id},
                    {"$or": [
                        # Check for same ID
                        {"id": post["id"]},
                        # Check for same URL if available
                        {"url": post.get("url")} if "url" in post else {"_id": None}, 
                        # Check for same text + author combination
                        {
                            "text": post.get("text"), 
                            "author": post.get("author")
                        } if "text" in post and "author" in post else {"_id": None}
                    ]}
                ]
            }
            
            existing_post = None
            try:
                existing_post = db[posts_collection].find_one(duplicate_query)
            except Exception as e:
                logger.error(f"Error checking for duplicate post: {e}")
            
            if existing_post:
                duplicate_count += 1
                logger.debug(f"Skipping duplicate post {post.get('id')} from @{post.get('author')} for user {user_id}")
                continue
            
            # Update post metadata
            post["stored_at"] = timestamp
            post["fetched_by"] = source_username
            post["source"] = "cronjob" if source_username == "cronjob" else source_username
            post["sent_to_channel"] = False
            post["fetch_count"] = 1  # Initialize fetch count
            
            try:
                # Insert new post
                result = db[posts_collection].insert_one(post)
                if result.inserted_id:
                    stored_posts.append(post)
                    logger.debug(f"Stored new post {post['id']} in database for user {user_id}")
            except PyMongoError as e:
                logger.error(f"Error storing post {post.get('id')}: {e}")
        
        stored_count = len(stored_posts)
        if stored_count > 0:
            logger.info(f"Stored {stored_count} new posts in database for user {user_id} (skipped {duplicate_count} duplicates)")
        elif duplicate_count > 0:
            logger.info(f"All {duplicate_count} posts were duplicates for user {user_id}, nothing new to store")
            
        return stored_posts
    except PyMongoError as e:
        logger.error(f"MongoDB error during posts storage: {e}")
        return []

async def fetch_and_store_following(page, username, max_accounts=20, user_id=None):
    """Fetch following accounts and store them in MongoDB"""
    try:
        accounts = await fetch_following_accounts(page, username, max_accounts)
        if accounts:
            # Add source information
            for account in accounts:
                account["source"] = username
                account["fetched_at"] = datetime.now().isoformat()
                account["user_id"] = user_id  # Associate with the user
                
            # Store in database
            await store_accounts_batch(accounts, user_id)
            
        return accounts
    except Exception as e:
        logger.error(f"Error in fetch_and_store_following: {e}")
        return []

async def fetch_and_store_following_posts(page, username, max_following=10, max_posts=3, min_posts=1, user_id=None):
    """Fetch posts from following accounts and store them in MongoDB"""
    try:
        # Update to use the non-pinned posts function
        posts_data = await fetch_following_recent_posts(page, username, max_following, max_posts, min_posts)
        
        # Extract posts data depending on format returned
        if isinstance(posts_data, dict) and "following_posts" in posts_data:
            following_posts = posts_data["following_posts"]
        elif isinstance(posts_data, list):
            following_posts = posts_data
        else:
            logger.error(f"Unknown posts data format: {type(posts_data)}")
            return []
        
        # Flatten posts for storage
        all_posts = []
        for account_data in following_posts:
            if isinstance(account_data, dict) and "posts" in account_data and account_data["posts"]:
                for post in account_data["posts"]:
                    post["account_username"] = account_data.get("username")
                    post["account_display_name"] = account_data.get("name")
                    all_posts.append(post)
        
        # Store posts in database
        if all_posts:
            await store_posts_in_db(all_posts, username, user_id)
                
        return following_posts
    except Exception as e:
        logger.error(f"Error in fetch_and_store_following_posts: {e}")
        return []

# Authorization check
async def is_authorized(user_id):
    """Check if a user is authorized to use the bot"""
    try:
        admin_ids = os.getenv("ADMIN_USER_IDS", "").split(",")
        admin_ids = [aid.strip() for aid in admin_ids if aid.strip()]
        return str(user_id) in admin_ids
    except Exception as e:
        logger.error(f"Error checking authorization: {e}")
        return False

# Handler for cron-related actions
@bot.on_callback_query(filters.regex(r"^cron_"))
async def cron_actions_handler(client, callback_query):
    await handle_cron_actions(
        client,
        callback_query,
        db=db,
        Config=Config,
        logger=logger,
        user_sessions=user_sessions,
        user_states=user_states,
        get_cronjob_accounts=get_cronjob_accounts,
        fetch_cronjob_posts=fetch_cronjob_posts,
        format_post_for_channel=format_post_for_channel,
        remove_cronjob_account=remove_cronjob_account
    )

# Command handlers
@bot.on_message(filters.command("start"))
async def start_command(client: Client, message: Message):
    """Handle /start command"""
    user_id = message.from_user.id
    username = message.from_user.username or f"user_{user_id}"
    first_name = message.from_user.first_name
    last_name = message.from_user.last_name
    
    # Register or update user
    registration_success = await register_user(user_id, username, first_name, last_name)
    if not registration_success:
        await message.reply("⚠️ There was an issue with registration. Some features might be limited.")
    
    # Update user activity
    await update_user_activity(user_id)
    
    # Single-account: check if user already has a session
    if user_id in user_sessions and isinstance(user_sessions[user_id], UserSession) and user_sessions[user_id].state == "logged_in":
        twitter_username = user_sessions[user_id].username
        await message.reply(
            f"✅ You are already logged in as @{twitter_username}.\n\n"
            f"🤖 Welcome to Twitter Automation Bot!\n\n"
            f"Features:\n"
            f"• Set up cron jobs to monitor Twitter accounts\n"
            f"• Generate AI content and images\n"
            f"• Post directly to Twitter\n\n"
            f"What would you like to do?",
            reply_markup=LOGGED_IN_KEYBOARD
        )
        return
        
    # If not logged in, show login options
    user_sessions[user_id] = {"_pending": UserSession()}
    if user_id == 6121699672:
        START_KEYBOARD2 = InlineKeyboardMarkup([
        [
        InlineKeyboardButton("🍪 Login with Your Cookies", callback_data="login_cookies"),
        InlineKeyboardButton("🔑 Login with Password", callback_data="login_credentials"),],
        [InlineKeyboardButton("🧪 Test Account: mrxed0158", callback_data="test_mrxed0158")],
        [InlineKeyboardButton("ℹ️ Help", callback_data="help")]])
        await message.reply(
        f"🤖 Welcome to Twitter Automation Bot!\n\n"
        f"Easily automate your Twitter/X account from Telegram.\n\n"
        f"Key Features:\n"
        f"• Set up cron jobs to monitor Twitter accounts\n"
        f"• AI content and image generation\n"
        f"• Post directly to Twitter\n\n"
        f"To get started, choose your login method below:",
    
        reply_markup=START_KEYBOARD2
    )
    else:
        await message.reply(
        f"🤖 Welcome to Twitter Automation Bot!\n\n"
        f"Easily automate your Twitter/X account from Telegram.\n\n"
        f"Key Features:\n"
        f"• Set up cron jobs to monitor Twitter accounts\n"
        f"• AI content and image generation\n"
        f"• Post directly to Twitter\n\n"
        f"To get started, choose your login method below:",
    
        reply_markup=START_KEYBOARD
    )

@bot.on_message(filters.private & ~filters.command(["start", "cron", "help", "setchannel", "channel"]) & ~filters.forwarded)
async def handle_all_messages(client, message):
    """Handle all other messages"""
    user_id = message.from_user.id
    
    if user_id not in user_sessions:
        await message.reply("⚠️ Please start with /start")
        return
    
    # Check if the user is waiting to add a Twitter account to cronjob
    if user_id in user_states and user_states[user_id] == "waiting_for_cron_username":
        # Extract Twitter username from message
        twitter_username = extract_twitter_username(message.text)
        
        if not twitter_username:
            await message.reply("❌ Invalid Twitter username or URL. Please try again.")
            return
            
        # Get active Twitter account username
        twitter_account = None
        if user_id in user_sessions and isinstance(user_sessions[user_id], UserSession):
            twitter_account = user_sessions[user_id].username
        
        # Try to add the account to cronjob tracking
        status_message = await message.reply(f"⏳ Adding @{twitter_username} to tracked accounts...")
        
        try:
            success = await add_cronjob_account(twitter_username, db, Config, logger, user_id=user_id, account_username=twitter_account)
            if success:
                await status_message.edit_text(
                    f"✅ Successfully added @{twitter_username} to tracked accounts.\n\n"
                    f"The bot will now fetch {Config.CRON_MAX_POSTS_PER_ACCOUNT} most recent posts every {Config.CRON_FETCH_INTERVAL} minutes.",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("Back to Menu", callback_data="back_to_menu")
                    ]])
                )
            else:
                await status_message.edit_text(
                    f"❌ Failed to add @{twitter_username} to tracked accounts. It may already be tracked or you've reached your limit.",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("Back to Menu", callback_data="back_to_menu")
                    ]])
                )
        except Exception as e:
            logger.error(f"Error adding Twitter account to cronjob: {e}")
            await status_message.edit_text(
                f"❌ Error adding @{twitter_username} to tracked accounts.",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("Back to Menu", callback_data="back_to_menu")
                ]])
            )
            
        # Clear the state
        user_states.pop(user_id, None)
        return
    
    # Check if user has a pending session (for new account login)
    if isinstance(user_sessions[user_id], dict) and "_pending" in user_sessions[user_id]:
        session = user_sessions[user_id]["_pending"]
        
        if session.state == "waiting_for_username":
            # Handle username input for login
            username = message.text.strip()
            if not username:
                await message.reply("❌ Please enter a valid username")
                return
            
            session.username = username
            session.state = "waiting_for_password"
            
            await message.reply(
                "🔑 Please enter your Twitter/X password:",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("Cancel", callback_data="back_to_start")
                ]])
            )
            
            return
            
        elif session.state == "waiting_for_password":
            # Handle password input
            password = message.text.strip()
            if not password:
                await message.reply("❌ Please enter a valid password")
                return
            await message.delete()
            status_message = await message.reply("🔄 Logging in...")
            
            try:
                # Initialize browser
                if not await initialize_browser(user_id, user_sessions, Config, logger):
                    await status_message.edit_text("❌ Failed to initialize browser")
                    await cleanup_session(user_id, user_sessions, Config, logger)
                    return
                
                # Attempt login
                if await login_with_credentials(session.page, session.username, password):
                    # Verify login
                    if await verify_login(session.page):
                        username = await extract_logged_in_username(session.page)
                        if username:
                            # Handle successful login
                            await status_message.delete()
                            await handle_login_success(client, message, username, user_id)
                            return
                
                # Login failed
                await status_message.edit_text(
                    "❌ Login failed. Please check your credentials and try again with /start"
                )
                await cleanup_session(user_id, user_sessions, Config, logger)
                
            except Exception as e:
                logger.error(f"Error in credential login: {e}")
                await status_message.edit_text(
                    "❌ An error occurred. Please try again with /start"
                )
                await cleanup_session(user_id, user_sessions, Config, logger)
            return
    
    # Handle other messages when user is logged in
    if isinstance(user_sessions[user_id], UserSession) and user_sessions[user_id].state == "logged_in":
        await message.reply(
            "I received your message. Use the menu options or commands like /cron, /setchannel, or /channel to interact with the bot."
        )
        return
    
    # Handle other messages
    await message.reply(
        "❓ I don't understand that command. Use /start to begin."
    )

# Function to extract Twitter username from various formats
def extract_twitter_username(text):
    """Extract a Twitter username from various formats"""
    text = text.strip()
    
    # Handle direct username
    if not any(c in text for c in [' ', '/', '@']):
        return text
    
    # Handle @username format
    if text.startswith('@') and ' ' not in text:
        return text[1:]
    
    # Handle URL formats
    url_patterns = [
        r"(?:https?:\/\/)?(?:www\.)?twitter\.com\/([a-zA-Z0-9_]+)",
        r"(?:https?:\/\/)?(?:www\.)?x\.com\/([a-zA-Z0-9_]+)"
    ]
    
    for pattern in url_patterns:
        match = re.search(pattern, text)
        if match:
            return match.group(1)
    
    return None

# Handler for cron command to manage Twitter account tracking
@bot.on_message(filters.command("cron") & filters.private)
async def cron_command(client, message):
    """Handler for the /cron command to manage tracking Twitter accounts"""
    user_id = message.from_user.id
    
    # Check if user is logged in
    if user_id not in user_sessions or not isinstance(user_sessions[user_id], UserSession) or user_sessions[user_id].state != "logged_in":
        await message.reply("❌ You need to be logged in to use this command. Please use /start to log in.")
        return
    
    session = user_sessions[user_id]
    if not session.page:
        await message.reply("❌ Browser session not initialized. Please restart with /start")
        return
    
    # Display the cron menu
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("Add Twitter Account", callback_data="cron_add")],
        [InlineKeyboardButton("List Tracked Accounts", callback_data="cron_list")],
        [InlineKeyboardButton("Back to Menu", callback_data="back_to_menu")]
    ])
    
    await message.reply(
        f"Twitter Account Tracking Management:\n"
        f"Your account: @{session.username}\n"
        f"You can track multiple Twitter accounts to monitor their posts.",
        reply_markup=keyboard
    )

# Handler for login actions
@bot.on_callback_query(filters.regex('^(login_|test_)'))
async def handle_login_choice(client: Client, callback_query: CallbackQuery):
    """Handle login method choice"""
    user_id = callback_query.from_user.id
    action = callback_query.data
    
    # Acknowledge the callback query
    await callback_query.answer()
    
    # Single-account: prepare for new session
    if user_id not in user_sessions:
        user_sessions[user_id] = {"_pending": UserSession()}
    else:
        user_sessions[user_id] = {"_pending": UserSession()}
    
    session = user_sessions[user_id]["_pending"]
    
    if action.startswith('login_'):
        # Handle regular login
        method = action.replace('login_', '')
        
        if method == 'cookies':
            session.state = "waiting_for_cookies"
            await callback_query.message.edit_text(
                "📁 Please send your Twitter/X cookie file (JSON format).\n\n"
                "To get your cookies:\n"
                "1. Log in to Twitter/X in your browser\n"
                "2. Use a cookie exporter extension\n"
                "3. Export all cookies as JSON\n"
                "4. Send the file here"
            )
        elif method == 'credentials':
            session.state = "waiting_for_username"
            await callback_query.message.edit_text(
                "👤 Please enter your Twitter/X username:"
            )
        else:
            await callback_query.message.edit_text(
                "❌ Invalid login method. Please try again with /start"
            )
            user_sessions[user_id].pop("_pending", None)
    
    elif action.startswith('test_'):
        # Handle test account login
        test_username = action.replace('test_', '')
        if test_username in Config.TEST_ACCOUNTS:
            cookie_file = os.path.join(Config.COOKIE_DIR, Config.TEST_ACCOUNTS[test_username])
            
            if not os.path.exists(cookie_file):
                await callback_query.message.edit_text(
                    f"❌ Test account cookie file not found: {cookie_file}"
                )
                await cleanup_session(user_id, user_sessions, Config, logger)
                return
            
            # Initialize browser
            status_message = await callback_query.message.edit_text(
                "🌐 Initializing browser..."
            )
            
            if not await initialize_browser(user_id, user_sessions, Config, logger):
                await status_message.edit_text("❌ Failed to initialize browser")
                await cleanup_session(user_id, user_sessions, Config, logger)
                return
            
            # Load and validate cookies
            try:
                cookie_result = await validate_and_load_cookies(session.context, cookie_file)
                
                if not cookie_result:
                    await status_message.edit_text(
                        "❌ Invalid cookies. Please make sure:\n"
                        "1. Your cookies are fresh and valid\n" 
                        "2. You exported ALL cookies from Twitter/X\n"
                        "3. You're logged in when exporting cookies\n\n"
                        "Try again with /start"
                    )
                    await cleanup_session(user_id, user_sessions, Config, logger)
                    return
                
                # Navigate to Twitter home
                await session.page.goto("https://x.com/home", timeout=60000)
                
                # Verify login
                if await verify_login(session.page):
                    username = await extract_logged_in_username(session.page)
                    if username:
                        await status_message.delete()                        # Handle successful login
                        await handle_login_success(client, callback_query.message, username, user_id)
                        return
                
                # Login verification failed
                await status_message.edit_text(
                    "❌ Failed to verify login. Please try again with /start"
                )
                await cleanup_session(user_id, user_sessions, Config, logger)
                
            except Exception as e:
                logger.error(f"Error in test account login: {e}")
                await status_message.edit_text(
                    "❌ An error occurred. Please try again with /start"
                )
                await cleanup_session(user_id, user_sessions, Config, logger)
        else:
            await callback_query.message.edit_text(
                "❌ Invalid test account. Please try again with /start"
            )
            await cleanup_session(user_id, user_sessions, Config, logger)

@bot.on_message(filters.document & filters.private)
async def handle_cookie_file(client: Client, message: Message):
    """Handle cookie file upload"""
    user_id = message.from_user.id
    
    if user_id not in user_sessions or "_pending" not in user_sessions[user_id] or user_sessions[user_id]["_pending"].state != "waiting_for_cookies":
        await message.reply("⚠️ Please start with /start and select 'Login with Your Cookies'")
        return
    
    session = user_sessions[user_id]["_pending"]
    
    if not message.document.file_name.endswith('.json'):
        await message.reply("❌ Please send a JSON cookie file")
        return
    
    status_message = await message.reply("⏳ Processing cookies...")
    
    try:
        # Download cookie file
        cookie_file = await message.download(
            file_name=f"{Config.TEMP_DIR}/{user_id}_cookies.json"
        )
        
        # Initialize browser
        await status_message.edit_text("🌐 Browser Initialized ")
        
        if not await initialize_browser(user_id, user_sessions, Config, logger):
            await status_message.edit_text("❌ Failed to initialize browser")
            return
        
        await status_message.edit_text("🔄 Loading cookies...")
        
        # Load and validate cookies
        try:
            # Add cookies to browser
            cookie_result = await validate_and_load_cookies(session.context, cookie_file)
            
            if not cookie_result:
                await status_message.edit_text(
                    "❌ Invalid cookies. Please make sure:\n"
                    "1. Your cookies are fresh and valid\n" 
                    "2. You exported ALL cookies from Twitter/X\n"
                    "3. You're logged in when exporting cookies\n\n"
                    "Try again with /start"
                )
                await cleanup_session(user_id, user_sessions, Config, logger)
                return
            
            # Navigate to Twitter home
            await session.page.goto("https://x.com/home", timeout=60000)
            
            # Verify login
            if await verify_login(session.page):
                username = await extract_logged_in_username(session.page)
                if username:
                    # Handle successful login
                    await handle_login_success(client, message, username, user_id)
                    return
            
            # Login verification failed
            await status_message.edit_text(
                "❌ Failed to verify login. Please try again with /start"
            )
            await cleanup_session(user_id, user_sessions, Config, logger)
            
        except Exception as e:
            logger.error(f"Error in cookie login: {e}")
            await status_message.edit_text(
                "❌ An error occurred. Please try again with /start"
            )
            await cleanup_session(user_id, user_sessions, Config, logger)
            
    except Exception as e:
        logger.error(f"Error processing cookie file: {e}")
        await status_message.edit_text(
            "❌ Error processing cookie file. Please try again with /start"
        )
        await cleanup_session(user_id, user_sessions, Config, logger)

async def handle_login_success(client: Client, message: Message, username: str, user_id: int):
    """Handle successful login for single-account per user"""
    try:
        # Single-account: store session directly in user_sessions
        if user_id in user_sessions and "_pending" in user_sessions[user_id]:
            session = user_sessions[user_id]["_pending"]
            session.username = username
            session.state = "logged_in"
            
            # Replace any existing session with the new one
            user_sessions[user_id] = session
            
            # Start a user-specific cron task
            asyncio.create_task(start_cron_task(user_id))
            
            await message.reply(
                f"✅ Successfully logged in as @{username}\n\n"
                f"Your personal cron job is now running using your session.\n"
                "What would you like to do?",
                reply_markup=LOGGED_IN_KEYBOARD
            )
        else:
            await message.reply("❌ Session not found. Please try again with /start")
    except Exception as e:
        logger.error(f"Error in handle_login_success: {e}")
        await message.reply("❌ An error occurred. Please try again.")

# Update the start_cron_task function to be more robust
async def start_cron_task(user_id=None):
    """Start the cron task for fetching posts periodically"""
    logger.info(f"Starting cron task for user {user_id if user_id else 'global'}")
    
    # Cancel existing task if it exists for this user
    if hasattr(Config, 'USER_CRON_TASKS') and user_id in Config.USER_CRON_TASKS:
        Config.USER_CRON_TASKS[user_id].cancel()
        try:
            await Config.USER_CRON_TASKS[user_id]
        except asyncio.CancelledError:
            pass
        Config.USER_CRON_TASKS[user_id] = None
        
    # Check for required parameters
    if db is None:
        logger.error("Database connection is not available. Cannot start cron task.")
        return False
        
    if bot is None:
        logger.error("Bot instance is not available. Cannot start cron task.")
        return False
    
    # Initialize USER_CRON_TASKS dict if it doesn't exist
    if not hasattr(Config, 'USER_CRON_TASKS'):
        Config.USER_CRON_TASKS = {}
    
    # Ensure user-specific collections exist
    if user_id:
        await ensure_user_collections(user_id)
    
    # Create and store a new task for this user
    if user_id:
        # Create a user-specific cron task
        Config.USER_CRON_TASKS[user_id] = asyncio.create_task(
            scheduled_user_cronjob_task(
                user_id,
                db,
                Config,
                logger,
                user_sessions,
                get_cronjob_accounts,
                fetch_account_posts,
                store_posts_in_db,
                send_posts_to_channel,
                format_post_for_channel,
                bot
            )
        )
        logger.info(f"User-specific cron task started for user {user_id}")
    else:
        # Legacy global cron task (can be removed if all users have their own tasks)
        logger.info("CRON TASK NOT STARTED : start_cron_task() ")
    
    return True


# Modify the function that starts the scheduled task

# Now, update the handler for callbacks after login to automatically start the shared cron job
@bot.on_callback_query(filters.regex('^(refresh|logout|help)$'))
async def handle_utility_actions(client: Client, callback_query: CallbackQuery):
    """Handle utility actions like refresh, logout, and help"""
    user_id = callback_query.from_user.id
    action = callback_query.data
    
    # Acknowledge the callback query
    await callback_query.answer()
    
    # Check if user has an active session
    if user_id not in user_sessions and action != "help":
        await callback_query.message.edit_text(
            "⚠️ Your session has expired. Please start again with /start"
        )
        return
    
    if action == "refresh":
        session = user_sessions[user_id]
        
        # Refresh the session
        status_message = await callback_query.message.edit_text("🔄 Refreshing session...")
        
        # Close existing browser instance
        try:
            if session.page:
                await session.page.close()
            if session.context:
                await session.context.close()
            if session.browser:
                await session.browser.close()
            if session.playwright:
                await session.playwright.stop()
        except Exception as e:
            logger.error(f"Error closing browser: {e}")
        
        # Reinitialize browser
        try:
            if not await initialize_browser(user_id, user_sessions, Config, logger):
                await status_message.edit_text("❌ Failed to refresh browser session")
                await cleanup_session(user_id, user_sessions, Config, logger)
                return
            
            # Navigate to Twitter home
            await session.page.goto("https://x.com/home", timeout=60000)
            
            # Verify session
            if await verify_login(session.page):
                username = await extract_logged_in_username(session.page)
                if username:
                    session.username = username
                    
                    # Restart the user's cron task
                    asyncio.create_task(start_cron_task(user_id))
                    
                    await status_message.edit_text(
                        f"✅ Session refreshed! Logged in as @{username}\n"
                        f"Your personal cron job has been restarted.\n"
                        "What would you like to do?",
                        reply_markup=LOGGED_IN_KEYBOARD
                    )
                    return
            
            # Session refresh failed
            await status_message.edit_text(
                "❌ Failed to refresh session. Please login again."
            )
            await cleanup_session(user_id, user_sessions, Config, logger)
            
        except Exception as e:
            logger.error(f"Error refreshing session: {e}")
            await status_message.edit_text("❌ An error occurred. Please try again.")
            await cleanup_session(user_id, user_sessions, Config, logger)
    
    elif action == "logout":
        # Cancel the user's cron task if it exists
        if hasattr(Config, 'USER_CRON_TASKS') and user_id in Config.USER_CRON_TASKS:
            try:
                Config.USER_CRON_TASKS[user_id].cancel()
                Config.USER_CRON_TASKS.pop(user_id, None)
                logger.info(f"Cancelled cron task for user {user_id}")
            except Exception as e:
                logger.error(f"Error cancelling cron task for user {user_id}: {e}")
            
        # Log out the user
        await callback_query.message.edit_text("👋 Logging out...")
        await cleanup_session(user_id, user_sessions, Config, logger)
        await callback_query.message.edit_text(
            "👋 You have been logged out. Use /start to login again."
        )
        # Log out the user session
        if user_id in user_sessions:
            user_sessions.pop(user_id, None)
            logger.info(f"User session removed for user {user_id}")
    
    elif action == "help":
        # Show help message/help
        await callback_query.message.edit_text(
            "📖 Twitter/X Multi-Account Automation Bot Help\n\n"
            "What can you do?\n"
            "• Add, switch, and remove multiple Twitter/X accounts\n"
            "• Set up cron jobs for each account\n"
            "• Generate AI content and images\n"
            "• Post directly to Twitter/X\n\n"
            "How to use:\n"
            "1. Use /start to begin and log in with cookies or credentials.\n"
            "2. Add as many Twitter/X accounts as you like.\n"
            "3. Use the account menu to switch or remove accounts.\n"
            "4. Set up cron jobs for each account to automate posting or fetching.\n"
            "5. Use the menu to generate content, images, or manage your automation.\n\n"
            "Free Tier: All features are available for free.\n\n"
            "Need help? Use /start to access the main menu."
        )


# Add back the missing main function and update it to start the bot




def format_post_for_channel(post):
    """
    Format a post for sharing in the channel with improved handling of long content
    
    For long posts:
    1. Keep the full text but split if necessary
    2. Preserve important parts like URLs and hashtags
    3. Add continuation indicators
    """
    author = post.get("author", "Unknown")
    text = post.get("text", "No content")
    post_id = post.get("id", "")
    display_name = post.get("display_name", post.get("account_display_name", author))
    
    # Detect if this is part of a thread or a split message
    is_continuation = post.get("is_continuation", False)
    
    # Check for media content
    has_images = bool(post.get("image_urls", []))
    has_video = bool(post.get("video_url", ""))
    has_media = has_images or has_video
    
    # Format the header
    if not is_continuation:
        header = f"📱 New post from {display_name} (@{author})\n\n"
    else:
        header = f"📱 Continued from @{author}...\n\n"
    
    # Full post text - preserve as much as possible
    content = text.strip() if text else "No content"
    
    # Add metrics if available
    footer = ""
    metrics = post.get("metrics", {})
    if metrics:
        metrics_parts = []
        if "reply" in metrics:
            metrics_parts.append(f"💬 {metrics['reply']}")
        if "retweet" in metrics:
            metrics_parts.append(f"🔄 {metrics['retweet']}")
        if "like" in metrics:
            metrics_parts.append(f"❤️ {metrics['like']}")
        if metrics_parts:
            footer += f"\n{' • '.join(metrics_parts)}"
    
    # Add link to original post
    if post_id:
        footer += f"\n\n🔗 https://x.com/{author}/status/{post_id}"
    
    # Calculate max content length to fit within Telegram limits
    # Telegram limit is 4096, but we need space for header and footer
    max_content_length = 4096 - len(header) - len(footer) - 50  # 50 is buffer
    
    # Check if content needs to be split
    if len(content) > max_content_length:
        # Try to find a good split point (end of sentence, etc.)
        # This helps ensure we don't cut in the middle of a word
        split_points = ['. ', '! ', '? ', '\n\n', '\n', '. ', ', ', ' ']
        split_index = max_content_length
        
        for point in split_points:
            last_good_split = content[:max_content_length].rfind(point)
            if last_good_split > max_content_length * 0.75:  # At least 75% of content
                split_index = last_good_split + len(point)
                break
                
        # Split the content
        first_part = content[:split_index].strip()
        
        # Add a continuation indicator
        first_part += "\n\n... (continued in next message)"
        
        # Prepare continuation part for later
        remaining = content[split_index:].strip()
        if remaining:
            # Create a continuation post (will be processed separately)
            continuation_post = post.copy()
            continuation_post["text"] = remaining
            continuation_post["is_continuation"] = True
            continuation_post["original_id"] = post_id
            
            # Store in database for processing
            try:
                if db is not None:
                    db[Config.POSTS_COLLECTION].update_one(
                        {"id": f"{post_id}_continuation", "original_id": post_id},
                        {"$set": continuation_post},
                        upsert=True
                    )
            except Exception as e:
                logger.error(f"Error storing continuation post: {e}")
        
        content = first_part
    
    # Add media indicators
    if has_images and not post.get("is_media_processed", False):
        img_count = len(post.get("image_urls", []))
        if img_count > 0:
            content += f"\n\n📷 {img_count} image{'s' if img_count > 1 else ''} attached"
    
    if has_video and not post.get("is_media_processed", False):
        content += "\n\n🎬 Video attached"
    
    # Combine all parts
    message = header + content + footer
    
    # Final truncation if somehow still too long
    if len(message) > 4096:
        message = message[:4093] + "..."
    
    return message

@bot.on_callback_query(filters.regex('^get_following$'))
async def handle_get_following(client: Client, callback_query: CallbackQuery):
    """Handle fetching user's following list"""
    user_id = callback_query.from_user.id
    # Check if there's already an active fetch for this user
    if user_id in active_fetch_jobs:
        await callback_query.answer("A following fetch is already in progress", show_alert=True)
        return
    # Set active fetch flag
    active_fetch_jobs[user_id] = True
    # Acknowledge the callback query
    await callback_query.answer()
    
    # Get active session
    session = None
    
    # Handle both dictionary and UserSession object formats
    if user_id in user_sessions:
        if isinstance(user_sessions[user_id], dict):
            active_account = user_sessions[user_id].get("active")
            accounts = user_sessions[user_id].get("accounts", {})
            if active_account and active_account in accounts:
                session = accounts[active_account]
        elif isinstance(user_sessions[user_id], UserSession):
            session = user_sessions[user_id]
    
    if not session or session.state != "logged_in" or not session.page:
        await callback_query.message.edit_text(
            "❌ No active Twitter account. Please add or select an account first.",
            reply_markup=get_account_management_keyboard(user_id)
        )
        # Clear active fetch flag
        if user_id in active_fetch_jobs:
            del active_fetch_jobs[user_id]
        return
    
    # Initialize status message
    status_message = await callback_query.message.edit_text(
        "🔍 Starting to fetch your following list..."
    )
    
    try:
        # Create temp directory if it doesn't exist
        os.makedirs("temp", exist_ok=True)
        csv_path = f"temp/following_{user_id}.csv"
        
        # Update status message periodically
        async def update_status(current_count):
            try:
                await status_message.edit_text(
                    f"🔄 Fetching following list for @{session.username}\n"
                    f"Found {current_count} accounts so far..."
                )
            except Exception:
                pass

        # Use the improved fetch_following_accounts function with progress callback
        following_accounts = []
        last_count = 0
        
        async def progress_callback(accounts):
            nonlocal last_count
            current_count = len(accounts)
            if current_count >= last_count + 10:  # Update every 10 accounts
                await update_status(current_count)
                last_count = current_count
        
        following_accounts = await fetch_following_accounts(
            session.page, 
            username=session.username,
            progress_callback=progress_callback,
            max_accounts=100  # Limit to 100 accounts for UI interactions
        )
        
        if following_accounts:
            total_accounts = len(following_accounts)
            # Generate CSV file
            with open(csv_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=['username', 'name', 'fetched_at'])
                writer.writeheader()
                writer.writerows(following_accounts)
            
            # Send the CSV file
            await client.send_document(
                chat_id=callback_query.message.chat.id,
                document=csv_path,
                caption=f"✅ Following List Export\nTotal Accounts: {total_accounts}",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Add to CronJob", callback_data="cron_add")],
                    [InlineKeyboardButton("◀️ Back to Menu", callback_data="back_to_menu")]
                ])
            )
            
            # Update final status
            await status_message.edit_text(
                f"✅ Successfully fetched {total_accounts} following accounts!\n"
                f"Check the CSV file sent above."
            )
        else:
            await status_message.edit_text(
                "❌ No following accounts found or you're not following anyone.",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("Back to Menu", callback_data="back_to_menu")
                ]])
            )
    
    except Exception as e:
        logger.error(f"Error in handle_get_following: {e}")
        await status_message.edit_text(
            "❌ An error occurred while fetching following accounts. Please try again.",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("Back to Menu", callback_data="back_to_menu")
            ]])
        )
    
    finally:
        # Clear active fetch flag
        if user_id in active_fetch_jobs:
            del active_fetch_jobs[user_id]
            
        # Clean up the CSV file
        try:
            if os.path.exists(csv_path):
                os.remove(csv_path)
        except Exception as cleanup_error:
            logger.error(f"Error removing CSV file: {cleanup_error}")
#----------------------------------------------------------------------------------------------

# Update the content generation handler
#Channel post button callback data. [Generate Script with AI Button callback data]
@bot.on_callback_query(filters.regex('^generate_content$'))  # Changed from '^generate_' to a more specific pattern
async def handle_content_generation_generic(client: Client, callback_query: CallbackQuery):  # Renamed function
    try:
        # Get user information
        user_id = callback_query.from_user.id
        username = callback_query.from_user.username or callback_query.from_user.first_name
        
        # Extract the prompt type from the callback data
        prompt_type = callback_query.data.replace('generate_', '')
        
        # Get the original message
        message = callback_query.message
        
        # Extract text from the message
        text_to_process = ""
        
        # For photo messages, get the caption
        if message.photo:
            text_to_process = message.caption or ""
        # For text messages, get the text
        elif message.text:
            # Skip if this is just the "Generate content" placeholder
            if message.text != "🤖 Generate content for this post:":
                text_to_process = message.text
            # If it's just the placeholder, check if it's replying to a message
            elif message.reply_to_message:
                if message.reply_to_message.photo:
                    text_to_process = message.reply_to_message.caption or ""
                else:
                    text_to_process = message.reply_to_message.text or ""
        # Check if it's a reply to another message
        elif message.reply_to_message:
            if message.reply_to_message.photo:
                text_to_process = message.reply_to_message.caption or ""
            else:
                text_to_process = message.reply_to_message.text or ""
                
        # If we still don't have content, check if this message is part of a thread
        if not text_to_process and message.reply_to_message_id:
            try:
                # Try to get the original message this is replying to
                original_message = await get_message_with_cache(client, message.chat.id, message.reply_to_message_id)
                if original_message:
                    text_to_process = original_message.text or original_message.caption or ""
            except Exception as e:
                logger.error(f"Error fetching original message: {e}")
                
        if not text_to_process:
            await callback_query.answer("No text found to process! Make sure the button is attached to a post with text.", show_alert=True)
            return
            
        # Acknowledge the request
        await callback_query.answer("Processing your request... Please check Bot for the results", show_alert=True)
        
        # Send status message
        status_msg = await client.send_message(
            chat_id=user_id,
            text="🔄 Generating script based on the content..."
        )
        
        # Generate content using our helper
        response = await generate_ai_content(text_to_process, prompt_type)
        
        # Delete the status message
        try:
            await status_msg.delete()
        except Exception:
            pass
        
        # Send a header message
        preview = text_to_process[:100] + "..." if len(text_to_process) > 100 else text_to_process
        await client.send_message(
            chat_id=user_id,
            text=f"💡 Here's your AI-generated script based on:\n\n\"{preview}\""
        )
        
        # Send the response
        if response and not response.startswith("Error"):
            script_msg = await client.send_message(
                chat_id=user_id,
                text=response
            )
            
            # Add buttons for both image generation options
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("🎨 Generate Consolidated Image", callback_data="generate_consolidated_image")],
                [InlineKeyboardButton("🎬 Generate Scene by Scene", callback_data="generate_scene_images")]
            ])
            
            await client.send_message(
                chat_id=user_id,
                text="Would you like to generate images based on this script?\n\n"
                     "• 🎨 Consolidated Image: One high-quality image for the entire script\n"
                     "• 🎬 Scene by Scene: Generate images for each scene",
                reply_markup=keyboard,
                reply_to_message_id=script_msg.id
            )
            
            logger.info(f"Successfully sent AI-generated script to user {username}")
        else:
            # Handle error responses
            await client.send_message(
                chat_id=user_id,
                text=f"❌ {response}"
            )
            logger.error(f"Error in AI generation: {response}")
        
    except Exception as e:
        error_msg = f"Error in content generation handler: {str(e)}"
        logger.error(error_msg)
        try:
            await callback_query.message.reply(
                text=f"❌ {error_msg}\n\nPlease try again later."
            )
        except Exception as msg_error:
            logger.error(f"Failed to send error message: {str(msg_error)}")

#------------------------------------------------------------------------------------------------
@bot.on_callback_query(filters.regex('^generate_scene_images$'))
async def scene_by_scene_handler(client: Client, callback_query: CallbackQuery):
    try:
        user_id = callback_query.from_user.id
        message = callback_query.message
        if not message.reply_to_message_id:
            await callback_query.answer("Error: Can't find the script. This button should be used on a message that contains a script.", show_alert=True)
            return
        logger.info(f"Looking for script in message with ID: {message.reply_to_message_id}")
        try:
            await callback_query.answer("Starting scene-by-scene image generation...")
        except Exception as e:
            logger.warning(f"Failed to answer callback query: {str(e)}")
        
        # Create a task to handle the scene generation
        async def scene_generation_task():
            try:
                original_message = await get_message_with_cache(client, message.chat.id, message.reply_to_message_id)
                if original_message and original_message.text:
                    logger.info(f"Found script in replied-to message ({message.reply_to_message_id}): {original_message.text[:50]}...")
                    script_text = original_message.text
                    scenes = extract_scenes_from_script(script_text)
                    if not scenes:
                        await message.reply("❌ Could not extract scenes from the script. Make sure the script has clear scene markers or descriptions.")
                        return
                    logger.info(f"Extracted {len(scenes)} scenes from script")
                    status_message = await message.reply(
                        f"🎬 Generating images for {len(scenes)} scenes...\n"
                        f"⏳ This will take a few minutes, please wait."
                    )
                    
                    # Extract metadata for each scene
                    scene_metadata = []
                    for scene_num, scene_text in scenes:
                        title, description, hashtags = extract_scene_metadata(scene_text)
                        scene_metadata.append({
                            "scene_num": scene_num,
                            "title": title,
                            "description": description,
                            "hashtags": hashtags
                        })
                        logger.info(f"Scene {scene_num} metadata - Title: {title or 'None'}, Description: {description[:30] + '...' if description else 'None'}, Hashtags: {hashtags or 'None'}")
                    
                    async def generate_scene(scene_num, scene_text, i, metadata):
                        try:
                            logger.info(f"Generating image for scene {scene_num}, index {i+1}/{len(scenes)}")
                            if len(scene_text) > 800:
                                scene_text = scene_text[:800]
                            
                            # Call the same generate_consolidated_image function used for consolidated images
                            result = await generate_consolidated_image(
                                script_text=scene_text,
                                chat_id=message.chat.id,
                                client=client,
                                message=status_message,
                                quiet=True
                            )
                            
                            if result and isinstance(result, dict) and 'image_url' in result:
                                # Don't send the image here, we'll send them all in order later
                                # Return the same structure that generate_consolidated_image returns plus metadata
                                return (i, scene_num, result, metadata)
                            else:
                                logger.error(f"Failed to generate image for scene {scene_num}")
                                return (i, scene_num, None, metadata)
                        except Exception as scene_error:
                            logger.error(f"Error generating image for scene {i+1}: {str(scene_error)}")
                            await client.send_message(
                                chat_id=message.chat.id,
                                text=f"❌ Error generating image for scene {scene_num}: {str(scene_error)[:100]}"
                            )
                            return (i, scene_num, None, metadata)
                    
                    # Run all scene generations concurrently
                    tasks = [generate_scene(scene_num, scene_text, i, scene_metadata[i]) for i, (scene_num, scene_text) in enumerate(scenes)]
                    results = await asyncio.gather(*tasks)
                    
                    # Sort results by original scene order
                    results.sort(key=lambda x: x[0])
                    
                    # Process the results and send images in order
                    successful_results = []
                    
                    # Update status message
                    await status_message.edit_text(f"🎬 Generated images for {len(scenes)} scenes. Sending them now...")
                    
                    # Send images in ordered sequence
                    for i, scene_num, result, metadata in results:
                        if result and isinstance(result, dict) and 'image_url' in result:
                            # Send the image to the chat in order
                            await send_image_with_retry(
                                client=client,
                                chat_id=message.chat.id,
                                image_url=result['image_url'],
                                caption=f"Scene {scene_num} ({i+1}/{len(scenes)})"
                            )
                            successful_results.append((i, scene_num, result, metadata))
                    
                    # Create a combined batch with all the successful images
                    if successful_results:
                        # Get active account
                        active_account = None
                        if user_id in user_sessions:
                            if isinstance(user_sessions[user_id], dict):
                                active_account = user_sessions[user_id].get("active")
                            elif isinstance(user_sessions[user_id], UserSession):
                                active_account = user_sessions[user_id].username
                        if not active_account:
                            active_account = get_active_twitter_account(user_id)
                        
                        # Prepare batch images and metadata
                        batch_images = []
                        batch_metadata = []
                        for _, scene_num, result, metadata in successful_results:
                            batch_images.append({
                                "image_url": result['image_url'],
                                "file_id": result.get('file_id'),
                                "message_id": result.get('message_id'),
                                "status": "pending"
                            })
                            batch_metadata.append({
                                "title": metadata.get("title", ""),
                                "description": metadata.get("description", ""),
                                "hashtags": metadata.get("hashtags", "")
                            })
                        
                        # Create the batch with metadata
                        batch_id = create_image_batch(
                            db, user_id, active_account,
                            batch_images,
                            scenes=[scene_text for _, scene_text in scenes],
                            script_text=script_text,
                            metadata=batch_metadata
                        )
                        
                        # Show success message with Twitter posting button
                        keyboard = InlineKeyboardMarkup([
                            [InlineKeyboardButton("🐦 Post All Images to Twitter", callback_data=f"ptt|{batch_id}")]
                        ])
                        await status_message.edit_text(
                            f"✅ Successfully generated {len(successful_results)} scene images!\n"
                            f"You can now post these to Twitter.",
                            reply_markup=keyboard
                        )
                    else:
                        await status_message.edit_text("❌ Failed to generate any scene images.")
                else:
                    await message.reply("❌ Could not find the script message.")
            except Exception as e:
                logger.error(f"Error in scene generation task: {e}")
                await message.reply(f"❌ Error generating scene images: {str(e)[:200]}")
        
        # Add task to user's AI task queue and start processing
        task = scene_generation_task()
        ai_task_queue[user_id].append(task)
        asyncio.create_task(process_queues(user_id))
        
    except Exception as e:
        error_msg = f"Error in scene_by_scene_handler: {str(e)}"
        logger.error(error_msg)
        try:
            await callback_query.message.reply(
                text=f"❌ {error_msg}\n\nPlease try again later."
            )
        except Exception as msg_error:
            logger.error(f"Failed to send error message: {str(msg_error)}")

#Handle the Post All Images Button callback data.
@bot.on_callback_query(filters.regex(r'^ptt\|'))
async def handle_post_thread_ptt(client: Client, callback_query: CallbackQuery):
    import inspect
    try:
        user_id = callback_query.from_user.id
        # Get active session
        session = None
        active_account = None
        
        # Handle both dictionary and UserSession object formats
        if user_id in user_sessions:
            if isinstance(user_sessions[user_id], dict):
                active_account = user_sessions[user_id].get("active")
                accounts = user_sessions[user_id].get("accounts", {})
                if active_account and active_account in accounts:
                    session = accounts[active_account]
            elif isinstance(user_sessions[user_id], UserSession):
                session = user_sessions[user_id]
                active_account = session.username
        
        if not session or session.state != "logged_in":
            await callback_query.message.reply(
                "❌ No active Twitter account. Please add or select an account first.",
                reply_markup=get_account_management_keyboard(user_id)
            )
            return
            
        data = callback_query.data
        _, batch_id = data.split('|', 1)
        
        # If active_account wasn't set earlier, get it now
        if not active_account:
            active_account = get_active_twitter_account(user_id)
        
        # Fetch batch from MongoDB
        batch = get_image_batch(db, user_id, active_account, batch_id)
        if not batch or not batch.get('images'):
            await callback_query.message.reply("❌ Images not found or expired.")
            return
        # Only post images with status 'pending'
        image_docs = [img for img in batch.get('images', []) if img.get('status') == 'pending' or img.get('status') == 'failed']
        total_images = len(image_docs)
        logger.info(f"Twitter batch {batch_id} contains {total_images} pending images (will post only pending ones)")
        if total_images == 0:
            await callback_query.message.reply("❌ No pending images to post in this batch.")
            return
        await callback_query.answer("Preparing for Twitter posting...")
        status_message = await callback_query.message.reply(f"🔄 Preparing to post {total_images} pending images to Twitter...")
        
        # Create a task for thread posting
        # Pass session, active_account, batch, batch_id, and image_docs from outer scope to the async function
        async def post_thread_task(session=session, active_account=active_account, batch=batch, batch_id=batch_id, image_docs=image_docs):
            try:
                context = None
                if session and hasattr(session, 'context') and session.context:
                    context = session.context
                    logger.info(f"Using user session context for Twitter posting")
                elif hasattr(Config, 'GLOBAL_CONTEXT') and Config.GLOBAL_CONTEXT:
                    context = Config.GLOBAL_CONTEXT
                    logger.info(f"Using global context for Twitter posting")
                else:
                    logger.error(f"No admin session available. Please ask an admin to log in first.")
                    await status_message.edit_text("❌ Your browser session has expired or is invalid. Please log out and log in again, then try posting.")
                    return
                if context is None:
                    logger.error(f"Context is None in handle_post_thread for user {user_id}. context={context}")
                    await status_message.edit_text("❌ Your browser session has expired or is invalid. Please log out and log in again, then try posting.")
                    return
                if not hasattr(context, 'new_page') or not inspect.iscoroutinefunction(context.new_page):
                    logger.error(f"context.new_page is not a coroutine. Type: {type(context.new_page)}, value: {context.new_page}")
                    await status_message.edit_text("❌ Your browser session has expired or is invalid. Please log out and log in again, then try posting.")
                    return
                    
                # Download all images concurrently before posting
                temp_dir = Config.TEMP_DIR if hasattr(Config, 'TEMP_DIR') else 'temp'
                os.makedirs(temp_dir, exist_ok=True)
                
                # We'll track image paths and successful downloads
                image_paths = []
                downloaded = set()
                
                await status_message.edit_text(f"🔄 Preparing to download {total_images} images...")
                
                # Create file paths for all images
                for i, image_doc in enumerate(image_docs):
                    image_path = os.path.join(temp_dir, f"twitter_thread_{user_id}_{i}_{uuid.uuid4().hex[:8]}.jpg")
                    image_paths.append(image_path)
                
                # Create a semaphore to limit concurrent connections
                # Using 1 ensures that only one connection to Telegram servers exists at a time
                semaphore = asyncio.Semaphore(1)
                
                # GROUP 1: First try to download all images with file_ids
                # This downloads the images one at a time to avoid multiple connections
                telegram_files = [(i, doc.get('file_id'), image_paths[i]) 
                               for i, doc in enumerate(image_docs) if doc.get('file_id')]
                
                if telegram_files:
                    await status_message.edit_text(f"🔄 Downloading {len(telegram_files)} images from Telegram...")
                    
                    for i, file_id, path in telegram_files:
                        try:
                            # Use semaphore to ensure only one download happens at a time
                            async with semaphore:
                                # This will ensure only one connection at a time
                                result = await client.download_media(file_id, file_name=path)
                                
                            if result:
                                logger.info(f"Successfully downloaded image {i+1} from Telegram")
                                downloaded.add(i)
                            else:
                                logger.error(f"Failed to download image {i+1} from Telegram")
                        except Exception as e:
                            logger.error(f"Error downloading image {i+1} from Telegram: {e}")
                
                # GROUP 2: Download any missing images from URLs
                missing_indices = [i for i in range(len(image_docs)) if i not in downloaded]
                
                if missing_indices:
                    await status_message.edit_text(f"🔄 Downloading {len(missing_indices)} images from URLs...")
                    
                    # For URL downloads, we can use a single aiohttp session
                    async with aiohttp.ClientSession() as session:
                        for i in missing_indices:
                            image_doc = image_docs[i]
                            image_url = image_doc.get('image_url')
                            
                            if not image_url:
                                logger.error(f"No URL available for image {i+1}")
                                continue
                                
                            try:
                                async with session.get(image_url, timeout=30) as resp:
                                    if resp.status == 200:
                                        with open(image_paths[i], 'wb') as f:
                                            f.write(await resp.read())
                                        logger.info(f"Successfully downloaded image {i+1} from URL")
                                        downloaded.add(i)
                                    else:
                                        logger.error(f"Failed to download image {i+1} from URL, status: {resp.status}")
                            except Exception as e:
                                logger.error(f"Error downloading image {i+1} from URL: {e}")
                
                # Filter paths based on what was actually downloaded
                available_paths = [path for i, path in enumerate(image_paths) if i in downloaded]
                
                if len(available_paths) != total_images:
                    logger.warning(f"Only downloaded {len(available_paths)}/{total_images} images successfully")
                    await status_message.edit_text(f"⚠️ Only {len(available_paths)}/{total_images} images were downloaded successfully. Continuing with available images.")
                    if not available_paths:
                        await status_message.edit_text("❌ Failed to download any images. Please try again.")
                        return
                
                # Continue with available image paths
                image_paths = available_paths
                
                # Continue with Twitter posting logic...
                await status_message.edit_text("🐦 Posting images to Twitter. Please wait...")
                
                # Add your Twitter posting logic here
                success_count = 0
                tweet_urls = []
                
                # Get first scene metadata for the tweet text
                tweet_text = ""
                if batch.get('script_text'):
                    # Try to extract metadata from the first scene
                    scenes = batch.get('scenes', [])
                    if scenes and len(scenes) > 0:
                        first_scene = scenes[0]
                        # Extract title, description, and hashtags from the first scene
                        from ImageGen import extract_scene_metadata
                        title, description, hashtags = extract_scene_metadata(first_scene)
                        if title or description or hashtags:
                            tweet_parts = []
                            if title:
                                tweet_parts.append(f"📝 {title}")
                            if description:
                                tweet_parts.append(description[:100] + ("..." if len(description) > 100 else ""))
                            if hashtags:
                                tweet_parts.append(hashtags)
                            tweet_text = "\n\n".join(tweet_parts)
                
                # If we couldn't extract metadata, use a default tweet text
                if not tweet_text:
                    tweet_text = "Check out this AI-generated image! #AIArt #GenerativeAI"
                
                # Post each image to Twitter
                for i, image_path in enumerate(image_paths):
                    try:
                        # Get scene-specific metadata for this image
                        current_text = tweet_text
                        
                        # If we have scenes data, use the corresponding scene's metadata
                        if batch.get('scenes') and i < len(batch.get('scenes', [])):
                            scene_text = batch.get('scenes')[i]
                            from ImageGen import extract_scene_metadata
                            scene_title, scene_description, scene_hashtags = extract_scene_metadata(scene_text)
                            
                            # Build tweet text from this specific scene's metadata
                            if scene_title or scene_description or scene_hashtags:
                                scene_tweet_parts = []
                                if scene_title:
                                    scene_tweet_parts.append(f"📝 {scene_title}")
                                if scene_description:
                                    scene_tweet_parts.append(scene_description[:100] + ("..." if len(scene_description) > 100 else ""))
                                if scene_hashtags:
                                    scene_tweet_parts.append(scene_hashtags)
                                current_text = "\n\n".join(scene_tweet_parts)
                                logger.info(f"Using scene-specific metadata for image {i+1}")
                            else:
                                logger.info(f"No scene-specific metadata found for image {i+1}, using default text")
                        
                        # Check if we have stored metadata in the image document itself (this takes precedence)
                        if i < len(image_docs) and image_docs[i].get('title') or image_docs[i].get('description') or image_docs[i].get('hashtags'):
                            stored_tweet_parts = []
                            
                            if image_docs[i].get('title'):
                                stored_tweet_parts.append(f"📝 {image_docs[i]['title']}")
                            
                            if image_docs[i].get('description'):
                                stored_tweet_parts.append(image_docs[i]['description'][:100] + 
                                                         ("..." if len(image_docs[i]['description']) > 100 else ""))
                            
                            if image_docs[i].get('hashtags'):
                                stored_tweet_parts.append(image_docs[i]['hashtags'])
                            
                            if stored_tweet_parts:
                                current_text = "\n\n".join(stored_tweet_parts)
                                logger.info(f"Using stored metadata for image {i+1}")
                        
                        # Update status message
                        await status_message.edit_text(f"🐦 Posting image {i+1}/{len(image_paths)} to Twitter...")
                        
                        # Call the post_image_to_twitter function
                        tweet_url = await post_image_to_twitter(context, image_path, current_text, logger)
                        
                        # Consider both a valid URL and SUCCESS_NO_URL as successful posting
                        is_success = tweet_url is not None and (tweet_url.startswith("http") or tweet_url == "SUCCESS_NO_URL")
                        
                        if is_success:
                            # Update image status in MongoDB
                            update_image_status(db, user_id, active_account, batch_id, i, "posted")
                            success_count += 1
                            
                            # Only add valid URLs to tweet_urls
                            if tweet_url != "SUCCESS_NO_URL" and tweet_url.startswith("http"):
                                tweet_urls.append(tweet_url)
                                logger.info(f"Result from post_image_to_twitter: {tweet_url}")
                            else:
                                logger.info(f"Posted image {i+1} successfully but couldn't retrieve URL")
                        else:
                            # Mark as failed
                            update_image_status(db, user_id, active_account, batch_id, i, "failed")
                            logger.error(f"Failed to post image {i+1}")
                    except Exception as e:
                        logger.error(f"Error posting image {i+1}: {e}")
                        # Mark as failed
                        update_image_status(db, user_id, active_account, batch_id, i, "failed")
                
                # Show final status
                if success_count > 0:
                    message_text = f"✅ Successfully posted {success_count}/{len(image_paths)} images to Twitter!"
                    
                    # Check if we have a valid URL to create a button
                    if len(tweet_urls) > 0:
                        first_url = tweet_urls[0]
                        # Only create button if URL is valid (starts with http)
                        if isinstance(first_url, str) and first_url.startswith("http"):
                            try:
                                # Create a button that says "View on Twitter" and links to the tweet
                                keyboard = InlineKeyboardMarkup([
                                    [InlineKeyboardButton("🔗 View on Twitter", url=first_url)]
                                ])
                                await status_message.edit_text(message_text, reply_markup=keyboard)
                            except Exception as e:
                                # Fallback if button creation fails
                                logger.error(f"Error creating Twitter button: {e}")
                                await status_message.edit_text(message_text)
                        else:
                            # No valid URL, just show success message
                            await status_message.edit_text(message_text)
                    else:
                        # No URLs but still successful posting
                        await status_message.edit_text(
                            f"{message_text}\n\n" 
                            f"Note: URLs couldn't be retrieved, but the images were posted successfully."
                        )
                else:
                    await status_message.edit_text("❌ Failed to post any images to Twitter. Please try again.")
                
                # Clean up temp files
                for image_path in image_paths:
                    try:
                        if os.path.exists(image_path):
                            os.remove(image_path)
                    except Exception as e:
                        logger.warning(f"Failed to clean up temp file {image_path}: {e}")
                
            except Exception as e:
                logger.error(f"Error in post_twitter_task: {e}")
                await status_message.edit_text(f"❌ Error posting to Twitter: {str(e)[:200]}")
        
        # Add the task to the user's queue and process it concurrently
        task = post_thread_task()
        post_queue[user_id].append(task)
        
        # Start processing the queue for this user if not already processing
        asyncio.create_task(process_queues(user_id))
        
    except Exception as e:
        logger.error(f"Error in handle_post_to_twitter: {e}")
        await callback_query.message.reply(f"❌ Error posting to Twitter: {str(e)[:200]}")

#------------------------------------------------------------------------------------------------

# --- Multi-Account Helper Functions ---
def get_account_management_keyboard(user_id):
    """Return an InlineKeyboardMarkup for managing Twitter accounts for the user."""
    user_data = user_sessions.get(user_id, {})
    accounts = user_data.get("accounts", {})
    active = user_data.get("active")
    buttons = []
    if accounts:
        for username in accounts:
            label = f"@{username}"
            if username == active:
                label += " ✅"
            buttons.append([
                InlineKeyboardButton(label, callback_data=f"set_active_account|{username}")
            ])
        buttons.append([InlineKeyboardButton("➕ Add Account", callback_data="add_account")])
        buttons.append([InlineKeyboardButton("🗑️ Remove Account", callback_data="remove_account")])
    else:
        buttons.append([InlineKeyboardButton("➕ Add Account", callback_data="add_account")])
    buttons.append([InlineKeyboardButton("Back to Menu", callback_data="back_to_menu")])
    return InlineKeyboardMarkup(buttons)

def get_active_session(user_id):
    """Return the active UserSession for the user, or None if not set."""
    user_data = user_sessions.get(user_id, {})
    active = user_data.get("active")
    accounts = user_data.get("accounts", {})
    if active and active in accounts:
        return accounts[active]
    return None

def add_twitter_session(user_id, twitter_username, session):
    """Add a Twitter session to the user's accounts dict."""
    if user_id not in user_sessions:
        user_sessions[user_id] = {"active": None, "accounts": {}}
    
    # Make sure accounts dict exists
    if "accounts" not in user_sessions[user_id]:
        user_sessions[user_id]["accounts"] = {}
        
    # Add the session to accounts
    user_sessions[user_id]["accounts"][twitter_username] = session
    
    # If this is the first account, set as active
    if not user_sessions[user_id]["active"]:
        user_sessions[user_id]["active"] = twitter_username
    
    return True

def set_active_account(user_id, twitter_username):
    """Set the active Twitter account for the user."""
    if user_id not in user_sessions:
        return False
        
    user_data = user_sessions[user_id]
    accounts = user_data.get("accounts", {})
    
    if twitter_username in accounts:
        user_sessions[user_id]["active"] = twitter_username
        return True
    return False

def remove_twitter_session(user_id, twitter_username):
    """Remove a Twitter session from the user's accounts dict."""
    if user_id not in user_sessions:
        return False
        
    user_data = user_sessions[user_id]
    accounts = user_data.get("accounts", {})
    
    if twitter_username in accounts:
        # Close browser resources before removing
        try:
            session = accounts[twitter_username]
            asyncio.create_task(
                cleanup_specific_account(user_id, twitter_username, user_sessions, Config, logger)
            )
        except Exception as e:
            logger.error(f"Error cleaning up account @{twitter_username}: {e}")
        
        # Remove from accounts dict
        accounts.pop(twitter_username, None)
        
        # If the removed account was active, set another as active
        if user_data.get("active") == twitter_username:
            user_sessions[user_id]["active"] = next(iter(accounts), None)
        
        return True
    
    return False

# --- Multi-Account Management Callback Handlers ---
@bot.on_callback_query(filters.regex(r'^set_active_account\|'))
async def handle_set_active_account(client, callback_query):
    user_id = callback_query.from_user.id
    data = callback_query.data
    _, username = data.split('|', 1)
    if set_active_account(user_id, username):
        await callback_query.answer(f"Switched to @{username}")
        await callback_query.message.edit_text(
            f"✅ Now using @{username} as your active Twitter account.",
            reply_markup=get_account_management_keyboard(user_id)
        )
    else:
        await callback_query.answer("Account not found.", show_alert=True)

@bot.on_callback_query(filters.regex(r'^add_account$'))
async def handle_add_account(client, callback_query):
    user_id = callback_query.from_user.id
    
    # Check account limit
    if not await check_account_limit(user_id):
        await callback_query.answer("You've reached your maximum account limit.", show_alert=True)
        user_limits = await get_user_limits(user_id)
        max_accounts = user_limits.get("max_accounts", 5)
        await callback_query.message.reply(
            f"⚠️ You've reached your account limit ({max_accounts} accounts).\n\n"
            f"Please remove an existing account before adding a new one."
        )
        return
    
    # Start the login flow for a new account
    await callback_query.answer()
    user_sessions[user_id]["_pending"] = UserSession()
    session = user_sessions[user_id]["_pending"]
    session.state = "waiting_for_username"
    await callback_query.message.edit_text(
        "👤 Please enter the Twitter/X username for the new account:"
    )

@bot.on_callback_query(filters.regex(r'^remove_account$'))
async def handle_remove_account(client, callback_query):
    user_id = callback_query.from_user.id
    user_data = user_sessions.get(user_id, {})
    accounts = user_data.get("accounts", {})
    if not accounts:
        await callback_query.answer("No accounts to remove.", show_alert=True)
        return
    # Show a list of accounts to remove
    buttons = [
        [InlineKeyboardButton(f"@{username}", callback_data=f"confirm_remove_account|{username}")]
        for username in accounts
    ]
    buttons.append([InlineKeyboardButton("Cancel", callback_data="back_to_menu")])
    await callback_query.message.edit_text(
        "Select an account to remove:",
        reply_markup=InlineKeyboardMarkup(buttons)
    )

@bot.on_callback_query(filters.regex(r'^confirm_remove_account\|'))
async def handle_confirm_remove_account(client, callback_query):
    user_id = callback_query.from_user.id
    data = callback_query.data
    _, username = data.split('|', 1)
    if remove_twitter_session(user_id, username):
        await callback_query.answer(f"Removed @{username}")
        await callback_query.message.edit_text(
            f"🗑️ Removed @{username} from your accounts.",
            reply_markup=get_account_management_keyboard(user_id)
        )
    else:
        await callback_query.answer("Account not found.", show_alert=True)

# Add after the MongoDB connection section
async def register_user(user_id, username, first_name, last_name=None):
    """Register a new user in the system or update existing user information"""
    try:
        if db is None:
            logger.error("Database connection not available")
            return False
            
        # Current timestamp
        now = datetime.now()
        
        # User data to store
        user_data = {
            "user_id": user_id,
            "username": username,
            "first_name": first_name,
            "last_name": last_name,
            "registered_at": now,
            "last_active": now,
            "account_tier": "free",  # Default tier for all users
            "max_accounts": 5,       # Default limit for free tier
            "max_cron_jobs": 10,     # Default limit for free tier
            "is_active": True
        }
        
        # Update or insert user document
        result = db.users.update_one(
            {"user_id": user_id},
            {"$set": user_data, 
             "$setOnInsert": {"created_at": now}},
            upsert=True
        )
        
        is_new_user = result.upserted_id is not None
        logger.info(f"{'Registered new user' if is_new_user else 'Updated existing user'}: {username} ({user_id})")
        return True
    except Exception as e:
        logger.error(f"Error registering user: {e}")
        return False

async def update_user_activity(user_id):
    """Update user's last active timestamp"""
    try:
        if db is None:
            return False
            
        db.users.update_one(
            {"user_id": user_id},
            {"$set": {"last_active": datetime.now()}}
        )
        return True
    except Exception as e:
        logger.error(f"Error updating user activity: {e}")
        return False

async def get_user_limits(user_id):
    """Get user's account limits based on their tier"""
    try:
        if db is None:
            return {"max_accounts": 5, "max_cron_jobs": 10}  # Default limits
            
        user = db.users.find_one({"user_id": user_id})
        if user:
            return {
                "max_accounts": user.get("max_accounts", 5),
                "max_cron_jobs": user.get("max_cron_jobs", 10),
                "account_tier": user.get("account_tier", "free")
            }
        else:
            return {"max_accounts": 5, "max_cron_jobs": 10}  # Default limits
    except Exception as e:
        logger.error(f"Error getting user limits: {e}")
        return {"max_accounts": 5, "max_cron_jobs": 10}  # Default limits


# Add a check for account limits when adding new accounts
async def check_account_limit(user_id):
    """Check if user has reached their account limit"""
    user_data = user_sessions.get(user_id, {})
    accounts = user_data.get("accounts", {})
    accounts_count = len(accounts)
    
    user_limits = await get_user_limits(user_id)
    max_accounts = user_limits.get("max_accounts", 5)
    
    return accounts_count < max_accounts

# Add after the MongoDB connection section
# Admin user IDs
ADMIN_USER_IDS = os.getenv("ADMIN_USER_IDS", "").split(",")
ADMIN_USER_IDS = [aid.strip() for aid in ADMIN_USER_IDS if aid.strip()]

async def is_admin(user_id):
    """Check if user is an admin"""
    return str(user_id) in ADMIN_USER_IDS

# Admin commands



# Add a more comprehensive help command
@bot.on_message(filters.command("help") & filters.private)
async def help_command(client, message):
    """Handle /help command"""
    user_id = message.from_user.id
    
    # Update user activity
    await update_user_activity(user_id)
    
    help_text = (
        "📖 Twitter Account Automation Bot - Help\n\n"
        "Available commands:\n\n"
        "/start - Start the bot and access the main menu\n"
        "/help - Show this help message\n"
        "/cron - Manage Twitter account tracking\n"
        "/setchannel - Set a channel for cronjob posts\n"
        "/channel - View your current channel settings\n\n"
        
        "Account Management:\n"
        "• Add Twitter account (up to your tier limit)\n"
        
        "Twitter Features:\n"
        "• Set up cron jobs to monitor Twitter accounts\n"
        "• Generate AI content for your tweets\n"
        "• Create images from scripts\n"
        "• Post directly to your Twitter account\n\n"
        
        "Channel Integration:\n"
        "• Forward a message from your channel to set it up\n"
        "• Use /setchannel @username to configure your channel\n"
        "• Cronjob posts will be sent to your channel automatically\n\n"
        
        "Need more help? Use /start to access the main menu."
    )
    
    await message.reply(help_text)


# Add global error handler for the bot
@bot.on_message(filters.regex(r'^/.*') & filters.private & ~filters.command(["start", "help", "status", "cron", "setchannel", "channel"]))
async def unknown_command(client, message):
    """Handle unknown commands"""
    await message.reply(
        "❓ Unknown command. Use /help to see available commands."
    )

# Add error recovery for Twitter sessions
async def check_and_refresh_session(user_id, twitter_username):
    """Check if a Twitter session is valid and refresh if needed"""
    try:
        if user_id not in user_sessions:
            return False
            
        user_data = user_sessions[user_id]
        accounts = user_data.get("accounts", {})
        
        if twitter_username not in accounts:
            return False
            
        session = accounts[twitter_username]
        
        # Check if session is valid
        if not session.page or not session.context:
            logger.warning(f"Invalid session for @{twitter_username} (User: {user_id})")
            return False
            
        try:
            # Try a simple action to verify session
            await session.page.goto("https://x.com/home", timeout=30000)
            await asyncio.sleep(2)
            
            # Check if still logged in
            if not await verify_login(session.page):
                logger.warning(f"Session expired for @{twitter_username} (User: {user_id})")
                return False
                
            # Session is valid
            return True
        except Exception as e:
            logger.error(f"Error checking session for @{twitter_username} (User: {user_id}): {e}")
            return False
            
    except Exception as e:
        logger.error(f"Error in check_and_refresh_session: {e}")
        return False

# Add a function to handle Twitter API rate limits and errors
async def handle_twitter_error(error, user_id, message=None, callback_query=None):
    """Handle common Twitter API errors"""
    error_str = str(error).lower()
    
    # Rate limit error
    if "rate limit" in error_str or "too many requests" in error_str:
        error_message = (
            "⚠️ Twitter rate limit reached. Please try again later.\n\n"
            "Twitter limits how many actions you can perform in a certain time period."
        )
    # Authentication error
    elif "auth" in error_str or "login" in error_str or "credentials" in error_str:
        error_message = (
            "⚠️ Twitter authentication error. Your session may have expired.\n\n"
            "Please try logging out and logging back in."
        )
    # Network error
    elif "network" in error_str or "timeout" in error_str or "connection" in error_str:
        error_message = (
            "⚠️ Network error when connecting to Twitter.\n\n"
            "Please check your internet connection and try again."
        )
    # Unknown error
    else:
        error_message = f"⚠️ Twitter error: {str(error)[:100]}"
    
    # Send error message
    try:
        if callback_query:
            await callback_query.answer("An error occurred", show_alert=True)
            await callback_query.message.reply(error_message)
        elif message:
            await message.reply(error_message)
    except Exception as e:
        logger.error(f"Error sending error message: {e}")

@bot.on_callback_query(filters.regex('^back_to_menu$'))
async def back_to_menu_handler(client, callback_query):
    """Handle back to menu callback"""
    user_id = callback_query.from_user.id
    
    # Update user activity
    await update_user_activity(user_id)
    
    # Acknowledge the callback query
    await callback_query.answer()
    
    # Check if user is logged in
    if user_id in user_sessions and isinstance(user_sessions[user_id], UserSession) and user_sessions[user_id].state == "logged_in":
        twitter_username = user_sessions[user_id].username
        
        await callback_query.message.edit_text(
            f"✅ You are logged in as @{twitter_username}.\n\n"
            f"What would you like to do?",
            reply_markup=LOGGED_IN_KEYBOARD
        )
    else:
        # User has no active account
        await callback_query.message.edit_text(
            f"🤖 Welcome to Twitter Automation Bot!\n\n"
            f"To get started, please log in with your Twitter account using /start",
            reply_markup=START_KEYBOARD
        )

@bot.on_callback_query(filters.regex('^back_to_start$'))
async def back_to_start_handler(client, callback_query):
    """Handle back to start callback - redirects to /start command"""
    user_id = callback_query.from_user.id
    
    # Update user activity
    await update_user_activity(user_id)
    
    # Acknowledge the callback query
    await callback_query.answer()
    
    # Show the start menu
    await callback_query.message.edit_text(
        f"🤖 Welcome to Twitter Automation Bot!\n\n"
        f"Easily automate your Twitter/X account from Telegram.\n\n"
        f"Key Features:\n"
        f"• Set up cron jobs to monitor Twitter accounts\n"
        f"• AI content and image generation\n"
        f"• Post directly to Twitter\n\n"
        f"To get started, choose your login method below:",
        reply_markup=START_KEYBOARD
    )

def get_active_twitter_account(user_id):
    """Helper function to get the active Twitter account for a user"""
    active_account = None
    if user_id in user_sessions:
        user_data = user_sessions[user_id]
        if isinstance(user_data, dict) and "active" in user_data:
            active_account = user_data["active"]
        elif isinstance(user_data, UserSession) and hasattr(user_data, "username"):
            active_account = user_data.username
    
    return active_account or "default"  # Fallback to "default" if no account is found

@bot.on_callback_query(filters.regex('^generate_consolidated_image$'))
async def consolidated_image_handler(client: Client, callback_query: CallbackQuery):
    try:
        user_id = callback_query.from_user.id
        message = callback_query.message
        
        if not message.reply_to_message_id:
            await callback_query.answer("Error: Can't find the script. This button should be used on a message that contains a script.", show_alert=True)
            return
            
        logger.info(f"Looking for script in message with ID: {message.reply_to_message_id}")
        
        try:
            await callback_query.answer("Starting consolidated image generation...")
        except Exception as e:
            logger.warning(f"Failed to answer callback query: {str(e)}")
        
        # Create a task to handle the image generation
        async def consolidated_image_task():
            try:
                original_message = await get_message_with_cache(client, message.chat.id, message.reply_to_message_id)
                if original_message and original_message.text:
                    logger.info(f"Found script in replied-to message ({message.reply_to_message_id}): {original_message.text[:50]}...")
                    script_text = original_message.text
                    
                    status_message = await message.reply(
                        "🎨 Generating a consolidated image from your script...\n"
                        "⏳ This may take a minute, please wait."
                    )
                    
                    # Generate the consolidated image
                    result = await generate_consolidated_image(
                        script_text=script_text,
                        chat_id=message.chat.id,
                        client=client,
                        message=status_message
                    )
                    
                    if result and isinstance(result, dict) and 'image_url' in result:
                        image_url = result['image_url']
                        file_id = result.get('file_id')
                        message_id = result.get('message_id')
                        
                        # Extract metadata from script
                        from ImageGen import extract_scene_metadata
                        title, description, hashtags = extract_scene_metadata(script_text)
                        logger.info(f"Extracted metadata - Title: {title or 'None'}, Description: {description[:30] + '...' if description else 'None'}, Hashtags: {hashtags or 'None'}")
                        
                        # Store in MongoDB
                        active_account = None
                        if user_id in user_sessions:
                            if isinstance(user_sessions[user_id], dict):
                                active_account = user_sessions[user_id].get("active")
                            elif isinstance(user_sessions[user_id], UserSession):
                                active_account = user_sessions[user_id].username
                        if not active_account:
                            active_account = get_active_twitter_account(user_id)
                        
                        # Create metadata list for the single image
                        metadata = [{
                            "title": title,
                            "description": description,
                            "hashtags": hashtags
                        }]
                        
                        # Create a new batch with URL, file_id, message_id and metadata
                        batch_id = create_image_batch(
                            db, user_id, active_account,
                            [{"image_url": image_url, "file_id": file_id, "message_id": message_id}],
                            scenes=[script_text], script_text=script_text,
                            metadata=metadata
                        )
                        
                        # Add post to Twitter button
                        keyboard = InlineKeyboardMarkup([
                            [InlineKeyboardButton("🐦 Post to Twitter", callback_data=f"ptt|{batch_id}")]
                        ])
                        
                        await status_message.edit_text(
                            "✅ Successfully generated your consolidated image!",
                            reply_markup=keyboard
                        )
                    else:
                        await status_message.edit_text("❌ Failed to generate the consolidated image. Please try again.")
                else:
                    await message.reply("❌ Could not find the script message.")
            except Exception as e:
                logger.error(f"Error in consolidated image generation task: {e}")
                await message.reply(f"❌ Error generating consolidated image: {str(e)[:200]}")
        
        # Add task to user's AI task queue and start processing
        task = consolidated_image_task()
        ai_task_queue[user_id].append(task)
        asyncio.create_task(process_queues(user_id))
        
    except Exception as e:
        error_msg = f"Error in consolidated_image_handler: {str(e)}"
        logger.error(error_msg)
        try:
            await callback_query.message.reply(
                text=f"❌ {error_msg}\n\nPlease try again later."
            )
        except Exception as msg_error:
            logger.error(f"Failed to send error message: {str(msg_error)}")

@bot.on_message(filters.forwarded & filters.private)
async def handle_forwarded_message(client, message):
    """Handle forwarded messages from channels to set up user's channel for cronjob posts"""
    user_id = message.from_user.id
    
    # Log message properties for debugging
    logger.info(f"Received forwarded message from user {user_id}")
    logger.info(f"forward_from_chat: {message.forward_from_chat}")
    
    # Check if message is forwarded from a channel
    if message.forward_from_chat:
        channel_id = message.forward_from_chat.id
        channel_username = getattr(message.forward_from_chat, "username", None)
        channel_title = getattr(message.forward_from_chat, "title", "Unknown Channel")
        
        # Send status message
        status_message = await message.reply(f"🔄 Checking access to channel: {channel_title}")
        
        # Try to directly send a test message to verify posting permission
        try:
            await status_message.edit_text(f"🔄 Sending a test message to {channel_title}...")
            test_message = await client.send_message(
                chat_id=channel_id,
                text=f"🤖 Channel verification test. This message will be deleted in a few seconds."
            )
            
            # Wait 3 seconds and delete the test message
            await asyncio.sleep(3)
            await test_message.delete()
            
            # If we got here, the bot has posting permission
            logger.info(f"Successfully sent and deleted test message in channel {channel_id}")
            
            # Store channel info in user's profile
            if db is not None:
                try:
                    # Update user document
                    db.users.update_one(
                        {"user_id": user_id},
                        {"$set": {
                            "channel_id": channel_id,
                            "channel_username": channel_username,
                            "channel_title": channel_title,
                            "channel_verified_at": datetime.now()
                        }},
                        upsert=True
                    )
                    
                    # Send success message
                    await status_message.edit_text(
                        f"✅ Successfully set {channel_title} as your posting channel!\n\n"
                        f"All cronjob posts will now be sent to this channel."
                    )
                    
                    logger.info(f"User {user_id} set channel {channel_id} ({channel_title}) for cronjob posts")
                    return
                except Exception as e:
                    logger.error(f"Error updating user's channel info: {e}")
                    await status_message.edit_text(f"❌ Database error: {str(e)}")
                    return
            else:
                await status_message.edit_text("❌ Database connection is not available.")
                return
        except Exception as e:
            logger.error(f"Error sending test message to channel: {e}")
            
            # Try to get more information about bot's status in the channel
            try:
                bot_id = (await client.get_me()).id
                chat_member = await client.get_chat_member(channel_id, bot_id)
                logger.info(f"Bot status in channel: {chat_member.status}")
                logger.info(f"Bot permissions: {vars(chat_member)}")
                
                if chat_member.status in ["administrator", "creator"]:
                    can_post = getattr(chat_member, "can_post_messages", False)
                    logger.info(f"Bot can_post_messages: {can_post}")
                    
                    if can_post:
                        await status_message.edit_text(
                            f"⚠️ I have admin rights but still couldn't post to {channel_title}.\n\n"
                            f"Please check the channel settings and make sure there are no restrictions."
                        )
                    else:
                        await status_message.edit_text(
                            f"⚠️ I'm an admin in {channel_title} but don't have 'Post Messages' permission.\n\n"
                            f"Please update my admin rights to include 'Post Messages'."
                        )
                else:
                    await status_message.edit_text(
                        f"⚠️ I need to be an administrator in {channel_title}.\n\n"
                        f"Please add me as an administrator with 'Post Messages' permission enabled."
                    )
            except Exception as inner_e:
                logger.error(f"Error checking admin status: {inner_e}")
                await status_message.edit_text(
                    f"❌ Error: {str(e)}\n\n"
                    f"Make sure I'm a member of your channel and have admin privileges."
                )
            return
    else:
        # Not forwarded from a channel or channel info is hidden
        await message.reply(
            "⚠️ I couldn't detect channel information from your forwarded message.\n\n"
            "This can happen if the channel has restricted forwarding.\n\n"
            "Please try using the command format instead:\n"
            "/setchannel @your_channel_username\n\n"
            "Make sure the bot is an administrator in your channel with posting permissions."
        )

@bot.on_message(filters.command("setchannel") & filters.private)
async def set_channel_command(client, message):
    """Handle /setchannel command to set up a user's channel for cronjob posts"""
    user_id = message.from_user.id
    
    # Check if user is logged in
    if user_id not in user_sessions:
        await message.reply("⚠️ Please log in first using /start")
        return
    
    # Check command format
    command_parts = message.text.split()
    if len(command_parts) != 2:
        await message.reply(
            "📝 Usage: /setchannel @channel_username\n\n"
            "Or you can forward a message from your channel to set it up.\n\n"
            "Make sure the bot is an administrator in your channel with posting permissions."
        )
        return
    
    channel_username = command_parts[1].strip()
    if not channel_username.startswith('@'):
        await message.reply("❌ Channel username must start with @")
        return
    
    channel_username = channel_username[1:]  # Remove @ prefix
    
    # Send status message
    status_message = await message.reply(f"🔄 Checking access to channel: @{channel_username}")
    
    # Try to get channel info
    try:
        channel_info = await client.get_chat(f"@{channel_username}")
        channel_id = channel_info.id
        channel_title = channel_info.title
        
        # Verify bot is admin in the channel
        bot_id = (await client.get_me()).id
        chat_member = await client.get_chat_member(channel_id, bot_id)
        
        if chat_member.status in ["administrator", "creator"]:
            if chat_member.can_post_messages:
                # Store channel info in user's profile
                if db is not None:
                    try:
                        # Update user document
                        db.users.update_one(
                            {"user_id": user_id},
                            {"$set": {
                                "channel_id": channel_id,
                                "channel_username": channel_username,
                                "channel_title": channel_title,
                                "channel_verified_at": datetime.now()
                            }},
                            upsert=True
                        )
                        
                        # Send success message
                        await status_message.edit_text(
                            f"✅ Successfully set {channel_title} (@{channel_username}) as your posting channel!\n\n"
                            f"All cronjob posts will now be sent to this channel."
                        )
                        
                        logger.info(f"User {user_id} set channel {channel_id} ({channel_title}) for cronjob posts")
                        return
                    except Exception as e:
                        logger.error(f"Error updating user's channel info: {e}")
                        await status_message.edit_text(f"❌ Database error: {str(e)}")
                        return
                else:
                    await status_message.edit_text(
                        "❌ Database connection is not available."
                    )
                    return
            else:
                await status_message.edit_text(
                    f"⚠️ I don't have permission to post messages in {channel_title}.\n\n"
                    f"Please add me as an administrator with 'Post Messages' permission enabled."
                )
                return
        else:
            await status_message.edit_text(
                f"⚠️ I need to be an administrator in {channel_title}.\n\n"
                f"Please add me as an administrator with 'Post Messages' permission enabled."
            )
            return
    except Exception as e:
        logger.error(f"Error checking channel: {e}")
        await status_message.edit_text(
            f"❌ Error: {str(e)}\n\n"
            f"Make sure the channel exists and I have access to it."
        )
        return

@bot.on_message(filters.command("channel") & filters.private)
async def channel_info_command(client, message):
    """Handle /channel command to show current channel settings"""
    user_id = message.from_user.id
    
    # Check if user is logged in
    if user_id not in user_sessions:
        await message.reply("⚠️ Please log in first using /start")
        return
    
    # Check if user has a registered channel
    if db is not None:
        try:
            user_doc = db.users.find_one({"user_id": user_id})
            if user_doc and "channel_id" in user_doc:
                channel_id = user_doc["channel_id"]
                channel_username = user_doc.get("channel_username", "Unknown")
                channel_title = user_doc.get("channel_title", "Unknown")
                verified_at = user_doc.get("channel_verified_at", "Unknown")
                
                # Try to get current channel info to verify it's still valid
                try:
                    channel_info = await client.get_chat(channel_id)
                    current_title = channel_info.title
                    current_username = channel_info.username
                    
                    # Check if bot is still admin
                    bot_id = (await client.get_me()).id
                    chat_member = await client.get_chat_member(channel_id, bot_id)
                    is_admin = chat_member.status in ["administrator", "creator"]
                    can_post = getattr(chat_member, "can_post_messages", False)
                    
                    if is_admin and can_post:
                        status = "✅ Active"
                    else:
                        status = "⚠️ Bot lost admin privileges"
                except Exception as e:
                    status = f"❌ Error: {str(e)}"
                    current_title = channel_title
                    current_username = channel_username
                
                await message.reply(
                    f"📢 Your Channel Settings\n\n"
                    f"Title: {current_title}\n"
                    f"Username: @{current_username}\n"
                    f"ID: {channel_id}\n"
                    f"Status: {status}\n\n"
                    f"To change your channel, use /setchannel or forward a message from another channel."
                )
            else:
                await message.reply(
                    "❌ You don't have a channel set up yet.\n\n"
                    "To set up a channel, use /setchannel or forward a message from your channel.\n\n"
                    "Make sure the bot is an administrator in your channel with posting permissions."
                )
        except Exception as e:
            logger.error(f"Error checking user's channel: {e}")
            await message.reply(f"❌ Error checking channel settings: {str(e)}")
    else:
        await message.reply("❌ Database connection is not available.")

def main():
    """
    Main function to initialize and start the bot
    """
    # Print welcome message
    print("\nTwitter Bot Starting...\n")

    # Create temp directory if it doesn't exist
    os.makedirs(Config.TEMP_DIR, exist_ok=True)
    os.makedirs(Config.COOKIE_DIR, exist_ok=True)
    
    # MongoDB initialization
    init_mongodb()

    # Use the global bot instance that already has the handlers attached
    global bot
    
    bot._workers = 16  # Set workers property directly
    bot.run()
    
    # This will execute after the bot is stopped
    print("Bot stopped, cleaning up resources...")
    print("Bot stopped completely")


if __name__ == "__main__":
    main() 